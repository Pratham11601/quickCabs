import 'package:get/get.dart';

import '../Routes/routes.dart';
import 'package:http/http.dart' as http;

class RegistrationController extends GetxController {
  var phone = ''.obs;
  var password = ''.obs;

  var phoneError = Rx<String?>(null);
  var passwordError = Rx<String?>(null);


  void toLoginPage(){
    Get.toNamed(Routes.LOGIN_PAGE);
  }

}
