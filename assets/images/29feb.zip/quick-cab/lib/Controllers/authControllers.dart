// import 'package:get/get.dart';
// import 'package:get/get_core/src/get_main.dart';
// import 'package:get/get_rx/src/rx_types/rx_types.dart';
// import 'package:get/get_state_manager/src/simple/get_controllers.dart';
// import 'package:jwt_decoder/jwt_decoder.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import '../Screens/login_page.dart';
//
// class AuthController extends GetxController {
//   static AuthController? _instance;
//
//   // Use RxString instead of late String for _tokenController
//   final RxString _tokenController = ''.obs;
//
//   AuthController._internal();
//
//   static AuthController get instance {
//     if (_instance == null) {
//       _instance = AuthController._internal();
//     }
//     return _instance!;
//   }
//
//   String get token => _tokenController.value;
//
//   void setToken(String token) {
//     _tokenController.value = token;
//   }
//
//   bool isAuthenticated() {
//     return !JwtDecoder.isExpired(_tokenController.value);
//   }
//
//   void logout() async {
//     try {
//       _tokenController.value = '';
//
//       SharedPreferences prefs = await SharedPreferences.getInstance();
//       await prefs.remove('token');
//
//       Get.offAll(LoginPage());
//     } catch (error) {
//       print('Error during logout: $error');
//     }
//   }
//
//
//   String? getCurrentUserId() {
//     String token = _tokenController.value;
//
//     if (token.isNotEmpty && !JwtDecoder.isExpired(token)) {
//       Map<String, dynamic> decodedToken = JwtDecoder.decode(token);
//
//       String userId = decodedToken['id'] ?? " "  ;
//
//       return userId;
//     } else {
//       // Token is empty or expired, user not authenticated
//       return null;
//     }
//   }
//
//
// }
