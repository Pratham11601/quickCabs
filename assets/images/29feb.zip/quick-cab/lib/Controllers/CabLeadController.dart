import 'dart:async';
import 'package:get/get.dart';
import '../models/leads_listing.dart';
import '../models/leadss.dart';
import '../services/ApiServices.dart';

class LeadsController extends GetxController {
  final StreamController<List<Result>> _leadsStreamController =
  StreamController<List<Result>>.broadcast();

  String tabname;
  List<Result> allLeads = [];
  DateTime? selectedFromDate;
  DateTime? selectedToDate;

  LeadsController({required this.tabname});

  Stream<List<Result>> get leadsStream => _leadsStreamController.stream;

  final ApiService _apiService = ApiService();
































  void fetchLeadsData({String? fromLocationFilter, String? toLocationFilter, DateTime? selectedFromDate, DateTime? selectedToDate,}) async {
    try {
      String jsonData = await _apiService.fetchLeadsDataActive();
      LeadsListing leadsListing = leadsListingFromJson(jsonData);
      allLeads = leadsListing.result;

      for (Result lead in allLeads) {
        Duration timeDifference = DateTime.now().difference(lead.createdAt);
        double minDifference = timeDifference.inMinutes.toDouble();

        lead.is_active = lead.is_active! && minDifference <= 57;

        await _apiService.updateLeadStatus(lead.id, lead.is_active!);
      }

      List<Result> filteredLeads = allLeads.where((lead) {
        bool vendorCatCondition = lead.is_active == true;

        bool fromLocationCondition = fromLocationFilter == null || lead.locationFrom == fromLocationFilter;

        bool toLocationCondition = toLocationFilter == null || lead.toLocation == toLocationFilter;

        bool dateCondition = true;
        if (selectedFromDate != null && selectedToDate != null) {
          dateCondition = lead.date != null &&
              _parseDate(lead.date!)!.isAfter(selectedFromDate) &&
              _parseDate(lead.date!)!.isBefore(selectedToDate);
        }



        return vendorCatCondition && fromLocationCondition && toLocationCondition && dateCondition;
      }).toList();

      filteredLeads.sort((a, b) => b.createdAt.compareTo(a.createdAt));

      _leadsStreamController.add(filteredLeads);

      print("Filtered and sorted Leads: $filteredLeads");
    } catch (error) {
      print("Error fetching leads data: $error");
    }
  }


  void fetchLeadsDatahomePagenew({String? fromLocationFilter, String? toLocationFilter, DateTime? selectedFromDate, DateTime? selectedToDate}) async {
    try {
      String jsonData = await _apiService.fetchLeadsDataActive();
      List<LeadsResponse> leadsResponses = leadsResponseFromJson(jsonData);

      List<Result> allLeads = [];
      for (LeadsResponse leadsResponse in leadsResponses) {
        allLeads.addAll(leadsResponse.leads as Iterable<Result>);
      }

      for (Result lead in allLeads) {
        Duration timeDifference = DateTime.now().difference(lead.createdAt);
        double minDifference = timeDifference.inMinutes.toDouble();

        lead.is_active = lead.is_active! && minDifference <= 57;

        await _apiService.updateLeadStatus(lead.id, lead.is_active!);
      }

      List<Result> filteredLeads = allLeads.where((lead) {
        bool vendorCatCondition = lead.is_active == true;

        bool fromLocationCondition = fromLocationFilter == null || lead.locationFrom == fromLocationFilter;

        bool toLocationCondition = toLocationFilter == null || lead.toLocation == toLocationFilter;

        bool dateCondition = true;
        if (selectedFromDate != null && selectedToDate != null) {
          dateCondition = lead.date != null &&
              _parseDate(lead.date.toString())!.isAfter(selectedFromDate) &&
              _parseDate(lead.date.toString())!.isBefore(selectedToDate);
        }

        return vendorCatCondition && fromLocationCondition && toLocationCondition && dateCondition;
      }).toList();

      filteredLeads.sort((a, b) => b.createdAt.compareTo(a.createdAt));

      _leadsStreamController.add(filteredLeads);

      print("Filtered and sorted Leads: $filteredLeads");
    } catch (error) {
      print("Error fetching leads data: $error");
    }
  }


  void fetchLeadsDatahomePage({String? fromLocationFilter, String? toLocationFilter, DateTime? selectedFromDate, DateTime? selectedToDate,}) async {
    try {
      String jsonData = await _apiService.fetchLeadsDataActive();
      LeadsListing leadsListing = leadsListingFromJson(jsonData);
      allLeads = leadsListing.result;

      for (Result lead in allLeads) {
        Duration timeDifference = DateTime.now().difference(lead.createdAt);
        double minDifference = timeDifference.inMinutes.toDouble();

        lead.is_active = lead.is_active! && minDifference <= 57;

        await _apiService.updateLeadStatus(lead.id, lead.is_active!);
      }

      List<Result> filteredLeads = allLeads.where((lead) {
        bool vendorCatCondition = lead.is_active == true;

        bool fromLocationCondition = fromLocationFilter == null || lead.locationFrom == fromLocationFilter;

        bool toLocationCondition = toLocationFilter == null || lead.toLocation == toLocationFilter;

        bool dateCondition = true;
        if (selectedFromDate != null && selectedToDate != null) {
          dateCondition = lead.date != null &&
              _parseDate(lead.date!)!.isAfter(selectedFromDate) &&
              _parseDate(lead.date!)!.isBefore(selectedToDate);
        }

        return vendorCatCondition && fromLocationCondition && toLocationCondition && dateCondition;
      }).toList();

      filteredLeads.sort((a, b) => b.createdAt.compareTo(a.createdAt));

      _leadsStreamController.add(filteredLeads);

      print("Filtered and sorted Leads: $filteredLeads");
    } catch (error) {
      print("Error fetching leads data: $error");
    }
  }





  void fetchLeadsDatahomePage2({String? fromLocationFilter, String? toLocationFilter, DateTime? selectedFromDate, DateTime? selectedToDate,}) async {
    try {
      String jsonData = await _apiService.fetchLeadsDataActive();
      LeadsListing leadsListing = leadsListingFromJson(jsonData);
      allLeads = leadsListing.result;

      for (Result lead in allLeads) {
        Duration timeDifference = DateTime.now().difference(lead.createdAt);
        double minDifference = timeDifference.inMinutes.toDouble();

        lead.is_active = lead.is_active! && minDifference <= 57;

        await _apiService.updateLeadStatus(lead.id, lead.is_active!);
      }

      List<Result> filteredLeads = allLeads.where((lead) {
        bool vendorCatCondition = lead.is_active == true;

        bool fromLocationCondition = fromLocationFilter == null || lead.locationFrom == fromLocationFilter;

        bool toLocationCondition = toLocationFilter == null || lead.toLocation == toLocationFilter;

        bool dateCondition = true;
        if (selectedFromDate != null && selectedToDate != null) {
          dateCondition = lead.date != null &&
              _parseDate(lead.date!)!.isAfter(selectedFromDate) &&
              _parseDate(lead.date!)!.isBefore(selectedToDate);
        }

        return vendorCatCondition && fromLocationCondition && toLocationCondition && dateCondition;
      }).toList();

      filteredLeads.sort((a, b) => b.createdAt.compareTo(a.createdAt));

      _leadsStreamController.add(filteredLeads);

      print("Filtered and sorted Leads: $filteredLeads");
    } catch (error) {
      print("Error fetching leads data: $error");
    }
  }

  void fetchDataForHistory() async {
    try {
      String jsonData = await _apiService.fetchLeadsData();

      LeadsListing leadsListing = leadsListingFromJson(jsonData);

      List<Result> filteredDataForHistory = leadsListing.result
          .where((lead) => lead.is_active == false)
          .toList();
      filteredDataForHistory.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      _leadsStreamController.add(filteredDataForHistory);

      print("Debug statement: $filteredDataForHistory");
    } catch (error) {
      print("Error fetching leads data: $error");
    }
  }

  void fetchToManageLeadsData(String? id) async {
    try {
      String jsonData = await _apiService.fetchLeadsData();
      LeadsListing leadsListing = leadsListingFromJson(jsonData);

      int? parsedId = id != null ? int.tryParse(id) : null;

      List<Result> filteredLeads = leadsListing.result
          .where((lead) => lead.vendorId == parsedId)
          .toList();

      filteredLeads.sort((a, b) => b.createdAt.compareTo(a.createdAt));

      _leadsStreamController.add(filteredLeads);

      print("Leads for ID $id: $filteredLeads");
    } catch (error) {
      print("Error fetching leads data: $error");
    }
  }

  String capitalize(String input) {
    if (input.isEmpty) {
      return input;
    }
    return input[0].toUpperCase() + input.substring(1);
  }

  DateTime? _parseDate(String dateString) {
    try {
      // Split the date string by "/"
      List<String> parts = dateString.split('/');
      // Parse the parts into integers
      int day = int.parse(parts[0]);
      int month = int.parse(parts[1]);
      int year = int.parse(parts[2]);
      // Return the parsed DateTime object
      return DateTime(year, month, day);
    } catch (e) {
      print('Error parsing date: $e');
      return null;
    }
  }


  @override
  void onClose() {
    _leadsStreamController.close();
    super.onClose();
  }

}