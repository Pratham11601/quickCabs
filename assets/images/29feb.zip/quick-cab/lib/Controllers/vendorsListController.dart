import 'dart:async';
import 'dart:convert';

import 'package:get/get.dart';
import 'package:untitled/Screens/homeScreen.dart';
import '../models/vendors_details.dart';
import '../services/ApiServices.dart';

class VendorController extends GetxController {
  final StreamController<List<Vendor>> _leadsStreamController =
  StreamController<List<Vendor>>.broadcast();

  String tabname;
  List<Vendor> _vendorSpecList = [];

  VendorController({required this.tabname});

  Stream<List<Vendor>> get leadsStream => _leadsStreamController.stream;

  final ApiService _apiService = ApiService();

  Future<void> fetchVendorsData() async {
    try {
      String jsonData = await _apiService.fetchVendorsData();

      VendorsDeatils vendorsListing = vendorsDeatilsFromJson(jsonData);

      print("this is controller $tabname" );

      _vendorSpecList = vendorsListing.vendors.where((vendor) => vendor.vendorCat == tabname  ).toList();

      _leadsStreamController.add(_vendorSpecList);
    } catch (e) {
      print("Error occurred: $e");
    }
  }

  void filterVendors(String query) {
    if (query.isEmpty) {
      _leadsStreamController.add(_vendorSpecList);
    } else {
      query = query.toLowerCase();
      List<Vendor> filteredVendors = _vendorSpecList.where((vendor) {
        final fullNameLowerCase = vendor.fullname?.toLowerCase() ?? '';
        final businessNameLowerCase = vendor.businessName?.toLowerCase() ?? '';
        final cityLowerCase = vendor.city?.toLowerCase() ?? '';

        return fullNameLowerCase.contains(query) ||
            businessNameLowerCase.contains(query) ||
            cityLowerCase.contains(query);
      }).toList();
      _leadsStreamController.add(filteredVendors);
    }
  }

  @override
  void onClose() {
    _leadsStreamController.close();
    super.onClose();
  }
}
