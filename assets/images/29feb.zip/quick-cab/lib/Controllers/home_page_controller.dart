import 'dart:async';

import 'package:get/get.dart';

import '../Screens/Tabs/Cabstab.dart';
import '../Screens/Tabs/VendorsList.dart';
import '../models/leads_listing.dart';
import '../services/ApiServices.dart';

class HomeController extends GetxController {

  RxInt selectedIndex = 0.obs;
  RxMap userData = {}.obs;
  List<Result> allLeads = [];
  DateTime? selectedFromDate;
  DateTime? selectedToDate;



  void updateUserData(Map<String, dynamic> newData) {
    userData = newData.obs;
    print("Updated userData: $userData");
  }



  void navigateToTab(int index) {
    selectedIndex.value = index;
    switch (index) {
      case 0:
        Get.to(CabsTab());
        break;
      case 1:
        Get.to(VendorsListScreen(tabName: 'Drivers'));
        break;
      case 2:
        Get.to(VendorsListScreen(tabName: 'Puncture'));
        break;
      case 3:
        Get.to(VendorsListScreen(tabName: 'Repairing'));
        break;
      case 4:
        Get.to(VendorsListScreen(tabName: 'Towing'));
        break;
      case 5:
        Get.to(VendorsListScreen(tabName: 'Fuel'));
        break;
      case 6:
        Get.to(VendorsListScreen(tabName: 'Restaurants'));
        break;
      case 7:
        Get.to(VendorsListScreen(tabName: 'Emergency'));

        break;
    }
  }


}
