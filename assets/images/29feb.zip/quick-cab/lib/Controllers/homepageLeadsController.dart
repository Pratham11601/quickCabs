import 'dart:async';
import 'package:get/get.dart';
import '../models/leads_listing.dart';
import '../services/ApiServices.dart';

class HomePageLeadsController extends GetxController {
  final StreamController<List<Result>> _homePageLeadsStreamController =
  StreamController<List<Result>>.broadcast();

  List<Result> homePageLeads = [];

  Stream<List<Result>> get homePageLeadsStream =>
      _homePageLeadsStreamController.stream;

  final ApiService _homePageApiService = ApiService();

  String capitalize(String input) {
    if (input.isEmpty) {
      return input;
    }
    return input[0].toUpperCase() + input.substring(1);
  }

  void fetchHomePageLeadsData({
    String? fromLocationFilter,
    String? toLocationFilter,
    DateTime? selectedFromDate,
    DateTime? selectedToDate,
  }) async {
    try {
      String jsonData = await _homePageApiService.fetchLeadsDataActive();
      LeadsListing homePageLeadsListing = leadsListingFromJson(jsonData);
      homePageLeads = homePageLeadsListing.result;

      for (Result homePageLead in homePageLeads) {
        Duration timeDifference =
        DateTime.now().difference(homePageLead.createdAt);
        double minDifference = timeDifference.inMinutes.toDouble();

        homePageLead.is_active = homePageLead.is_active! && minDifference <= 57;

        await _homePageApiService.updateLeadStatus(
          homePageLead.id,
          homePageLead.is_active!,
        );
      }

      List<Result> filteredHomePageLeads = homePageLeads.where((homePageLead) {
        bool vendorCatCondition = homePageLead.is_active == true;

        bool fromLocationCondition = fromLocationFilter == null ||
            homePageLead.locationFrom == fromLocationFilter;

        bool toLocationCondition =
            toLocationFilter == null || homePageLead.toLocation == toLocationFilter;

        bool dateCondition = true;
        if (selectedFromDate != null && selectedToDate != null) {
          dateCondition = homePageLead.date != null &&
              _parseDate(homePageLead.date!).isAfter(selectedFromDate) &&
              _parseDate(homePageLead.date!).isBefore(selectedToDate);
        }

        return vendorCatCondition &&
            fromLocationCondition &&
            toLocationCondition &&
            dateCondition;
      }).toList();

      filteredHomePageLeads.sort((a, b) => b.createdAt.compareTo(a.createdAt));

      _homePageLeadsStreamController.add(filteredHomePageLeads);

      print("Filtered and sorted Leads for homepage: $filteredHomePageLeads");
    } catch (error) {
      print("Error fetching leads data for homepage: $error");
    }
  }

  DateTime _parseDate(String dateString) {
    List<String> parts = dateString.split('/');
    int day = int.parse(parts[0]);
    int month = int.parse(parts[1]);
    int year = int.parse(parts[2]);
    return DateTime(year, month, day);
  }

  @override
  void onClose() {
    _homePageLeadsStreamController.close();
    super.onClose();
  }
}
