import 'package:flutter_localization/flutter_localization.dart';

List<MapLocale> LOCALE = [
  MapLocale('mr', LocalData.MR),
  MapLocale('hi', LocalData.HI),
  MapLocale('eng', LocalData.eng),
  MapLocale('kan', LocalData.KN),
];

mixin LocalData {
  static const String MyProfile = 'MyProfile';
  static const String featuresTag = 'featuresTag';
  static const String userRegistration = 'userRegistration';
  static const String busniessDetails = 'busniessDetails';
  static const String transgender = 'transgender';
  static const String Language = 'Language';
  static const String Home = 'Home';
  static const String editProfile = 'editProfile';
  static const String ManagemyLeads = 'ManagemyLeads';
  static const String leadsHistory = 'leadsHistory';
  static const String postNewLead = 'postNewLead';
  static const String helpAndSupport = 'helpAndSupport';
  static const String history = 'history';
  static const String postLead = 'Postlead';
  static const String myLeads = 'myLeads';
  static const String name = 'name';
  static const String detailsSaved = 'detailsSaved';
  static const String phone = 'Phone';
  static const String email = 'Email';
  static const String gender = 'gender';
  static const String budniessAddress = 'budniessAddress';
  static const String savedetails = 'savedetails';
  static const String logout = 'logout';
  static const String helpandsupport = 'helpandsupport';
  static const String sendMessage = 'Sendmessage';
  static const String howcanweAssit = 'howcanweAssityou';
  static const String typeQuery = 'typeQuery';
  static const String active = 'active';
  static const String completed = 'completed';
  static const String Login = 'Login';
  static const String PersonDetails = 'PersonDetails';
  static const String firstname = 'firstname';
  static const String surname = 'surname';
  static const String male = 'Male';
  static const String female = 'female';
  static const String profileImage = 'profileImage';
  static const String capture = 'capture';
  static const String contine = 'continue';
  static const String cancle = 'cancle';
  static const String busniessname = 'busniessname';
  static const String category = 'category';
  static const String license = 'license';
  static const String document = 'document';
  static const String pleaseenteryourphonenumber = 'Pleaseenteryourphonenumber';
  static const String BusinessAddress = 'BusinessAddress';
  static const String address = 'address';
  static const String city = 'city';
  static const String pincode = 'pincode';
  static const String UploadAdharCard = 'UploadAdharCard';
  static const String SelectDrivingLicenceImage = 'SelectDrivingLicenceImage';
  static const String Pleasecheckyourinternetconnection =
      'Pleasecheckyourinternetconnection';
  static const String Searchbynameorcity = 'Searchbynameorcity';
  static const String noDataFound = 'noDataFound';
  static const String goback = 'goback';
  static const String callhim = 'callhim';
  static const String CabServices = 'CabServices';
  static const String from = 'from';
  static const String leads = 'leads';
  static const String Activeleads = 'Activeleads';
  static const String to = ' to ';
  static const String Completed = 'Completed';
  static const String accountDetails = 'accountDetails';
  static const String PostNewLead = 'PostNewLead';
  static const String Cab = 'Cab';
  static const String Driver = 'Driver';
  static const String Repairing = 'Repairing';
  static const String Puncture = 'Puncture';
  static const String Towing = 'Towing';
  static const String Fuel = 'Fuel';
  static const String Restaurant = 'Restaurant';
  static const String Emergeny = 'Emergeny';
  static const String SelectDate = "SelectDate";
  static const String Selecttime = "Selecttime";
  static const String Skip = "Skip";
  static const String firstfeaturesContent = "Dear friends, it gives us great pleasure to inform you that we have developed an app for you, which is absolutely free.";
  static const String FeaturesList = "";
  static const String FeaturesDescription = "";



  static Map<String, dynamic> KN = {
    FeaturesList: "೧) ಬುಕ್ ಮಾಡಿಕೊಳ್ಳಿ \n೨) ಟೋಯಿಂಗ್ \n೩) ಪಂಕ್ಚರ್ ರಿಪೇರ್ \n೪) ಮೆಕಾನಿಕ್ \n೫) ಪೆಟ್ರೋಲ್ ಸಿಎನ್ಜಿ ಸ್ಟೇಷನ್ ಮತ್ತು ಸಮಯ \n೬) ಆಂಬುಲೆನ್ಸ್ \n೭) ಹೋಟೆಲ್ ರೆಸ್ಟೊರಂಟ್ \n೮) ಡ್ರೈವರ್ \nಮತ್ತು ಇನ್ನೂ ಅನೇಕ.",
    firstfeaturesContent: "ಪ್ರಿಯ ಸ್ನೇಹಿತರೇ, ನಾವು ನಿಮಗಾಗಿ ಸಂಪೂರ್ಣ ಉಚಿತವಾಗಿ ಅಪ್ಲಿಕೇಶನ್ ಅನ್ನು ಅಭಿವೃದ್ಧಿ ಮಾಡಿದ್ದೇವೆ.",
    FeaturesDescription: "ಅದಕ್ಕಾಗಿ, ನೀವು ನಮ್ಮ ಅಪ್ಲಿಕೇಶನ್‌ನ್ನು ಡೌನ್‌ಲೋಡ್ ಮಾಡಿ ಮೂಲ ದಾಖಲೆಗಳನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಿ ಪರಿಶೀಲಿಸಬೇಕಾಗುತ್ತದೆ. ನಾವು ಎಲ್ಲರಿಗೂ ಅವರ ಮೂಲ ದಾಖಲೆಗಳನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡಲು ವಿನಂತಿಸುತ್ತೇವೆ. ಯಾರು ತಪ್ಪಾದ ದಾಖಲೆಗಳನ್ನು ಅಪ್ಲೋಡ್ ಮಾಡುತ್ತಾರೆಯೋ ಅವರನ್ನು ತಂತ್ರಾಂಶ ಪ್ರದೇಶದಿಂದ ಶಾಶ್ವತವಾಗಿ ನಿಲ್ಲಿಸಲಾಗುತ್ತದೆ ಮತ್ತು ಯಾವುದೇ ಫರುಡ್‌ಲಂಬಿಯ ಪ್ರಯತ್ನಗಳ ಮೇಲೆ ಕಾನೂನಿಗೆ ಪ್ರವೃತ್ತಿ ನಡೆಯಲಾಗುತ್ತದೆ.",
    userRegistration: "ಬಳಕೆದಾರ ನೋಂದಣಿ",
    Skip: "ಸ್ಕಿಪ್",
    featuresTag: "ನಮ್ಮ ಭದ್ರ ಅಪ್ಲಿಕೇಶನ್‌ಗೆ ಸ್ವಾಗತ",
    SelectDate: "ದಿನಾಂಕ ಆಯ್ಕೆ ಮಾಡಿ",
    Selecttime: "ಸಮಯ ಆಯ್ಕೆಮಾಡಿ",
    Driver: "ಚಾಲಕ",
    Repairing: "ಸರಿಪಡಿಸುವುದು",
    Fuel: "ಈಂಧನ",
    Puncture: "ಪಂಕ್ಚರ್",
    Towing: "ಟೋಯಿಂಗ್",
    Emergeny: "ಅತ್ಯಾವಶ್ಯಕ",
    Restaurant: "ರೆಸ್ಟೋರಂಟ್",
    PostNewLead: "ಹೊಸ ಲೀಡ್ ಪೋಸ್ಟ್ ಮಾಡಿ",
    accountDetails: "ಖಾತೆಯ ವಿವರಗಳು",
    detailsSaved: "ವಿವರಗಳನ್ನು ಉಳಿಸಿದೆ",
    goback: "ಹಿಂದಿರುಗಿ",
    from: " ",
    to: " ರಿಂದ ",
    leads: "ಲೀಡ್‌ಗಳು",
    Activeleads: "ಸಕ್ರಿಯ ಲೀಡ್‌ಗಳು ",
    Completed: "ಪೂರ್ಣಗೊಂಡಿದೆ",
    callhim: "ಅವನಿಗೆ ಫೋನ್ ಮಾಡಿ",
    CabServices: "ಕ್ಯಾಬ್ ಸೇವೆಗಳು",
    Searchbynameorcity: "ಹೆಸರು ಅಥವಾ ನಗರದ ಹೆಸರು ಅನ್ನು ಹುಡುಕಿ",
    noDataFound: "ಡೇಟಾ ಕಂಡುಬಂದಿಲ್ಲ",
    UploadAdharCard: "ಆಧಾರ ಕಾರ್ಡ್ ಅಪ್ಲೋಡ್ ಮಾಡಿ",
    Pleasecheckyourinternetconnection:
    "ದಯವಿಟ್ಟು ನಿಮ್ಮ ಇಂಟರ್ನೆಟ್ ಸಂಪರ್ಕವನ್ನು ಪರಿಶೀಲಿಸಿ!",
    pleaseenteryourphonenumber: "ದಯವಿಟ್ಟು ನಿಮ್ಮ ಫೋನ್ ಸಂಖ್ಯೆಯನ್ನು ನಮೂದಿಸಿ",
    SelectDrivingLicenceImage: "ಡ್ರೈವಿಂಗ್ ಲೈಸೆನ್ಸ್ ಚಿತ್ರವನ್ನು ಆಯ್ಕೆ ಮಾಡಿ",
    city: "ನಗರ",
    address: "ವಿಳಾಸ",
    pincode: "ಪಿನ್‌ಕೋಡ್",
    BusinessAddress: "ವ್ಯಾಪಾರ ವಿಳಾಸ",
    busniessDetails: "ವ್ಯಾಪಾರ ವಿವರಗಳು",
    transgender: "ಟ್ರಾನ್ಸ್‌ಜೆಂಡರ್",
    Home: "ಮುಖಪುಟ",
    Language: "ಭಾಷೆ",
    Cab: "ಕ್ಯಾಬ್",
    MyProfile: 'ನನ್ನ ಪ್ರೊಫೈಲ್',
    editProfile: 'ಪ್ರೊಫೈಲ್ ಸಂಪಾದಿಸಿ',
    ManagemyLeads: 'ನನ್ನ ಲೀಡ್‌ಗಳನ್ನು ನಿರ್ವಹಿಸಿ',
    leadsHistory: 'ಲೀಡ್‌ಗಳ ಇತಿಹಾಸ',
    postNewLead: 'ಹೊಸ ಲೀಡ್ ಪೋಸ್ಟ್ ಮಾಡಿ',
    helpAndSupport: 'ಸಹಾಯ ಮತ್ತು ಬೆಂಬಲ',
    history: 'ಇತಿಹಾಸ',
    postLead: 'ಲೀಡ್ ಪೋಸ್ಟ್ ಮಾಡಿ',
    myLeads: 'ನನ್ನ ಲೀಡ್‌ಗಳು',
    name: 'ಹೆಸರು',
    phone: 'ಫೋನ್',
    email: 'ಇಮೇಲ್',
    gender: 'ಲಿಂಗ',
    budniessAddress: 'ವ್ಯಾಪಾರ ವಿಳಾಸ',
    savedetails: 'ವಿವರಗಳನ್ನು ಉಳಿಸಿ',
    logout: 'ಲಾಗ್ ಔಟ್',
    helpandsupport: 'ಸಹಾಯ ಮತ್ತು ಬೆಂಬಲ',
    sendMessage: 'ಸಂದೇಶ ಕಳುಹಿಸಿ',
    howcanweAssit: 'ನಾವು ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು',
    typeQuery: 'ಪ್ರಶ್ನೆ ಟೈಪ್ ಮಾಡಿ',
    active: 'ಸಕ್ರಿಯ',
    completed: 'ಪೂರ್ಣಗೊಂಡಿದೆ',
    Login: 'ಲಾಗಿನ್ ಮಾಡಿ',
    PersonDetails: 'ವ್ಯಕ್ತಿ ವಿವರಗಳು',
    firstname: 'ಮೊದಲ ಹೆಸರು',
    surname: 'ಕುಟುಂಬದ ಹೆಸರು',
    male: 'ಪುರುಷ',
    female: 'ಸ್ತ್ರೀ',
    profileImage: 'ಪ್ರೊಫೈಲ್ ಚಿತ್ರ',
    capture: 'ಸ್ನಾಪ್‌ಗೆ ಹಿಡಿಯಿರಿ',
    contine: 'ಮುಂದುವರಿಸಿ',
    cancle: 'ರದ್ದು ಮಾಡಿ',
    busniessname: 'ವ್ಯಾಪಾರದ ಹೆಸರು',
    category: 'ವರ್ಗ',
    license: 'ಲೈಸೆನ್ಸ್',
    document: 'ದಾಖಲೆ',
  };



  static Map<String, dynamic> eng = {
    FeaturesDescription:  "For that, you'll need to download our app and verify by uploading your original documents. We kindly request everyone to upload their original documents. If someone uploads incorrect documents, they will be permanently banned from the platform and legal action will be taken against any fraudulent attempts.",
    FeaturesList :  "1) Confirm booking \n2) Towing \n3) Puncture  \n3) repair  \n4) Mechanic  \n5) Petrol CNG station and timing  \n6)  Ambulance  \n7)  Hotel restaurant  \n8) Driver  \n and much more.  ",
    firstfeaturesContent:       "Dear friends, it gives us great pleasure to inform you that we have developed an app for you, which is absolutely free.",
  userRegistration: "User Registration",
    featuresTag: "Welcome to Our Secure App",
    Selecttime: "Select time",
    Driver: "Driver",
    Skip: "Skip",
    Repairing: "Repairing",
    Fuel: "Fuel",
    SelectDate: "Select Date",
    Puncture: "Puncture",
    Towing: "Towing",
    Emergeny: "Emergency",
    Restaurant: "Restaurant",
    PostNewLead: "Post New Lead",
    accountDetails: "Account Details",
    detailsSaved: "Details Saved",
    goback: "Go Back",
    from: "From",
    to: "To",
    leads: "Leads",
    Activeleads: "Active Leads",
    Completed: "Completed",
    callhim: "Call Him",
    CabServices: "Cab Services",
    Searchbynameorcity: "Search by Name or City",
    noDataFound: "No Data Found",
    UploadAdharCard: "Upload Adhar Card",
    Pleasecheckyourinternetconnection: "Please check your internet connection!",
    pleaseenteryourphonenumber: "Please enter your phone number",
    SelectDrivingLicenceImage: "Select Driving Licence Image",
    city: "City",
    address: "Address",
    pincode: "Pincode",
    BusinessAddress: "Business Address",
    busniessDetails: "Business Details",
    transgender: "Transgender",
    Home: "Home",
    Language: "Language",
    Cab: "Cab",
    MyProfile: "My Profile",
    editProfile: "Edit Profile",
    ManagemyLeads: "Manage my Leads",
    leadsHistory: "Leads History",
    postNewLead: "Post New Lead",
    helpAndSupport: "Help and Support",
    history: "History",
    postLead: "Post Lead",
    myLeads: "My Leads",
    name: "Name",
    phone: "Phone",
    email: "Email",
    gender: "Gender",
    budniessAddress: "Business Address",
    savedetails: "Save Details",
    logout: "Logout",
    helpandsupport: "Help and Support",
    sendMessage: "Send Message",
    howcanweAssit: "How can we assist you",
    typeQuery: "Type Query",
    active: "Active",
    completed: "Completed",
    Login: "Login",
    PersonDetails: "Person Details",
    firstname: "First Name",
    surname: "Surname",
    male: "Male",
    female: "Female",
    profileImage: "Profile Image",
    capture: "Capture",
    contine: "Continue",
    cancle: "Cancel",
    busniessname: "Business Name",
    category: "Category",
    license: "License",
    document: "Document",
  };

  static Map<String, dynamic> HI = {
    FeaturesList: "१) बुकिंग की पुष्टि \n२) टोइंग \n३) पंक्चर रिपेयर \n४) मीकैनिक \n५) पेट्रोल सीएनजी स्टेशन और समय \n६) एम्बुलेंस \n७) होटेल रेस्तरां \n८) ड्राइवर \nऔर बहुत कुछ।",
    firstfeaturesContent: "प्रिय मित्रों, हमें आपको सूचित करने का बड़ा आनंद है कि हमने आपके लिए एक ऐप विकसित किया है, जो पूरी तरह से मुफ्त है।",
    FeaturesDescription: "उसके लिए, आपको हमारे ऐप को डाउनलोड करके प्रमाणित करने की आवश्यकता होगी। हम सभी से एक अनुरोध करते हैं कि वे अपने मूल दस्तावेज़ अपलोड करें। यदि कोई गलत दस्तावेज़ अपलोड करता है, तो उसे प्लेटफ़ॉर्म से स्थायी रूप से प्रतिबंधित किया जाएगा और किसी भी धोखाधड़ी के प्रयास पर कानूनी कार्रवाई की जाएगी।",

    userRegistration: "उपयोगकर्ता पंजीकरण",
    Skip: "गाळणे",
    featuresTag: "हमारे सुरक्षित ऐप में आपका स्वागत है",
    SelectDate: "दिनांक का चयन करें",
    Selecttime: "समय का चयन करें",
    Driver: "चालक",
    Repairing: "वाहन दुरुस्ती",
    Fuel: "इंधन",
    Puncture: "पंक्चर",
    Towing: "टोइंग",
    Emergeny: "आणीबाणी",
    Restaurant: "उपाहारगृह",
    PostNewLead: "नई लीड पोस्ट करें",
    accountDetails: "खाता विवरण",
    detailsSaved: "विवरण सहेजा गया",
    goback: "वापस जाओ",
    from: " ",
    to: " से ",
    leads: "लीड्स",
    Activeleads: "सक्रिय लीड्स ",
    Completed: "पूरा हो गया है",
    callhim: "फोन करो",
    CabServices: "कॅब सेवा",
    Searchbynameorcity: "नाम या शहर से खोजें",
    noDataFound: "डाटा प्राप्त नहीं हुआ",
    UploadAdharCard: "आधार कार्ड अपलोड करें",
    Pleasecheckyourinternetconnection:
        "कृपया अपने इंटरनेट कनेक्शन की जाँच करें!",
    pleaseenteryourphonenumber: "कृपया अपना फोन नंबर दर्ज करें",
    SelectDrivingLicenceImage: "ड्राइविंग लाइसेंस छवि का चयन करें",
    city: "शहर",
    address: "पत्ता",
    pincode: "पिन कोड",
    BusinessAddress: "व्यवसायाचा पत्ता",
    busniessDetails: "व्यापार विवरण",
    transgender: "ट्रान्सजेंडर",
    Home: "होम",
    Language: "भाषा",
    Cab: "कॅब",
    MyProfile: 'मेरी प्रोफ़ाइल',
    editProfile: 'प्रोफ़ाइल संपादित करें',
    ManagemyLeads: 'मेरे लीड्स प्रबंधित करें',
    leadsHistory: 'लीड्स इतिहास',
    postNewLead: 'नया लीड पोस्ट करें',
    helpAndSupport: 'सहायता और समर्थन',
    history: 'इतिहास',
    postLead: 'लीड पोस्ट करें',
    myLeads: 'मेरे लीड्स',
    name: 'नाम',
    phone: 'फ़ोन',
    email: 'ईमेल',
    gender: 'लिंग',
    budniessAddress: 'व्यवसाय पता',
    savedetails: 'विवरण सहेजें',
    logout: 'लॉग आउट',
    helpandsupport: 'सहायता और समर्थन',
    sendMessage: 'संदेश भेजें',
    howcanweAssit: 'हम आपकी कैसे मदद कर सकते हैं',
    typeQuery: 'प्रश्न टाइप करें',
    active: 'सक्रिय',
    completed: 'पूरा हो गया',
    Login: 'लॉग इन करें',
    PersonDetails: 'व्यक्ति विवरण',
    firstname: 'पहला नाम',
    surname: 'उपनाम',
    male: 'पुरुष',
    female: 'महिला',
    profileImage: 'प्रोफ़ाइल छवि',
    capture: 'कैप्चर करें',
    contine: 'जारी रखें',
    cancle: 'रद्द करें',
    busniessname: 'व्यापार का नाम',
    category: 'श्रेणी',
    license: 'लाइसेंस',
    document: 'दस्तावेज़',

  };

  static Map<String, dynamic> MR = {
    FeaturesDescription: "त्यासाठी, तुम्हाला आमच्या ऍपची डाउनलोड करून वॅरिफाय करणे आवश्यक आहे. आपल्याला कृपया आपले मूळ दस्तऐवज अपलोड करायचे आहे. जर कोणी चुकीचे दस्तऐवज अपलोड केले तर त्यांना प्लेटफॉर्मवरून कायमस्वरूपीत निषेध केले जाईल आणि कोणीही धोखाधड़ीचा प्रयत्न केला तर कडेची कारवाई केली जाईल.",
    FeaturesList: "१) बुकिंगची पुष्टी \n२) टोईंग \n३) पंक्चर रिपेअर \n४) मॅकेनिक \n५) पेट्रोल CNG स्टेशन आणि वेळ \n६) एम्बुलेन्स \n७) हॉटेल रेस्टॉरंट \n८) ड्रायव्हर \nआणि अधिक.",
    firstfeaturesContent: "मित्रांनो, आपल्याला सूचित करण्याची आनंदवाणी आहे की आम्ही आपल्यासाठी एक अॅप विकसित केलं आहे, जो पूर्णपणे मोफत आहे.",

    userRegistration: " वापरकर्ता नोंदणी ",
    Skip: "गाळणे",
    featuresTag: "आमच्या सुरक्षित अ‍ॅपमध्ये आपले स्वागत आहे",
    SelectDate: "तारीख निवडा",
    SelectDate: "वेळ निवडा",
    Driver: "चालक",
    Driver: "चालक",
    Repairing: "वाहन दुरुस्ती",
    Fuel: "इंधन",
    Puncture: "पंक्चर",
    Towing: "टोइंग",
    Emergeny: "आणीबाणी",
    Restaurant: "उपाहारगृह",
    from: " ",
    Language: "भाषा",
    to: " ते ",
    PostNewLead: "नवीन लीड पोस्ट करा",
    accountDetails: "खात्याचा तपशील",
    detailsSaved: "तपशील जतन",
    leads: "लीड्स",
    Completed: "पूर्ण झाले",
    Activeleads: "सक्रिय लीड्स ",
    CabServices: "कॅब सेवा",
    callhim: "फोन करा ",
    Searchbynameorcity: "नाव किंवा शहरानुसार शोधा",
    goback: "परत जा",
    noDataFound: "कोणताही डेटा अस्तित्वात नाही",
    Pleasecheckyourinternetconnection: " कृपया आपले इंटरनेट कनेक्शन तपासा! ",
    UploadAdharCard: 'आधार कार्ड अपलोड करा',
    SelectDrivingLicenceImage: 'ड्रायव्हिंग लायसन्स प्रतिमा निवडा',
    city: "शहर",
    pincode: "पिन कोड",
    address: "पत्ता",
    BusinessAddress: "व्यवसायाचा पत्ता",
    pleaseenteryourphonenumber: "कृपया तुमचा फोन नंबर प्रविष्ट करां",
    busniessDetails: "वव्यवसाय तपशील",
    transgender: "ट्रान्सजेंडर",
    Home: "होम",
    Cab: "कॅब",
    MyProfile: 'माझं प्रोफाइल',
    editProfile: 'प्रोफाइल संपादित करा',
    ManagemyLeads: 'माझे लीड्स व्यवस्थापित करा',
    leadsHistory: 'लीड्स इतिहास',
    postNewLead: 'नवीन लीड पोस्ट करा',
    helpAndSupport: 'सहाय्य आणि समर्थन',
    history: 'इतिहास',
    postLead: 'लीड पोस्ट करा',
    myLeads: 'माझे लीड्स',
    name: 'नाव',
    phone: 'फोन',
    email: 'ईमेल',
    gender: 'लिंग',
    budniessAddress: 'व्यवसाय पत्ता',
    savedetails: 'तपशील साठवा',
    logout: 'लॉगआउट',
    helpandsupport: 'सहाय्य आणि समर्थन',
    sendMessage: 'संदेश पाठवा',
    howcanweAssit: 'आम्ही आपली कसे मदत करू शकतो',
    typeQuery: 'प्रश्न टाइप करा',
    active: 'सक्रिय',
    completed: 'पूर्ण',
    Login: 'लॉगिन करा',
    PersonDetails: 'व्यक्तीचे तपशील',
    firstname: 'पहिले नाव',
    surname: 'आडनाव',
    male: 'पुरुष',
    female: 'स्त्री',
    profileImage: 'प्रोफाइल चित्र',
    capture: 'कॅप्चर करा',
    contine: 'सुरू ठेवा',
    cancle: 'रद्द करा',
    busniessname: 'व्यवसाय नाव',
    category: 'वर्ग',
    license: 'परवाना',
    document: 'दस्तऐवज'
  };
}
