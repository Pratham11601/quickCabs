import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled/Constants/contants.dart';
import 'package:untitled/Localization/locals.dart';
import 'package:untitled/Screens/AppFeatures.dart';
import 'package:untitled/Screens/homeScreen.dart';
import 'package:untitled/Screens/login_page.dart';
import 'package:untitled/Screens/no_internet_page.dart';
import 'package:untitled/Screens/splashhScreen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final FlutterLocalization localization = FlutterLocalization.instance;

  @override
  void initState() {
    super.initState();
    configureLocalization();
  }

  void configureLocalization() {
    localization.init(mapLocales: LOCALE, initLanguageCode: "eng");
    localization.onTranslatedLanguage = onTranslatedLanguage;
  }

  void onTranslatedLanguage(Locale? locale) {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quick Cab',
      theme: ThemeData(primarySwatch: Colors.orange, canvasColor: Colors.grey),
      supportedLocales: localization.supportedLocales,
      localizationsDelegates: localization.localizationsDelegates,
      home: FutureBuilder<bool>(
        future: isLoggedIn(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator();
          } else {
            if (snapshot.data == true) {
              return FutureBuilder<bool>(
                future: Constants().checkInternetConnection(),
                builder: (context, internetSnapshot) {
                  if (internetSnapshot.connectionState == ConnectionState.waiting) {
                    return CircularProgressIndicator();
                  } else {
                    return internetSnapshot.data == true ? SplashScreen() : NoInternetPage();
                  }
                },
              );
            } else {
              return Features();
            }
          }
        },
      ),
    );
  }


  Future<bool> isLoggedIn() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('token') != null;
  }
}

