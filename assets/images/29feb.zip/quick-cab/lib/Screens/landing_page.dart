import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import '../Controllers/home_page_controller.dart';
import '../generated/assets.dart';


class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

List<String> tabIcons = [
  Assets.imagesCabImage,
  Assets.imagesTowingRb,
  Assets.imagesPunctureRb,
  Assets.imagesCarRepairingRb,
  Assets.imagesDriverRb,
  Assets.imagesFuelsRb,
  Assets.imagesRestuarantRb,
  Assets.imagesHospitalsRb,
];

List<String> title = [
  "CAB",
  "TOWING",
  "PUNCTURE",
  "REPAIRING",
  "DRIVERS",
  "FUEL",
  "RESTAURANTS",
  "EMERGENCY",
];

class _LandingPageState extends State<LandingPage> {

  @override
  Widget build(BuildContext context) {

    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    final HomeController controller = Get.put(HomeController());
    RxMap userData = controller.userData;
    return Scaffold(
      body: Expanded(
        child: Padding(
          padding: EdgeInsets.only(bottom: height * 0.018),
          child: GridView.builder(
            gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: width / 1.97,
              childAspectRatio: 1.9 / 1.5,
              crossAxisSpacing: 1,
              mainAxisSpacing: 35,
            ),
            itemCount: tabIcons.length,
            itemBuilder: (BuildContext context, index) {
              return InkWell(
                onTap: () {
                  controller.navigateToTab(index);
                },
                child: Padding(
                  padding: EdgeInsets.symmetric(
                      horizontal: height * 0.015, vertical: 5),
                  child: Container(
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.white,
                          spreadRadius: 0,
                          blurRadius: 0,
                          offset: Offset(-0, -0),
                        ),
                        BoxShadow(
                          color: Colors.orangeAccent,
                          spreadRadius: 2,
                          blurRadius: 1,
                          offset: Offset(1, 2),
                        ),
                      ],
                      borderRadius: BorderRadius.circular(22),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Expanded(
                          child: Image.asset(
                            tabIcons[index],
                            fit: BoxFit.fill,
                          ),
                        ),
                        Text(
                          title[index],
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            fontFamily: "menu",
                            color: Colors.black,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),


    );
  }
}
