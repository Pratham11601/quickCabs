
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:otpless_flutter/otpless_flutter.dart';
import 'package:untitled/Constants/contants.dart';
import 'package:untitled/Screens/otp_verification.dart';
import '../Controllers/registration_page_controller.dart';
import '../generated/assets.dart';
import '../services/ApiServices.dart';
import 'login_page.dart';

class RegistrationsPage extends StatefulWidget {
  const RegistrationsPage({Key? key}) : super(key: key);

  @override
  State<RegistrationsPage> createState() => _RegistrationsPageState();
}

class _RegistrationsPageState extends State<RegistrationsPage> {



  Future<void> _checkPhoneNumberExistence() async {

    String? token;

    ///Define the instance
    final _otplessFlutterPlugin = Otpless();
    var extra = {
      "method": "get",
      "params": {
        "cid":
        "HRIRBIIKXMKEOTDDA8VV4HP2V24454X8", //Replace the cid value with your CID value which is provided in the docs
        "crossButtonHidden": "true",
      },
    };



    Future<void> startOtpless() async {
      await _otplessFlutterPlugin.hideFabButton();
      _otplessFlutterPlugin.openLoginPage((result) {
        if (result['data'] != null) {
          // todo send this token to your backend service to validate otplessUser details received in the callback with OTPless backend service
          token = result['data']['token'];
          setState(() {});
        }
      }, jsonObject: extra);
    }


    @override
    void initState() {
      super.initState();



      _otplessFlutterPlugin.isWhatsAppInstalled().then(
            (value) {
          if (!value) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: const Text("Please install the whatsapp"),
                backgroundColor: Theme.of(context).hoverColor,
              ),
            );
          } else {
            startOtpless();
          }
        },
      );


    }



    final phoneNumber = _phoneController.text;

    try {
      final Map<String, dynamic> result = await ApiService().checkPhoneNumberExistence(phoneNumber,context);

      if (result['exists']) {
        print('Phone number already exists. Please use a different number.');
      } else {
        Get.to(VerifyOtp(password: _passwordController.text ,phone: _phoneController.text));
      }
    } catch (error) {
      print('Error checking phone number existence: $error');
    }
  }

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final RegistrationController registrationController =
      Get.put(RegistrationController());
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  bool _isPasswordVisible = false;

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;

    return Scaffold(
      body: Container(
        color: Colors.orange,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Column(
              children: [
                SizedBox(height: height * 0.1),
                Container(
                  height: height * 0.125,
                  width: height * 0.135,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(26),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Image.asset(Assets.imagesAppiconfinal, fit: BoxFit.cover,),
                    ),
                  ),
                ),
                SizedBox(
                  height: height *0.005,
                ),
              ],
            ),
            const SizedBox(
              height: 55,
            ),
            Expanded(
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(45)),
                ),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formKey,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: height * 0.02,
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 28),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Create New Account",
                                style: TextStyle(
                                    fontWeight: FontWeight.w800, fontSize: 25),
                              ),
                              Text(
                                "Fill in the details below to get started with us.",
                                style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 15,
                                    color: Colors.blue),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: height * 0.062,
                        ),
                        Center(
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width * 0.8,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const SizedBox(
                                  height: 20,
                                ),
                                const SizedBox(height: 10),
                                TextFormField(
                                  controller: _phoneController,
                                  decoration: const InputDecoration(
                                    labelText: 'Phone',
                                    border: OutlineInputBorder(),
                                    prefixIcon: Icon(Icons.phone),
                                  ),
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Please enter your Phone Number';
                                    } else if (!RegExp(r'^[0-9]+$')
                                        .hasMatch(value)) {
                                      return 'Please enter a valid phone address';
                                    }
                                    return null;
                                  },
                                ),
                                const SizedBox(
                                  height: 10,
                                ),
                                TextFormField(
                                  controller: _passwordController,
                                  obscureText: !_isPasswordVisible,
                                  decoration: InputDecoration(
                                    labelText: 'Password',
                                    border: const OutlineInputBorder(),
                                    prefixIcon: const Icon(Icons.lock),
                                    suffixIcon: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          _isPasswordVisible =
                                              !_isPasswordVisible;
                                        });
                                      },
                                      child: Icon(
                                        _isPasswordVisible
                                            ? Icons.visibility
                                            : Icons.visibility_off,
                                      ),
                                    ),
                                  ),
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Please enter your password';
                                    } else if (value.length < 6) {
                                      return 'Password must be at least 6 characters';
                                    }
                                    return null;
                                  },
                                ),
                                const SizedBox(height: 10),
                                TextFormField(
                                  controller: _confirmPasswordController,
                                  obscureText: !_isPasswordVisible,
                                  decoration: InputDecoration(
                                    labelText: 'Confirm Password',
                                    border: const OutlineInputBorder(),
                                    prefixIcon: const Icon(Icons.lock),
                                    suffixIcon: GestureDetector(
                                      onTap: () {
                                        setState(() {
                                          _isPasswordVisible =
                                              !_isPasswordVisible;
                                        });
                                      },
                                      child: Icon(
                                        _isPasswordVisible
                                            ? Icons.visibility
                                            : Icons.visibility_off,
                                      ),
                                    ),
                                  ),
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Please confirm your password';
                                    } else if (value !=
                                        _passwordController.text) {
                                      return 'Password do not match';
                                    }
                                    return null;
                                  },
                                ),
                                SizedBox(
                                  height: height * 0.029,
                                ),
                                MaterialButton(
                                  child:  Container(
                                      height: height*0.059,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(22),
                                          gradient: const LinearGradient(
                                              colors: [Colors.orange, Colors.orange,
                                                Colors.orange, Colors.deepOrange])),
                                      child: Center(
                                        child: Text(
                                            'Sign In',
                                          style: const TextStyle(
                                              fontSize: 24,
                                              color: Colors.white,
                                              fontWeight: FontWeight.w700),
                                        ),
                                      )),
                                  onPressed: () async {
                                    if (_formKey.currentState?.validate() ?? false) {
                                      await _checkPhoneNumberExistence();

                                    } else {
                                      debugPrint("Validation failed");

                                    }
                                  },
                                ),
                                SizedBox(
                                  height: height*0.06,
                                ),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.push(context, MaterialPageRoute(builder: (context) => const LoginPage()),
                                    );
                                  },
                                  child: RichText(
                                    text: TextSpan(
                                      text: "",
                                      children: <TextSpan>[
                                        const TextSpan(
                                          text: 'Already a User!',
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16,
                                          ),
                                        ),
                                        TextSpan(
                                          text: ' Log in',
                                          style: TextStyle(
                                            color: Colors.blue.shade800,
                                            fontWeight: FontWeight.w800,
                                            fontSize: 16.2,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
