import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:untitled/Constants/contants.dart';
import 'package:untitled/Screens/homeScreen.dart';
import '../generated/assets.dart';

class NoInternetPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Text(Constants.appName,style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w700
        ),),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset(Assets.animationsNoInternet,height: height * 0.6),
            Text(
              '  Please check your internet connection!  ',
              style: TextStyle(
                  fontSize: height * 0.032),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: height *0.04,
            ),
            MaterialButton(
              onPressed: () async {
                var connectivityResult = await Connectivity().checkConnectivity();
                if (connectivityResult != ConnectivityResult.none) {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => HomePage()),
                  );
                }
              },
              child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.grey.shade300,Colors.grey.shade300,]
                    ),
                    borderRadius: BorderRadius.circular(6)
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Retry',style: TextStyle(
                        fontSize: height * 0.028,
                    ),),
                  )),
            )
          ],
        ),
      ),
    );
  }
}
