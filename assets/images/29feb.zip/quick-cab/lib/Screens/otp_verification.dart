import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/get_navigation.dart';
import 'package:untitled/Screens/kyc_page.dart';
import '../Widgets/custom_button_orange.dart';

class VerifyOtp extends StatefulWidget {
  String password;
  String phone;
  VerifyOtp({required this.password,required this.phone, Key? key}) : super(key: key);

  @override
  State<VerifyOtp> createState() => _VerifyOtpState();
}





class _VerifyOtpState extends State<VerifyOtp> {
  late List<TextEditingController> _controllers;

  @override
  void initState() {
    super.initState();
    // Initialize _controllers
    _controllers = List.generate(4, (_) => TextEditingController());
  }

  @override
  void dispose() {
    // Dispose the controllers
    for (var controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    print(widget.password);

    double height = MediaQuery
        .of(context)
        .size
        .height;
    return Scaffold(
        body: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  height:height*0.1,
                ),
                typography(),
                SizedBox(
                  height: 30,
                ),
                Form(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.orange.shade50,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(width: 2, color: Colors.orange)),
                        height: 65,
                        width: 65,
                        child: TextFormField(
                          onChanged: (value) {
                            if (value.length == 1) {
                              FocusScope.of(context).nextFocus();
                            }
                          },
                          textAlign: TextAlign.center,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                          ),
                          style: Theme
                              .of(context)
                              .textTheme
                              .headline5,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(1),
                            FilteringTextInputFormatter.digitsOnly
                          ],
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.orange.shade50,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(width: 2, color: Colors.orange)),
                        height: 65,
                        width: 65,
                        child: TextFormField(
                          onChanged: (value) {
                            if (value.length == 1) {
                              FocusScope.of(context).nextFocus();
                            }
                          },
                          textAlign: TextAlign.center,
                          decoration: InputDecoration(
                            border: InputBorder.none,
                          ),
                          style: Theme
                              .of(context)
                              .textTheme
                              .headline5,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(1),
                            FilteringTextInputFormatter.digitsOnly
                          ],
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.orange.shade50,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(width: 2, color: Colors.orange)),
                        height: 65,
                        width: 65,
                        child: TextFormField(
                          onChanged: (value) {
                            if (value.length == 1) {
                              FocusScope.of(context).nextFocus();
                            }
                          },
                          textAlign: TextAlign.center,
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                          ),
                          style: Theme
                              .of(context)
                              .textTheme
                              .headline5,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(1),
                            FilteringTextInputFormatter.digitsOnly
                          ],
                        ),
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: Colors.orange.shade50,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(width: 2, color: Colors.orange)),
                        height: 65,
                        width: 65,
                        child: TextFormField(
                          onChanged: (value) {
                            if (value.length == 1) {
                              FocusScope.of(context).nextFocus();
                            }
                          },
                          textAlign: TextAlign.center,
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                          ),
                          style: Theme
                              .of(context)
                              .textTheme
                              .headline5,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(1),
                            FilteringTextInputFormatter.digitsOnly
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 27, top: 10,right: 27),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      InkWell(
                        onTap: () {
                          debugPrint("Gen");
                        },
                        child:  Text(
                          "Resend the code",
                          style: TextStyle(
                              color: Colors.blue,
                              fontSize: height* 0.022,


                          ),
                        ),
                      ),

                    ],
                  ),
                ),
                Expanded(
                  child: SizedBox(),
                ),
                CustomButton("Verify", height * 0.07, onPressed: () {
                  String otp = '';
                  for (TextEditingController controller in _controllers) {
                    otp += controller.text;
                  }
                  // Print the OTP
                  print('Entered OTP: $otp');

                  print("hello");
                  Get.to(KYCPage(password: widget.password,phone:  widget.phone ));
                }),
                SizedBox(
                  height: 40,
                ),
              ],
            )));
  }

  Widget typography() {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 17.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Verify Code",
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 25),
          ),
          Text(
            "We have sent 4-digit code to your number",
          ),
        ],
      ),
    );
  }
}
