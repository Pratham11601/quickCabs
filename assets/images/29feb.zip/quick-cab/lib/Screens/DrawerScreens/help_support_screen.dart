import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:untitled/services/ApiServices.dart';

import '../../Constants/contants.dart';
import '../../Controllers/home_page_controller.dart';
import '../../Localization/locals.dart';
import '../../Widgets/custom_button_orange.dart';
import '../no_internet_page.dart';

class HelpAndSupportPage extends StatefulWidget {
  @override
  _HelpAndSupportPageState createState() => _HelpAndSupportPageState();
}

class _HelpAndSupportPageState extends State<HelpAndSupportPage> {
  TextEditingController _queryController = TextEditingController();

  @override
  void initState() {
    super.initState();
    checkInternetAndFetchDetails();
    ApiService().getUserDataFromToken();
  }


  Future<void> checkInternetAndFetchDetails() async {
    bool isConnected = await Constants().checkInternetConnection();

    if (isConnected) {

    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => NoInternetPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    final HomeController controller = Get.put(HomeController());
    RxMap userData = controller.userData;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          LocalData.helpAndSupport.getString(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              LocalData.howcanweAssit.getString(context),
              style: TextStyle(
                fontSize: height * 0.027,
              ),
            ),
            SizedBox(height: 20),
            TextField(
              controller: _queryController,
              decoration: InputDecoration(
                labelText:
                LocalData.typeQuery.getString(context),
                border: OutlineInputBorder(),
              ),
              maxLines: 5,
            ),
            SizedBox(height: 20),
            CustomButton(
              LocalData.sendMessage.getString(context),
              height * 0.060,
              onPressed: () {
                print(userData['userId']);

                ApiService().help_support_send(
                    _queryController.text,
                    userData['userId'],
                    userData['fullname'],
                    userData['vendor_cat'],
                    userData['phone'].toString());

              },
            ),
            SizedBox(
              height: height * 0.02,
            ),
          ],
        ),
      ),
    );
  }
}
