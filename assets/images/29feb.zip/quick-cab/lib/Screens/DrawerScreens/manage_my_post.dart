import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:untitled/Screens/no_internet_page.dart';
import 'package:http/http.dart' as http;
import '../../Constants/contants.dart';
import '../../Controllers/CabLeadController.dart';
import '../../Controllers/home_page_controller.dart';
import '../../Widgets/EditPostDialog.dart';
import '../../Widgets/loadingShimer.dart';


import '../../models/leadss.dart';


class ManageMyPost extends StatefulWidget {
  final String id;
  final String Vendor_cat;

  const ManageMyPost({required this.id, super.key, required this.Vendor_cat});

  @override
  State<ManageMyPost> createState() => _ManageMyPostState();
}

class _ManageMyPostState extends State<ManageMyPost> {
  late final LeadsController _leadsController;
  final String apiUrl = 'http://10.0.2.2:3000/posts/all';
  late ScrollController _scrollController;
  late List<Lead> _leads;
  bool _isLoading = false;
  int _currentPage = 1;
  Constants constant = Constants();

  @override
  void initState() {
    super.initState();
    _leads = [];
    _scrollController = ScrollController()..addListener(_scrollListener);
    _fetchLeads();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _fetchLeads();
    }
  }

  Future<void> _fetchLeads() async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    final response = await http.get(Uri.parse('$apiUrl?page=$_currentPage'));

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      final leadsResponse = LeadsResponse.fromJson(jsonData);

      setState(() {
        final filteredLeads = leadsResponse.leads.where((lead) => lead.vendorId == int.parse(widget.id)).toList();
        _leads.addAll(filteredLeads);
        _leads.sort((a, b) => b.createdAt.compareTo(a.createdAt));
        _currentPage++;
        _isLoading = false;
      });

    } else {
      throw Exception('Failed to load leads');
    }
  }

  Future<void> _refreshLeads() async {
    _currentPage = 1;
    _leads.clear();
    await _fetchLeads();
  }

  Future<void> checkInternetAndFetchDetails() async {
    bool isConnected = await Constants().checkInternetConnection();

    if (isConnected) {

    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => NoInternetPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    setState(() {

    });
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Edit My Lead",
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _refreshLeads,
        child: ListView.builder(
          controller: _scrollController,
          itemCount: _leads.length + (_isLoading ? 1 : 0),
          itemBuilder: (context, index) {
            if (index < _leads.length) {
              final lead = _leads[index];
              var leadDate;
              return
                Padding(
                  padding: EdgeInsets.symmetric(
                      vertical: height * 0.002,
                      horizontal: height * 0.00709),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius:
                      BorderRadius.circular(8),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.blueGrey,
                          spreadRadius: 1,
                          blurRadius: 2,
                          offset: Offset(2, 3),
                        ),
                      ],
                    ),
                    child: Container(
                      decoration: const BoxDecoration(
                          gradient: LinearGradient(colors: [
                            Colors.white10,
                            Colors.white24,
                            Color(0xFFEAEAEA),
                          ])),
                      width: double.maxFinite,
                      child: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                                left: 10.0,
                                top: 4,
                                bottom: 4),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Row(
                                    crossAxisAlignment:
                                    CrossAxisAlignment
                                        .start,
                                    mainAxisAlignment:
                                    MainAxisAlignment
                                        .spaceBetween,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment
                                            .start,
                                        mainAxisAlignment:
                                        MainAxisAlignment
                                            .spaceEvenly,
                                        children: [
                                          Text(
                                            " From ${lead.locationFrom} to "
                                                " ${lead.toLocation}  ",
                                            style: TextStyle(
                                                color: Colors
                                                    .grey
                                                    .shade700,
                                                fontWeight:
                                                FontWeight
                                                    .w700,
                                                fontSize:
                                                height *
                                                    0.016),
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .end,
                                            children: [
                                              Icon(
                                                Icons
                                                    .calendar_month,
                                                size: height *
                                                    0.022,
                                              ),
                                              Text(
                                                ' ${DateFormat('dd').format(leadDate ?? DateTime.now())}/${DateFormat('MM').format(leadDate ?? DateTime.now())}/${DateFormat('yyyy').format(leadDate ?? DateTime.now())}',
                                                style: TextStyle(
                                                    fontSize:
                                                    height *
                                                        0.0167,
                                                    fontFamily:
                                                    'heading'),
                                              ),
                                              SizedBox(
                                                width:
                                                height *
                                                    0.028,
                                              ),
                                              Icon(
                                                Icons
                                                    .watch_later_outlined,
                                                size: height *
                                                    0.022,
                                              ),
                                              Text(
                                                  '${lead.time}')
                                            ],
                                          ),
                                          Text(lead
                                              .isActive!
                                              ? "(Active)"
                                              : "(Completed)")
                                        ],
                                      ),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              '(${formatTimeAgo(lead.createdAt)} )  ',
                                              style: TextStyle(
                                                  fontSize: height * 0.015),
                                            ),
                                            SizedBox(
                                              height: height * 0.010,
                                            ),
                                            Visibility(
                                              visible: lead.isActive! ? true : false,
                                              child: InkWell(
                                                onTap: () {
                                                  print("hitted edit Option");
                                                  showDialog(
                                                    context:
                                                    context,
                                                    builder:
                                                        (context) {
                                                      return EditPostDialog(
                                                        post: lead,
                                                      );
                                                    },
                                                  );
                                                },
                                                child: Padding(padding: const EdgeInsets.only(right: 18.0),
                                                  child: Icon(
                                                      Icons.edit,
                                                      size: height * 0.028),
                                                ),
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );

            } else {
              return  Padding(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                child: Center(
                  child:LoadingWidget(height,width),
                ),
              );
            }
          },
        ),
      ),
    );
  }
  String capitalize(String input) {
    if (input.isEmpty) {
      return input;
    }
    return input[0].toUpperCase() + input.substring(1);
  }

  String formatTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes} mins ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} hours ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return 'on ${dateTime.day}/${dateTime.month}/${dateTime.year}';
    }
  }
}
