import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:intl/intl.dart';
import 'package:untitled/Localization/locals.dart';
import '../../Constants/contants.dart';
import '../../Widgets/loadingShimer.dart';
import '../../models/leadss.dart';
import '../no_internet_page.dart';
import 'package:http/http.dart' as http;

class HistoryTab extends StatefulWidget {
  const HistoryTab({super.key});

  @override
  State<HistoryTab> createState() => _HistoryTabState();
}

class _HistoryTabState extends State<HistoryTab> {
  final String apiUrl = 'http://10.0.2.2:3000/posts/history';
  late ScrollController _scrollController;
  late List<Lead> _leads;
  bool _isLoading = false;
  int _currentPage = 1;

  Constants constant = Constants();

  @override
  void initState() {
    super.initState();
    _leads = [];
    _scrollController = ScrollController()..addListener(_scrollListener);
    _fetchLeads();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _fetchLeads();
    }
  }

  Future<void> _fetchLeads() async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    final response = await http.get(Uri.parse('$apiUrl?page=$_currentPage'));

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      final leadsResponse = LeadsResponse.fromJson(jsonData);

      setState(() {
        List<Lead> tempLeads = leadsResponse.leads;

        tempLeads.sort((a, b) => b.createdAt.compareTo(a.createdAt));

        _leads.addAll(tempLeads);

        _currentPage++;
        _isLoading = false;
      });
    } else {
      throw Exception('Failed to load leads');
    }
  }

  Future<void> _refreshLeads() async {
    _currentPage = 1;
    _leads.clear();
    await _fetchLeads();
  }



  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    var leadDate;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          LocalData.leadsHistory.getString(context),
          style: TextStyle(
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _refreshLeads,
        child: ListView.builder(
          controller: _scrollController,
          itemCount: _leads.length + (_isLoading ? 1 : 0),
          itemBuilder: (context, index) {
            if (index < _leads.length) {
              final lead = _leads[index];
              return Padding(
                padding: EdgeInsets.symmetric(
                    vertical: height * 00.0025, horizontal: width * 0.009),
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.grey,
                        spreadRadius: 1,
                        blurRadius: 2,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 5.0),
                    child: Container(
                      decoration: const BoxDecoration(
                          gradient: LinearGradient(colors: [
                        Colors.white10,
                        Colors.white10,
                        Colors.white24,
                        Colors.white24,
                        Colors.white24,
                      ])),
                      width: double.maxFinite,
                      child: Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.only(
                                left: width * 0.00, bottom: height * 0.002),
                            child: Row(
                              children: [
                                Expanded(
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceEvenly,
                                        children: [
                                          SizedBox(
                                            height: height * 0.008,
                                          ),
                                          Text(
                                            " Posted By: ${capitalize(lead.vendorName.toString())}",
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontWeight: FontWeight.w700,
                                                fontSize: height * 0.019),
                                          ),
                                          Row(
                                            children: [
                                              Text(
                                                LocalData.from
                                                    .getString(context),
                                                style: TextStyle(
                                                    fontFamily: 'from_to',
                                                    color: Colors.grey.shade700,
                                                    fontWeight: FontWeight.w500,
                                                    fontSize: height * 0.016),
                                              ),
                                              Text(
                                                " ${lead.locationFrom} ",
                                                style: TextStyle(
                                                    fontFamily: 'from_to',
                                                    color: Colors.grey.shade700,
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: height * 0.016),
                                              ),
                                              Text(
                                                LocalData.to.getString(context),
                                                style: TextStyle(
                                                    fontFamily: 'from_to',
                                                    color: Colors.grey.shade700,
                                                    fontWeight: FontWeight.w600,
                                                    fontSize: height * 0.016),
                                              ),
                                              Text(
                                                "${lead.toLocation}",
                                                style: TextStyle(
                                                    fontFamily: 'from_to',
                                                    color: Colors.grey.shade700,
                                                    fontWeight: FontWeight.w700,
                                                    fontSize: height * 0.016),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              Icon(
                                                Icons.calendar_month,
                                                size: height * 0.022,
                                              ),
                                              Text(
                                                ' ${DateFormat('dd').format(leadDate ?? DateTime.now())}/${DateFormat('MM').format(leadDate ?? DateTime.now())}/${DateFormat('yyyy').format(leadDate ?? DateTime.now())}',
                                                style: TextStyle(
                                                    fontSize: height * 0.0167,
                                                    fontFamily: 'heading'),
                                              ),
                                              SizedBox(
                                                width: height * 0.038,
                                              ),
                                              Icon(
                                                Icons.watch_later_outlined,
                                                size: height * 0.022,
                                              ),
                                              Text('${lead.time}')
                                            ],
                                          ),
                                          SizedBox()
                                        ],
                                      ),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              '(${formatTimeAgo(lead.createdAt)} )  ',
                                              style: TextStyle(
                                                  fontSize: height * 0.015),
                                            ),
                                            SizedBox(
                                              height: height * 0.00015,
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                  right: height * 0.020),
                                              child: Column(
                                                children: [
                                                  Icon(Icons.done,
                                                      color: Colors.green,
                                                      size: height * 0.035),
                                                  Text("Completed")
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            } else {
              return Padding(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                child: Center(
                  child: LoadingWidget(height, width),
                ),
              );
            }
          },
        ),
      ),
    );
  }

  Future<void> checkInternetAndFetchDetails() async {
    bool isConnected = await Constants().checkInternetConnection();

    if (isConnected) {
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => NoInternetPage()),
      );
    }
  }

  String formatTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes} mins ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} hours ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return 'on ${dateTime.day}/${dateTime.month}/${dateTime.year}';
    }
  }

  String capitalize(String input) {
    if (input.isEmpty) {
      return input;
    }
    return input[0].toUpperCase() + input.substring(1);
  }
}
