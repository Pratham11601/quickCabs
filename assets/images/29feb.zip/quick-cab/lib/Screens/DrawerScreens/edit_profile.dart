import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:get/get.dart';
import 'package:untitled/Widgets/textField_myprofile.dart';
import '../../Constants/contants.dart';
import '../../Controllers/home_page_controller.dart';
import '../../Localization/locals.dart';
import '../../Widgets/custom_button_orange.dart';
import 'package:path/path.dart' as path;
import '../../services/ApiServices.dart';
import 'package:http/http.dart' as http;

import '../no_internet_page.dart';


class EditProfile extends StatefulWidget {
  final userId;
   EditProfile({Key? key,required this.userId}) : super(key: key);

  @override
  State<EditProfile> createState() => _EditProfileState();
}

var client = http.Client();
var APIUrl = "http://10.0.2.2:3000";

class _EditProfileState extends State<EditProfile> {
  TextEditingController _nameController = TextEditingController();
  TextEditingController _phoneController = TextEditingController();
  TextEditingController _emailController = TextEditingController();
  TextEditingController _currentAddressController = TextEditingController();
  TextEditingController _permanentAddressController = TextEditingController();
  TextEditingController _genderController = TextEditingController();
  // Declare the class-level variable
  late String relativePath = '' ;
  late String VendorCat = '' ;



  @override
  void initState() {
    super.initState();
    fetchVendorDetails();
    checkInternetAndFetchDetails();
  }

  Future<void> checkInternetAndFetchDetails() async {
    bool isConnected = await Constants().checkInternetConnection();

    if (isConnected) {

    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => NoInternetPage()),
      );
    }
  }

  Future<void> fetchVendorDetails() async {
    try {
      final response = await http.post(
        Uri.parse('http://10.0.2.2:3000/vendorDetails/get/${widget.userId}'),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body)['vendor'];
        setState(() {
          _nameController.text = data['fullname'];
          _phoneController.text = data['phone'];
          _emailController.text = data['email'];
          _currentAddressController.text = data['currentAddress'];
          _permanentAddressController.text = data['permenantAddress'];
          _genderController.text = data['vendor_gender'];
          VendorCat =  data['vendor_cat'];


          var imagePath = data['profileImgUrl'];
          relativePath = path.relative(imagePath, from: 'uploads');

          print("This is my image $relativePath");

          var image = data['profileImgUrl'];
          print("This is my image $image");
        });
      } else {
        print('Error fetching vendor details: ${response.statusCode}');
      }
    } catch (error) {
      print('Error fetching vendor details: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    final HomeController controller = Get.put(HomeController());
    RxMap userData = controller.userData;
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          LocalData.editProfile.getString(context),
          style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.w600
        ),),
        backgroundColor: Colors.orange,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.orange,
                borderRadius: BorderRadius.vertical(
                    bottom: Radius.circular(height * 0.050)),
              ),
              height: height * 0.34,
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Center(
                      child:
                      ClipOval(
                        child: Image.network(
                          '$APIUrl/$relativePath',
                          fit: BoxFit.fitWidth,
                          height: height * 0.2,
                          width: height * 0.2,
                          errorBuilder: (BuildContext context, Object error, StackTrace? stackTrace) {
                            print('Error loading image: $error');
                            return Center(
                              child: CircularProgressIndicator(),
                            );
                          },
                          loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                            if (loadingProgress == null) {
                              return child;
                            } else {
                              return Center(
                                child: CircularProgressIndicator(
                                  value: loadingProgress.expectedTotalBytes != null
                                      ? loadingProgress.cumulativeBytesLoaded / max(1, loadingProgress.expectedTotalBytes ?? 0)
                                      : null,
                                ),
                              );
                            }
                          },
                        ),
                      ),

                    ),
                    SizedBox(
                      height: height * 0.019,
                    ),
                    Text(
                      _nameController.text,
                      style: TextStyle(
                          color: Colors.white,
                          fontFamily: 's',
                          letterSpacing: 3,
                          fontSize: height * 0.035,
                          fontWeight: FontWeight.bold),
                    ),
                    Text(
                      "($VendorCat-Vendor)" ,
                      style:  TextStyle(
                          color: Colors.white,
                          fontSize: height * 000.030,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
            ),


             Padding(
              padding: EdgeInsets.symmetric(horizontal: height * 0.030, vertical: height *0.025),
              child: Text(
                LocalData.accountDetails.getString(context),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
                textAlign: TextAlign.start,
              ),
            ),

            buildEditableTextField(
              icon: Icons.person,
              title: LocalData.name.getString(context),
              controller: _nameController,
              enabled: false,
            ),
            Divider(),
            buildEditableTextField(
              icon: Icons.phone,
              title: LocalData.phone.getString(context),
              controller: _phoneController,
              enabled: false,
            ),
         Divider(),
            buildEditableTextField(
              icon: Icons.email,
              title:LocalData.email.getString(context),
              controller: _emailController,
            ),
            Divider(),

            buildEditableTextField(
              icon: Icons.location_city,
              title: LocalData.gender.getString(context),
              controller: _genderController,
              enabled: false,
            ),
            Divider(),
            buildEditableTextField(
              icon: Icons.location_city,
              title: LocalData.budniessAddress.getString(context),
              controller: _permanentAddressController,
              enabled: false,
            ),

            SizedBox(
              height: height *00.05,
            ),

            CustomButton(
              LocalData.savedetails.getString(context),
              height * 00.070,
              onPressed: () {
                saveUserData();
              },
            ),
            SizedBox(
              height: height *00.05,
            ),

          ],
        ),
      ),
    );
  }

  void saveUserData() async {
    try {
      await ApiService().updateUserData(
        _emailController.text,
        _currentAddressController.text,
      );

      Get.snackbar(
        'Details Saved',
        'User details updated successfully.',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } catch (error) {
      print('Error saving user data: $error');
      Get.snackbar(
        'Failed to Save Details',
        'Error saving user details.',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }
}
