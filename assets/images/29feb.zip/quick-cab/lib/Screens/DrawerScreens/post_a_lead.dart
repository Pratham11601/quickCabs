import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:intl/intl.dart';
import 'package:untitled/Localization/locals.dart';
import 'package:untitled/Screens/homeScreen.dart';
import 'package:untitled/services/ApiServices.dart';
import 'package:csc_picker/csc_picker.dart';
import '../../Constants/contants.dart';
import '../../Controllers/home_page_controller.dart';
import '../no_internet_page.dart';

class PostLead extends StatefulWidget {
  const PostLead({super.key});

  @override
  State<PostLead> createState() => _PostLeadState();
}

class _PostLeadState extends State<PostLead> {
  final HomeController controller = Get.put(HomeController());

  String countryValue = "";
  String stateValue = "";
  String cityValueFrom = "";

  String countryValueto = "";
  String stateValueto = "";
  String cityValueTO = "";

  DateTime _selectedDate = DateTime.now();
  TimeOfDay _selectedTime = TimeOfDay.now();



  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),

      locale: const Locale('en', 'US'),
    );
    if (picked != null && picked != _selectedDate)
      setState(() {
        _selectedDate = picked;
      });
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: _selectedTime,
      // Set the locale explicitly to English (United States)
      builder: (BuildContext context, Widget? child) {
        return MediaQuery(
          data: MediaQuery.of(context).copyWith(alwaysUse24HourFormat: false),
          child: Localizations.override(
            context: context,
            locale: const Locale('en', 'US'),
            child: child!,
          ),
        );
      },
    );
    if (picked != null && picked != _selectedTime)
      setState(() {
        _selectedTime = picked;
      });
  }



  @override
  void initState() {
    checkInternetAndFetchDetails();
  }


  Future<void> checkInternetAndFetchDetails() async {
    bool isConnected = await Constants().checkInternetConnection();

    if (isConnected) {
      ApiService().getUserDataFromToken();
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => NoInternetPage()),
      );
    }
  }



  @override
  Widget build(BuildContext context) {
    RxMap userData = controller.userData;

    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        leading: InkWell(
            onTap: () {
              Get.to(HomePage());
            },
            child: Icon(Icons.arrow_back_ios)),

        title:  Text(
     LocalData.postNewLead.getString(context),
          style: TextStyle(fontWeight: FontWeight.w600),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              const Padding(
                padding: EdgeInsets.only(bottom: 19.0),
                child: Divider(),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(height *0.01))
                ),
                child: Padding(
                  padding:  EdgeInsets.all(height * 0.018),
                  child: Row(
                    children: [
                      Text(
                        "From ",
                        style: TextStyle(
                          fontSize: height * 0.027,
                        ),
                      ),
                      SizedBox(
                        width: height * 0.020,
                      ),
                      Expanded(
                        child: CSCPicker(
                          showStates: true,

                          showCities: true,

                          flagState: CountryFlag.DISABLE,

                          dropdownDecoration: BoxDecoration(
                              borderRadius: const BorderRadius.all(Radius.circular(10)),
                              color: Colors.white,
                              border:
                              Border.all(color: Colors.grey.shade300, width: 1)),

                          disabledDropdownDecoration: BoxDecoration(
                              borderRadius: const BorderRadius.all(Radius.circular(10)),
                              color: Colors.grey.shade300,
                              border:
                              Border.all(color: Colors.grey.shade300, width: 1)),

                          countrySearchPlaceholder: "Country",
                          stateSearchPlaceholder: "State",
                          citySearchPlaceholder: "City",

                          countryDropdownLabel: "*Country",
                          stateDropdownLabel: "*State",
                          cityDropdownLabel: "*City",

                          defaultCountry: CscCountry.India,

                          disableCountry: true,

                          selectedItemStyle: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                          ),

                          dropdownHeadingStyle: const TextStyle(
                              color: Colors.black,
                              fontSize: 17,
                              fontWeight: FontWeight.bold),

                          dropdownItemStyle: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                          ),

                          dropdownDialogRadius: 10.0,

                          searchBarRadius: 10.0,

                          onCountryChanged: (value) {
                            setState(() {
                              ///store value in country variable
                              countryValue = value;
                            });
                          },

                          ///triggers once state selected in dropdown
                          onStateChanged: (value) {
                            setState(() {
                              ///store value in state variable
                              // stateValue = value;
                            });
                          },

                          ///triggers once city selected in dropdown
                          onCityChanged: (value) {
                            setState(() {
                              ///store value in city variable
                              cityValueFrom = value ?? "no";
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                ),),
              SizedBox(height: height * 0.020),
              Container(
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.black,width: 1),
                    borderRadius: BorderRadius.all(Radius.circular(height *0.01))
                ),
                child: Padding(
                  padding:  EdgeInsets.all(height * 0.018),
                  child: Row(
                    children: [
                      Text(
                        "To ",
                        style: TextStyle(
                          fontSize: height * 0.027,
                        ),
                      ),
                      SizedBox(
                        width: height * 0.050,
                      ),
                      Expanded(
                        child: CSCPicker(
                          ///Enable disable state dropdown [OPTIONAL PARAMETER]
                          showStates: true,

                          /// Enable disable city drop down [OPTIONAL PARAMETER]
                          showCities: true,

                          ///Enable (get flag with country name) / Disable (Disable flag) / ShowInDropdownOnly (display flag in dropdown only) [OPTIONAL PARAMETER]
                          flagState: CountryFlag.DISABLE,

                          ///Dropdown box decoration to style your dropdown selector [OPTIONAL PARAMETER] (USE with disabledDropdownDecoration)
                          dropdownDecoration: BoxDecoration(
                              borderRadius: const BorderRadius.all(Radius.circular(10)),
                              color: Colors.white,
                              border:
                              Border.all(color: Colors.grey.shade300, width: 1)),

                          ///Disabled Dropdown box decoration to style your dropdown selector [OPTIONAL PARAMETER]  (USE with disabled dropdownDecoration)
                          disabledDropdownDecoration: BoxDecoration(
                              borderRadius: const BorderRadius.all(Radius.circular(10)),
                              color: Colors.grey.shade300,
                              border:
                              Border.all(color: Colors.grey.shade300, width: 1)),

                          ///placeholders for dropdown search field
                          countrySearchPlaceholder: "Country",
                          stateSearchPlaceholder: "State",
                          citySearchPlaceholder: "City",

                          ///labels for dropdown
                          countryDropdownLabel: "*Country",
                          stateDropdownLabel: "*State",
                          cityDropdownLabel: "*City",

                          ///Default Country
                          defaultCountry: CscCountry.India,

                          ///Disable country dropdown (Note: use it with default country)
                          disableCountry: true,

                          selectedItemStyle: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                          ),

                          dropdownHeadingStyle: const TextStyle(
                              color: Colors.black,
                              fontSize: 17,
                              fontWeight: FontWeight.bold),

                          dropdownItemStyle: const TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                          ),

                          ///Dialog box radius [OPTIONAL PARAMETER]
                          dropdownDialogRadius: 10.0,

                          ///Search bar radius [OPTIONAL PARAMETER]
                          searchBarRadius: 10.0,

                          ///triggers once country selected in dropdown
                          onCountryChanged: (value) {
                            setState(() {
                              ///store value in country variable
                              countryValue = value;
                            });
                          },

                          ///triggers once state selected in dropdown
                          onStateChanged: (value) {
                            setState(() {
                              ///store value in state variable
                              // stateValue = value;
                            });
                          },

                          ///triggers once city selected in dropdown
                          onCityChanged: (value) {
                            setState(() {
                              ///store value in city variable
                              cityValueTO = value ?? "null";
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 15),
              Row(
                children: [
                  Text(
                    LocalData.SelectDate.getString(context),
                    style: TextStyle(

                      fontSize: height * 0.025,
                    ),
                  ),
                  SizedBox(
                    width: height * 0.050,
                  ),

                  MaterialButton(
                    onPressed: () => _selectDate(context),
                    child: Row(
                      children: [
                        Icon(Icons.calendar_today),
                        Text(
                          ' ${DateFormat('dd/MM/yyyy').format(_selectedDate)}',
                          style: TextStyle(
                              fontWeight: FontWeight.w800, fontSize: height * 0.024),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),

                ],
              ),

              const SizedBox(height:  10),
              Row(
                children: [
                  Text(
                    LocalData.Selecttime.getString(context),
                    style: TextStyle(
                      fontSize: height * 0.025,
                    ),
                  ),
                  SizedBox(
                    width: height * 0.050,
                  ),
                  MaterialButton(
                    onPressed: () => _selectTime(context),
                    child: Row(
                      children: [
                        Icon(Icons.watch_later_outlined),
                        Text(
                          ' ${formatTimeOfDay(_selectedTime)}',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: height * 0.024,
                          ),
                        ),
                      ],
                    ),
                  ),


                ],
              ),
              Padding(
                padding:  EdgeInsets.only( top:  height *  0.02),
                child: MaterialButton(
                  onPressed: () {
                    print('this is my city   ${cityValueFrom}');
                    Map<String, dynamic> formData = {
                      "location_from": cityValueFrom,
                      "is_active": true,
                      "vendor_name": capitalizeFirstLetter(userData['fullname']),
                      "vendor_cat": userData['vendor_cat'],
                      "to_location": cityValueTO,
                      "date":
                      DateFormat('dd/MM/yyyy').format(_selectedDate).toString(),
                      "time":  formatTimeOfDay(_selectedTime),
                      "vendor_id": userData['userId'],
                      "vendor_contact": userData['phone'],
                    };
                    if (cityValueFrom != null &&
                        cityValueTO != "null" &&
                        cityValueFrom.isNotEmpty &&
                        cityValueTO.isNotEmpty) {
                      ApiService().postLead(
                          formData, userData['vendor_cat'], height * 0.06);
                    } else {
                      Get.snackbar("Error", " Please Enter All Your Data " ,icon: Icon(Icons.error,color: Colors.red,size: height * 0.040));
                    }
                    print('Form Data: $formData');
                  },
                  child: Center(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            colors: [ Colors.orange,Colors.orange,Colors.orange.shade700 ]
                        ),
                        borderRadius: BorderRadius.circular(height * 0.012),
                      ),
                      width: double.infinity,
                      height: height * 0.048,
                      child: Center(
                        child: Text(
                          LocalData.postNewLead.getString(context),
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: height * 0.030,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String capitalizeFirstLetter(String text) {
    if (text.isEmpty) return text;
    return text.substring(0, 1).toUpperCase() + text.substring(1);
  }

  String formatTimeOfDay(TimeOfDay timeOfDay) {
    final now = DateTime.now();
    final DateTime datetime = DateTime(now.year, now.month, now.day, timeOfDay.hour, timeOfDay.minute);
    return DateFormat.jm().format(datetime); // This formats the time as 'h:mm a'
  }

}
