import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:untitled/Localization/locals.dart';
import 'package:untitled/Screens/Tabs/CabLeadsList.dart';
import 'package:untitled/Screens/Tabs/trialtab/RefreshTab.dart';

import '../DrawerScreens/post_a_lead.dart';

class CabsTab extends StatefulWidget {
  const CabsTab({super.key});

  @override
  State<CabsTab> createState() => _CabsTabState();
}

class _CabsTabState extends State<CabsTab> {



  @override
  Widget build(BuildContext context) {

    var height = MediaQuery.of(context).size.height;

    return  Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,

        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
             Text(
             LocalData.CabServices.getString(context),
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
            ),
            InkWell(
                onTap: (){

                  Get.to(
                      PostLead()
                  );
                }               ,
                child: Icon(Icons.add_circle,color: Colors.white,size: height * 0.039,))
          ],
        ),
      ),
      body:  LeadpageScrollIndicatorPage() ,
    ) ;
  }
}
