import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';
import 'package:untitled/Localization/locals.dart';

import '../../../Constants/contants.dart';
import '../../../Widgets/loadingShimer.dart';
import '../../../generated/assets.dart';
import '../../../models/leadss.dart';
import '../../../services/ApiServices.dart';
import '../CabLeadsList.dart';


class LeadpageScrollIndicatorPage extends StatefulWidget {
  @override
  _LeadpageScrollIndicatorPageState createState() =>
      _LeadpageScrollIndicatorPageState();
}

class _LeadpageScrollIndicatorPageState
    extends State<LeadpageScrollIndicatorPage> {
  final String apiUrl = 'http://10.0.2.2:3000/posts/active';
  final String ImageStartPointUrl = 'http://10.0.2.2:3000';
  late ScrollController _scrollController;
  late List<Lead> _leads;
  bool _isLoading = false;
  int _currentPage = 1;
  String? fromLocationFilter;
  String? toLocationFilter;
  String? toDateFilter;
  String? fromDateFilter;
  final String ApiUrlForImage = 'http://10.0.2.2:3000';


  void applyFilters() {
    setState(() {
      _leads = _leads.where((lead) {
        bool locationFilterPassed = true;
        if (fromLocationFilter != null) {
          locationFilterPassed = lead.locationFrom.toLowerCase() == fromLocationFilter!.toLowerCase();
        }
        if (toLocationFilter != null) {
          locationFilterPassed = locationFilterPassed && lead.toLocation.toLowerCase() == toLocationFilter!.toLowerCase();
        }

        bool dateFilterPassed = true;
        if (fromDateFilter != null && toDateFilter != null) {
          DateTime leadDate = DateFormat('dd/MM/yyyy').parse(lead.date);
          DateTime fromDate = DateFormat('dd/MM/yyyy').parse(fromDateFilter!);
          DateTime toDate = DateFormat('dd/MM/yyyy').parse(toDateFilter!);
          dateFilterPassed = leadDate.isAfter(fromDate.subtract(Duration(days: 1))) &&
              leadDate.isBefore(toDate.add(Duration(days: 1)));
        }


        return locationFilterPassed && dateFilterPassed;
      }).toList();
    });
  }


  Constants constant = Constants();

  @override
  void initState() {
    super.initState();
    _leads = [];
    _scrollController = ScrollController()..addListener(_scrollListener);
    _fetchLeads();
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _fetchLeads();
    }
  }

  Future<void> _fetchLeads() async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    final response = await http.get(Uri.parse('$apiUrl?page=$_currentPage'));

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      final leadsResponse = LeadsResponse.fromJson(jsonData);

      setState(() {
        leadsResponse.leads.sort((b, a) => a.createdAt.compareTo(b.createdAt));

        for (Lead lead in leadsResponse.leads) {
          Duration timeDifference = DateTime.now().difference(lead.createdAt);
          double minDifference = timeDifference.inMinutes.toDouble();

          if (lead.isActive! && minDifference <= 58) {
          } else {
            lead.isActive = false;
            ApiService().updateLeadStatus(lead.id, lead.isActive);
          }
        }

        _leads.addAll(leadsResponse.leads);

        if (fromDateFilter != null && toDateFilter != null) {
          _leads = _leads.where((lead) {
            DateTime leadDate = DateFormat('dd/MM/yyyy').parse(lead.date);
            DateTime fromDate = DateFormat('dd/MM/yyyy').parse(fromDateFilter!);
            DateTime toDate = DateFormat('dd/MM/yyyy').parse(toDateFilter!);
            return leadDate.isAfter(fromDate.subtract(Duration(days: 1))) &&
                leadDate.isBefore(toDate.add(Duration(days: 1)));
          }).toList();
        }

        _currentPage++;
        _isLoading = false;
      });
    } else {
      throw Exception('Failed to load leads');
    }
  }

  Future<void> _refreshLeads() async {
    _currentPage = 1;
    _leads.clear();
    await _fetchLeads();
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    bool isVisible = false;
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric( horizontal: 12.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Lottie.asset(Assets.animationsLiveLeads,
                        fit: BoxFit.fill,
                        height: height * 0.060,
                        width: height * 0.050),
                    Text(
                      LocalData.active.getString(context),
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: height * 0.024,
                      ),
                    ),


                  ],
                ),
                InkWell(
                  onTap: () async {
                    final Map<String, dynamic>? filters = await Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => FilterPage()),
                    );
                    if (filters != null) {
                      setState(() {
                        fromLocationFilter = filters['fromLocation'];
                        toLocationFilter = filters['toLocation'];
                        fromDateFilter = filters['fromDate'];
                        toDateFilter = filters['toDate'];

                        applyFilters();
                      });
                    }
                  },

                  child: Container(
                    decoration: BoxDecoration(
                        color: isVisible
                            ? Colors.orange
                            : Colors.white,
                        border: Border.all(
                            color: Colors.black, width: 1),
                        borderRadius:
                        BorderRadius.circular(height * 0.1)),
                    child: Padding(
                      padding: EdgeInsets.all(height * 0.005),
                      child: Row(
                        children: [
                          const Icon(Icons.filter_list_alt),
                          Text(
                            "Filters ",
                            style: TextStyle(
                              fontSize: height * 0.020,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: RefreshIndicator(
              onRefresh: _refreshLeads,
              child: ListView.builder(
                controller: _scrollController,
                itemCount: _leads.length + (_isLoading ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index < _leads.length) {
                    final lead = _leads[index];
                    if ((fromLocationFilter == null || fromLocationFilter!.isEmpty || lead.locationFrom.toLowerCase() == fromLocationFilter!.toLowerCase()) &&
                        (toLocationFilter == null || toLocationFilter!.isEmpty || lead.toLocation.toLowerCase() == toLocationFilter!.toLowerCase())) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 5.0),
                        child: GestureDetector(
                          onTap: () async {
                            try {
                              final vendorDetails =
                              await ApiService()
                                  .fetchVendorDetailsById(
                                  lead.vendorId);
                              showDialog(
                                  context: context,
                                  builder: (BuildContext context) {
                                    return AlertDialog(
                                      contentPadding:
                                      EdgeInsets.zero,
                                      content: Container(
                                        width: width * 12.20,
                                        child: Column(
                                          mainAxisSize:
                                          MainAxisSize.min,
                                          children: [
                                            SizedBox(
                                              height:
                                              height * 0.020,
                                            ),
                                            Container(
                                              width: width * 0.31,
                                              height: width * 0.32,
                                              child: ClipOval(
                                                child:
                                                Image.network(
                                                  "$ApiUrlForImage/${vendorDetails['vendor']['profileImgUrl']}",
                                                  fit: BoxFit.cover,
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height:
                                              height * 0.020,
                                            ),
                                            Text(
                                              vendorDetails[
                                              'vendor']['fullname'],
                                              style: TextStyle(
                                                  fontSize: height *
                                                      0.040,
                                                  letterSpacing: 1,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500),
                                            ),
                                            Text(
                                              '${lead.vendorCat} Vendor',
                                              style: TextStyle(
                                                  fontSize: height *
                                                      0.025,
                                                  fontFamily:
                                                  "from_to"),
                                            ),
                                            SizedBox(
                                              height:
                                              height * 0.03020,
                                            ),
                                            Padding(
                                              padding: const EdgeInsets.only(left: 18.0, right: 18.0),
                                              child: Container(
                                                decoration: BoxDecoration(
                                                    border: Border.all(
                                                        width: 1,
                                                        color: Colors.deepOrangeAccent)),
                                                child: Padding(
                                                  padding:
                                                  EdgeInsets.only(
                                                      left: 8.0,
                                                      top: 10,
                                                      right: 8,
                                                      bottom:
                                                      height *
                                                          0.03),
                                                  child: Column(
                                                    children: [
                                                      Text( 'Vendor address:-'  + "  ${vendorDetails['vendor']['currentAddress']}",
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(
                                                            fontSize:
                                                            height *
                                                                0.018),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height:
                                              height * 0.020,
                                            ),
                                            Row(
                                              mainAxisAlignment:
                                              MainAxisAlignment
                                                  .spaceAround,
                                              children: [
                                                InkWell(
                                                  onTap: () {
                                                    constant.makePhoneCall(
                                                        vendorDetails[
                                                        'vendor']
                                                        [
                                                        'phone']);
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                        BorderRadius
                                                            .circular(
                                                            7),
                                                        gradient:
                                                        LinearGradient(
                                                            colors: [
                                                              Colors
                                                                  .amberAccent
                                                                  .shade700,
                                                              Colors
                                                                  .amberAccent
                                                                  .shade700,
                                                              Colors
                                                                  .orange
                                                            ])),
                                                    width: width *
                                                        0.34,
                                                    height: height *
                                                        0.050,
                                                    child: Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .all(
                                                          8.0),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceAround,
                                                        children: [
                                                          Image
                                                              .asset(
                                                            Assets
                                                                .imagesPhone,
                                                            height: height *
                                                                0.032,
                                                          ),
                                                          const SizedBox(
                                                            width:
                                                            1,
                                                          ),
                                                          Text(
                                                            "Call him",
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .white,
                                                                fontSize: height *
                                                                    0.023,
                                                                fontWeight:
                                                                FontWeight.w600),
                                                          ),
                                                          const SizedBox(
                                                            height:
                                                            1,
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                InkWell(
                                                  onTap: () {
                                                    constant.sendWhatsAppMessage(
                                                        vendorDetails[
                                                        'vendor']
                                                        [
                                                        'phone']);
                                                  },
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                        borderRadius:
                                                        BorderRadius
                                                            .circular(
                                                            7),
                                                        gradient:
                                                        LinearGradient(
                                                            colors: [
                                                              Colors
                                                                  .green,  Colors
                                                                  .green,
                                                            ])),
                                                    width: width *
                                                        0.34,
                                                    height: height *
                                                        0.050,
                                                    child: Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .all(
                                                          8.0),
                                                      child: Row(
                                                        mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceAround,
                                                        children: [
                                                          Image
                                                              .asset(
                                                            Assets
                                                                .imagesWhtsappicon,
                                                            height: height *
                                                                0.032,
                                                          ),
                                                          const SizedBox(
                                                            width:
                                                            3,
                                                          ),
                                                          Text(
                                                            "WhatsApp",
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .white,
                                                                fontSize: height *
                                                                    0.022,
                                                                fontWeight:
                                                                FontWeight.w500),
                                                          ),
                                                          const SizedBox(
                                                            height:
                                                            1,
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(
                                              height:
                                              height * 0.030,
                                            ),
                                            InkWell(
                                              onTap: () {
                                                Navigator.pop(
                                                    context);
                                              },
                                              child: Container(
                                                height:
                                                height * 0.055,
                                                width: width * 0.70,
                                                decoration:
                                                BoxDecoration(
                                                  color: Colors
                                                      .white60,
                                                  border: Border.all(
                                                      color: Colors
                                                          .blue,
                                                      width: 1),
                                                  borderRadius:
                                                  BorderRadius
                                                      .circular(
                                                      7),
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    'Go Back',
                                                    style: TextStyle(
                                                      color: Colors
                                                          .blue,
                                                      fontSize:
                                                      height *
                                                          0.025,

                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              height:
                                              height * 0.030,
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  });

                              print(vendorDetails['vendor']['email']);

                              print('Vendor Details: $vendorDetails');
                            } catch (error) {
                              print(
                                  'Error fetching vendor details: $error');
                              // Handle error as needed
                            }
                          },
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              boxShadow: const [
                                BoxShadow(
                                  color: Colors.orange,
                                  spreadRadius: 0.01,
                                  blurRadius: 2,
                                  offset: Offset(2, 2),
                                ),
                                BoxShadow(
                                  color: Colors.grey,
                                  spreadRadius: 0.1,
                                  blurRadius: 0,
                                  offset: Offset(0, 0),
                                ),
                              ],
                            ),
                            child: Padding(
                              padding: EdgeInsets.only(top: height * 0.008),
                              child: Row(
                                children: [
                                  SizedBox(
                                    width: width * 0.025,
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Posted by: ${(lead.vendorName.toString())}",
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: Colors.black,
                                          fontSize: height * 0.019,
                                        ),
                                      ),


                                      Row(
                                        children: [
                                          Text(
                                            LocalData.from.getString(context),
                                            style: TextStyle(
                                              color: Colors.grey.shade700,
                                              fontSize: height * 0.019,
                                            ),
                                          ),
                                          Text(
                                            " ${lead.locationFrom}",
                                            style: TextStyle(
                                              color: Colors.grey.shade700,
                                              fontWeight: FontWeight.w700,
                                              fontSize: height * 0.019,
                                            ),
                                          ),
                                          Text(
                                           LocalData.to.getString(context),
                                            style: TextStyle(
                                              color: Colors.grey.shade700,
                                              fontSize: height * 0.019,
                                            ),
                                          ),
                                          Text(
                                            " ${lead.toLocation}",
                                            style: TextStyle(
                                              color: Colors.grey.shade700,
                                              fontWeight: FontWeight.w700,
                                              fontSize: height * 0.019,
                                            ),
                                          ),
                                        ],
                                      ),
                                      Padding(
                                        padding: EdgeInsets.only(
                                            top: height * 0.0044, bottom: height * 0.0070),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                            Icon(
                                              Icons.calendar_month,
                                              size: height * 0.022,
                                            ),
                                            Text(
                                              ' ${lead.date} ',
                                              style: TextStyle(
                                                fontSize: height * 0.0167,
                                                fontFamily: 'heading',
                                              ),
                                            ),
                                            SizedBox(width: height * 0.028),
                                            Icon(
                                              Icons.watch_later_outlined,
                                              size: height * 0.022,
                                            ),
                                            Text('${lead.time}'),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: height * 0.022),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          '(${formatTimeAgo(lead.createdAt)}',
                                          style: TextStyle(fontSize: height * 0.015),
                                        ),
                                        SizedBox(
                                          height: height * 0.012,
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(
                                              right: width * 0.018, bottom: width * 0.008),
                                          child: InkWell(
                                            onTap: () {
                                              constant.makePhoneCall(lead.vendorContact.toString());
                                            },
                                            child: Icon(
                                              Icons.call,
                                              size: height * 0.044,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(
                                    width: width * 0.025,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    } else {
                      return Container(
                        child: Text("Currently no active leads")
                      );
                    }
                  } else {
                    return  Padding(
                      padding: EdgeInsets.symmetric(vertical: 16.0),
                      child: Center(
                        child: LoadingWidget(height /2, width),
                      ),
                    );
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  String formatTimeAgo(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);

    if (difference.inMinutes < 1) {
      return 'just now';
    } else if (difference.inMinutes < 60) {
      return '${difference.inMinutes} mins ago';
    } else if (difference.inHours < 24) {
      return '${difference.inHours} hours ago';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return 'on ${dateTime.day}/${dateTime.month}/${dateTime.year}';
    }
  }
}

class FilterPage extends StatefulWidget {
  @override
  _FilterPageState createState() => _FilterPageState();
}

class _FilterPageState extends State<FilterPage> {
  List<String> locationFromValues = [];
  List<String> locationToValues = [];
  String? selectedFromLocation;
  String? selectedToLocation;
  DateTime? selectedFromDate;
  DateTime? selectedToDate;

  @override
  void initState() {
    super.initState();
    fetchDistinctLocations();
  }

  Future<void> fetchDistinctLocations() async {
    try {
      List<String> distinctFromLocations =
      await ApiService().fetchDistinctLocationFrom();
      List<String> distinctToLocations =
      await ApiService().fetchDistinctLocationto();
      setState(() {
        locationFromValues = distinctFromLocations;
        locationToValues = distinctToLocations;
      });
    } catch (error) {
      print('Error fetching distinct locations: $error');
    }
  }

  @override
  Widget build(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: AppBar(
        title: Text('Filters'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Text(
                  "Select Date From:- ",
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                MaterialButton(
                  onPressed: () async {
                    final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: selectedFromDate,
                      firstDate: DateTime(2022),
                      lastDate: DateTime(2101),
                    );

                    if (picked != null && picked != selectedFromDate) {
                      setState(() {
                        selectedFromDate = picked;
                      });
                    }
                  },
                  child: Row(
                    children: [
                      Icon(Icons.calendar_today),
                      Text(
                        ' ${selectedFromDate != null ? DateFormat('dd/MM/yyyy').format(selectedFromDate!) : DateFormat('dd/MM/yyyy').format(DateTime.now())}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
              ],
            ),
            Row(
              children: [
                const Text(
                  "Select Date To:- ",
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                  ),
                ),
                MaterialButton(
                  onPressed: () async {
                    final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: selectedToDate,
                      firstDate: DateTime(2022),
                      lastDate: DateTime(2101),
                    );

                    if (picked != null && picked != selectedToDate) {
                      setState(() {
                        selectedToDate = picked;
                      });
                    }
                  },
                  child: Row(
                    children: [
                      Icon(Icons.calendar_today),
                      Text(
                        ' ${selectedToDate != null ? DateFormat('dd/MM/yyyy').format(selectedToDate!) : DateFormat('dd/MM/yyyy').format(DateTime.now())}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 10),
              ],
            ),
            Padding(
              padding: EdgeInsets.only(bottom: width * 0.03),
              child: Row(
                children: [
                  Icon(
                    Icons.location_on,
                    color: Colors.grey.shade700,
                  ),
                  Text(
                    "Location",
                    style: TextStyle(fontSize: width * 0.0570),
                  ),
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: width * 0.04),
              child: InkWell(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return Dialog(
                        child: SearchableDropdown(
                          items: locationFromValues,
                          value: selectedFromLocation,
                          onChanged: (location) {
                            setState(() {
                              selectedFromLocation = location;
                            });
                          },
                        ),
                      );
                    },
                  );
                },
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'From',
                    border: OutlineInputBorder(),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(selectedFromLocation ?? 'Select Location from'),
                      Icon(Icons.arrow_drop_down),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 16.0),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: width * 0.04),
              child: InkWell(
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return Dialog(
                        child: SearchableDropdown(
                          items: locationToValues,
                          value: selectedToLocation,
                          onChanged: (location) {
                            setState(() {
                              selectedToLocation = location;
                            });
                          },
                        ),
                      );
                    },
                  );
                },
                child: InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'To',
                    border: OutlineInputBorder(),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(selectedToLocation ?? 'Select Location to'),
                      Icon(Icons.arrow_drop_down),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(height: 16.0),
            MaterialButton(
              onPressed: () {
                Navigator.pop(context, {
                  'fromLocation': selectedFromLocation,
                  'toLocation': selectedToLocation,
                  'fromDate': selectedFromDate != null
                      ? DateFormat('dd/MM/yyyy').format(selectedFromDate!)
                      : null,
                  'toDate': selectedToDate != null
                      ? DateFormat('dd/MM/yyyy').format(selectedToDate!)
                      : null,
                });
              },
              child: Container(
                width: width,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: const [
                    Colors.orange,
                    Colors.orange,
                    Colors.orange,
                    Colors.amber
                  ]),
                  borderRadius: BorderRadius.circular(055),
                ),
                height: height * 0.06,
                child: Center(
                  child: Text('Apply Filters',
                      style: TextStyle(
                          fontSize: width * 0.055,
                          color: Colors.white)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
