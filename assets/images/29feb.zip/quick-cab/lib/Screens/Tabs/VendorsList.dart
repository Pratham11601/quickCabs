import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:untitled/models/vendors_details.dart';
import '../../Constants/contants.dart';
import '../../Controllers/vendorsListController.dart';
import '../../Localization/locals.dart';
import '../../generated/assets.dart';
import '../../services/ApiServices.dart';
import '../no_internet_page.dart';

class VendorsListScreen extends StatefulWidget {
  final String tabName;

  const VendorsListScreen({required this.tabName, Key? key}) : super(key: key);


  @override
  State<VendorsListScreen> createState() => _VendorsListScreenState(tabName: tabName);
}

class _VendorsListScreenState extends State<VendorsListScreen> {
  late final VendorController vendorController;
  final String tabName;

  _VendorsListScreenState({required this.tabName});

  @override
  void initState() {
    print("init state  ${widget.tabName} TAB");

    super.initState();
    checkInternetAndFetchDetails();
    vendorController = Get.put(VendorController(tabname: '${widget.tabName}' ));
    vendorController.fetchVendorsData();
  }

  Constants constants = Constants();

  Future<void> checkInternetAndFetchDetails() async {
    bool isConnected = await Constants().checkInternetConnection();

    if (isConnected) {
      ApiService().getUserDataFromToken();
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => NoInternetPage()),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;
    print("override   ${widget.tabName} TAB");

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orange,
        title: Text(

          widget.tabName,
          style: TextStyle(
              fontSize: height * 0.03,
              fontWeight: FontWeight.w600,
              color: Colors.white),
        ),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              SearchBar(vendorController: vendorController),
              GetBuilder<VendorController>(
                builder: (controller) {
                  return StreamBuilder<List<Vendor>>(
                    stream: controller.leadsStream,
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        List<Vendor> leadsList = snapshot.data!;
                        if (leadsList.isNotEmpty) {
                          return Column(
                            children: leadsList.map((lead) {
                              String imageUrl =
                                  "http://10.0.2.2:3000/${lead.profileImgUrl.toString()}";
                              imageUrl = imageUrl.replaceFirst("/uploads/", "/");
                              print("Modified Image URL: $imageUrl");
                              return Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: width * 00.007),
                                child: Column(
                                  children: [
                                    SizedBox(height: 4),
                                    Container(
                                      decoration: BoxDecoration(
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.orange,
                                            spreadRadius: 0.01,
                                            blurRadius: 2,
                                            offset: Offset(2, 2),
                                          ),
                                          BoxShadow(
                                            color: Colors.orange,
                                            spreadRadius: 0.1,
                                            blurRadius: 1,
                                            offset: Offset(-3, 0),
                                          ),
                                        ],
                                        borderRadius: BorderRadius.circular(08),
                                        color: Colors.grey.shade100,
                                      ),
                                      child: Column(
                                        children: [
                                          Column(
                                            children: [
                                              ListTile(
                                                title: Text(
                                                  lead.businessName.isNull ||
                                                          lead.businessName ==
                                                              null
                                                      ? lead.fullname ?? ''
                                                      : lead.businessName!,
                                                  style: TextStyle(
                                                      fontWeight:
                                                          FontWeight.w600),
                                                ),
                                                trailing: Icon(
                                                  Icons.contact_mail,
                                                  size: height * 0.055,
                                                ),
                                                leading: Padding(
                                                  padding:
                                                      const EdgeInsets.all(0.0),
                                                  child: CircleAvatar(
                                                    radius: height * 0.039,
                                                    backgroundImage: NetworkImage(
                                                        "$imageUrl" ??
                                                            "https://th.bing.com/th/id/OIP.Ld1-vmK4alBUagfOv-e1VwHaFj?w=265&h=199&c=7&r=0&o=5&dpr=1.3&pid=1.7"),
                                                  ),
                                                ),
                                                onTap: () {
                                                  if (lead.profileImgUrl !=
                                                      null) {
                                                    Uri uri = Uri.parse(lead
                                                        .profileImgUrl
                                                        .toString());
                                                    String fileName =
                                                        uri.pathSegments.last;
                                                    print(
                                                        "Profile Image Filename: $fileName");
                                                    print(
                                                        "http://10.0.2.2:3000/${lead.profileImgUrl}");
                                                  }
                                                  showDialog(
                                                    context: context,
                                                    builder:
                                                        (BuildContext context) {
                                                      return AlertDialog(
                                                        contentPadding:
                                                            EdgeInsets.zero,
                                                        content: Container(
                                                          width: width * 12.20,
                                                          child: Column(
                                                            mainAxisSize:
                                                                MainAxisSize.min,
                                                            children: [
                                                              SizedBox(
                                                                height: height *
                                                                    0.020,
                                                              ),
                                                              Container(
                                                                width:
                                                                    width * 0.31,
                                                                height:
                                                                    width * 0.32,
                                                                child: ClipOval(
                                                                  child: Image
                                                                      .network(
                                                                    "$imageUrl" ??
                                                                        "https://th.bing.com/th?id=OIP.hZQOmSCKlMjx2WKPQs82-AHaG9&w=257&h=242&c=8&rs=1&qlt=90&o=6&dpr=1.3&pid=3.1&rm=2",
                                                                    fit: BoxFit
                                                                        .cover,
                                                                  ),
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                height: height *
                                                                    0.020,
                                                              ),
                                                              Text(
                                                                lead.fullname
                                                                    .toString(),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        height *
                                                                            0.040,
                                                                    letterSpacing:
                                                                        1,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500),
                                                              ),
                                                              Text(
                                                                '${lead.vendorCat}'
                                                                    .toUpperCase(),
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        height *
                                                                            0.025,
                                                                    fontFamily:
                                                                        "menu"),
                                                              ),
                                                              SizedBox(
                                                                height: height *
                                                                    0.03020,
                                                              ),
                                                              Container(
                                                                decoration: BoxDecoration(
                                                                    border: Border.all(
                                                                        width: 1,
                                                                        color: Colors
                                                                            .red)),
                                                                child: Padding(
                                                                  padding: EdgeInsets.only(
                                                                      left: 8.0,
                                                                      top: 10,
                                                                      right: 8,
                                                                      bottom:
                                                                          height *
                                                                              0.03),
                                                                  child: Column(
                                                                    children: [
                                                                      Text(
                                                                        'At Post :-${lead.currentAddress}  ',
                                                                        style: TextStyle(
                                                                            fontSize:
                                                                                height * 0.017),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                height: height *
                                                                    0.020,
                                                              ),
                                                              Row(
                                                                mainAxisAlignment:
                                                                    MainAxisAlignment
                                                                        .spaceAround,
                                                                children: [
                                                                  InkWell(
                                                                    onTap: () {
                                                                      constants.makePhoneCall(
                                                                          lead.phone);
                                                                    },
                                                                    child:
                                                                        Container(
                                                                      decoration: BoxDecoration(
                                                                          borderRadius:
                                                                              BorderRadius.circular(
                                                                                  7),
                                                                          gradient:
                                                                              LinearGradient(
                                                                                  colors: [
                                                                                Colors.amberAccent.shade700,
                                                                                Colors.amberAccent.shade700,
                                                                                Colors.orange
                                                                              ])),
                                                                      width:
                                                                          width *
                                                                              0.34,
                                                                      height:
                                                                          height *
                                                                              0.050,
                                                                      child:
                                                                          Padding(
                                                                        padding: const EdgeInsets
                                                                            .all(
                                                                            8.0),
                                                                        child:
                                                                            Row(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceAround,
                                                                          children: [
                                                                            Image
                                                                                .asset(
                                                                              Assets.imagesPhone,
                                                                              height:
                                                                                  height * 0.032,
                                                                            ),
                                                                            const SizedBox(
                                                                              width:
                                                                                  1,
                                                                            ),
                                                                            Text(
                                                                             LocalData.callhim.getString(context),
                                                                              style: TextStyle(
                                                                                  color: Colors.white,
                                                                                  fontSize: height * 0.023,
                                                                                  fontWeight: FontWeight.w600),
                                                                            ),
                                                                            const SizedBox(
                                                                              height:
                                                                                  1,
                                                                            )
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  InkWell(
                                                                    onTap: () {
                                                                      constants.sendWhatsAppMessage(
                                                                          lead.phone);
                                                                    },
                                                                    child:
                                                                        Container(
                                                                      decoration:
                                                                          BoxDecoration(
                                                                              borderRadius:
                                                                                  BorderRadius.circular(7),
                                                                              gradient: LinearGradient(colors: [
                                                                                Colors.green,
                                                                                Colors.green,
                                                                              ])),
                                                                      width:
                                                                          width *
                                                                              0.34,
                                                                      height:
                                                                          height *
                                                                              0.050,
                                                                      child:
                                                                          Padding(
                                                                        padding: const EdgeInsets
                                                                            .all(
                                                                            8.0),
                                                                        child:
                                                                            Row(
                                                                          mainAxisAlignment:
                                                                              MainAxisAlignment.spaceAround,
                                                                          children: [
                                                                            Image
                                                                                .asset(
                                                                              Assets.imagesWhtsappicon,
                                                                              height:
                                                                                  height * 0.032,
                                                                            ),
                                                                            const SizedBox(
                                                                              width:
                                                                                  3,
                                                                            ),
                                                                            Text(
                                                                              "WhatsApp",
                                                                              style: TextStyle(
                                                                                  color: Colors.white,
                                                                                  fontSize: height * 0.022,
                                                                                  fontWeight: FontWeight.w500),
                                                                            ),
                                                                            const SizedBox(
                                                                              height:
                                                                                  1,
                                                                            )
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                              SizedBox(
                                                                height: height *
                                                                    0.030,
                                                              ),
                                                              InkWell(
                                                                onTap: () {
                                                                  Navigator.pop(
                                                                      context);
                                                                },
                                                                child: Container(
                                                                  height: height *
                                                                      0.055,
                                                                  width: width *
                                                                      0.70,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                    color: Colors
                                                                        .white60,
                                                                    border: Border.all(
                                                                        color: Colors
                                                                            .blue,
                                                                        width: 1),
                                                                    borderRadius:
                                                                        BorderRadius
                                                                            .circular(
                                                                                7),
                                                                  ),
                                                                  child: Center(
                                                                    child: Text(
                                                                     LocalData.goback.getString(context),
                                                                      style:
                                                                          TextStyle(
                                                                        color: Colors
                                                                            .blue,
                                                                        fontSize:
                                                                            height *
                                                                                0.025,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                height: height *
                                                                    0.030,
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                  );
                                                },
                                                subtitle: Text(lead.city ?? ''),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }).toList(),
                          );
                        } else {
                          return  Text(LocalData.noDataFound.getString(context));
                        }
                      } else if (snapshot.hasError) {
                        return Text('Error: ${snapshot.error}');
                      } else {
                        return Padding(
                            padding: EdgeInsets.all(8.0),
                            child: SizedBox(
                              width: 200.0,
                              height: 100.0,
                              child: Text(LocalData.Searchbynameorcity.getString(context),)
                            )
                        );
                      }
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }


}

class SearchBar extends StatelessWidget {
  final VendorController vendorController;

  SearchBar({required this.vendorController});

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    return Padding(
      padding: EdgeInsets.symmetric(
        vertical: height * 0.008,
        horizontal: width * 0.001,
      ),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(0.0),
          border: Border.all(
            width: 0.3,
            color: Colors.grey,
          ),
        ),
        child: TextField(
          onChanged: (query) {
            vendorController.filterVendors(query);
          },
          decoration: InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: LocalData.Searchbynameorcity.getString(context),
            border: InputBorder.none,
          ),
        ),
      ),
    );
  }
}
