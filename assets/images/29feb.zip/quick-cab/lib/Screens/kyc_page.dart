import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart' as dio;
import 'package:flutter_localization/flutter_localization.dart';
import 'package:get/get.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:image_picker/image_picker.dart';
import 'package:untitled/Screens/login_page.dart';
import 'package:autocomplete_textfield/autocomplete_textfield.dart';
import '../Constants/contants.dart';
import '../Localization/locals.dart';
import '../services/ApiServices.dart';
import 'no_internet_page.dart';

class KYCPage extends StatefulWidget {
  String password;
  String phone;

  KYCPage({required this.password, required this.phone, Key? key})
      : super(key: key);

  @override
  _KYCPageState createState() => _KYCPageState();
}

class _KYCPageState extends State<KYCPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _surnameController = TextEditingController();
  final TextEditingController _bussinessNameController =
  TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _currentAddressCityController =
  TextEditingController();
  final TextEditingController _currentAddressStreetController =
  TextEditingController();
  final TextEditingController _currentAddressLandmarkController =
  TextEditingController();
  final TextEditingController _currentAddresspincodeController =
  TextEditingController();
  int _index = 0;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String selectedVendorType = 'none';
  String selectedGender = 'none';

  late FlutterLocalization _FlutterLocalization ;
  late String _currentLocale;

  GlobalKey<AutoCompleteTextFieldState<String>> key = GlobalKey();
  GlobalKey<AutoCompleteTextFieldState<String>> keybusiness = GlobalKey();
  TextEditingController controller = TextEditingController();

  late dynamic selectedLicenseImage = " ";
  late dynamic selectedIdProofImage = " ";
  late dynamic? _selectedProfileImage;
  File? _profilePic;
  String? selectedCategory;


  Widget _buildAddressFormFields(String label, Icon icon,
      TextEditingController controller, TextInputType textInputType) {
    return TextFormField(
      controller: controller,
      keyboardType: textInputType,
      validator: (value) {
        if (value == null || value.isEmpty) {
          return 'Please enter $label';
        }
        return null;
      },
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        prefixIcon: icon,
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(
            color: Colors.orange,
          ),
        ),
        labelText: label,
      ),
    );
  }


  @override
  void initState() {
    super.initState();

    _FlutterLocalization = FlutterLocalization.instance;
    _currentLocale  =  _FlutterLocalization.currentLocale!.languageCode;
    dynamic selectedLicenseImage = " ";
    dynamic selectedIdProofImage = " ";
    _selectedProfileImage = '';
    checkInternetAndFetchDetails();
  }

  Future<void> checkInternetAndFetchDetails() async {
    bool isConnected = await Constants().checkInternetConnection();

    if (isConnected) {
      print('Done');
    } else {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => NoInternetPage()),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    double height = MediaQuery
        .of(context)
        .size
        .height;
    _phoneController.text = widget.phone;
    return Theme(
      data: ThemeData(
        textTheme: const TextTheme(),
      ),
      child: Scaffold(
        appBar: AppBar(
          title:  Text('  ${LocalData.userRegistration.getString(context)}',
              style: TextStyle(fontSize: height * 0.023,fontWeight: FontWeight.w600)),
          actions: [
            DropdownButton(
              onChanged: (value){
                print("hello");
                print(value);
                _setLocale(value);

              },
              items: const [
                DropdownMenuItem(
                  value: "hi",
                  child: Text("hi"),
                ),
                DropdownMenuItem(
                  value: "eng",
                  child: Text("eng"),
                ) ,
                DropdownMenuItem(
                  value: "mr",
                  child: Text("mr"),
                )



              ],
            ),
          ],
        ),
        body: Stepper(
          currentStep: _index,
          onStepCancel: () {
            if (_index > 0) {
              setState(() {
                _index -= 1;
              });
            }
          },
          onStepContinue: () {
            bool isCurrentStepValid = _validateCurrentStep();
            if (isCurrentStepValid) {
              if (_index < 4) {
                setState(() {
                  _index += 1;
                });
              } else if (_index == 4) {
                if (_validateAllSteps()) {
                  _registerVendor();

                  Get.to(KYCPage(
                    password: widget.password,
                    phone: widget.phone,
                  ));
                }
              }
            }
          },
          onStepTapped: (int index) {
            setState(() {
              _index = index;
            });
          },
          type: StepperType.vertical,
          steps: <Step>[
            Step(
              title: Row(
                children: [
                  Icon(
                    Icons.person,
                    color: Colors.blue.shade800,
                    size: height * 0.038,
                  ),
                  SizedBox(
                    width: height * 0.01,
                  ),
                  Text(
                    LocalData.PersonDetails.getString(context),
                    style: TextStyle(fontSize: height * 0.021),
                  )
                ],
              ),
              content: Container(
                alignment: Alignment.bottomLeft,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: height * 0.018,
                      ),
                      _buildAddressFormFields(
                          LocalData.firstname.getString(context),
                          const Icon(Icons.person_2_sharp),
                          _nameController,
                          TextInputType.name),
                      SizedBox(
                        height: height * 0.018,
                      ),
                      _buildAddressFormFields(
                          LocalData.surname.getString(context),
                          const Icon(Icons.person_2_sharp),
                          _surnameController,
                          TextInputType.name),
                      SizedBox(
                        height: height * 0.018,
                      ),
                      DropdownButtonFormField<String>(
                        value: selectedGender,
                        onChanged: (String? newValue) {
                          setState(() {
                            selectedGender = newValue ?? 'none';
                          });
                        },
                        items:  [
                          DropdownMenuItem(
                            value: 'none',
                            child: Text(
                              'None',
                              style: TextStyle(color: Colors.grey),
                            ),
                          ),
                          DropdownMenuItem(
                            value: 'male',
                            child: Text( LocalData.male.getString(context),),
                          ),
                          DropdownMenuItem(
                            value: 'female',
                            child: Text( LocalData.female.getString(context)),
                          ),
                          DropdownMenuItem(
                            value: 'Transgender',
                            child: Text(LocalData.transgender.getString(context),
                          ),
                          ),
                        ],
                        decoration:  InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: LocalData.gender.getString(context),
                        ),
                      ),
                      SizedBox(
                        height: height * 0.018,
                      ),
                      TextFormField(
                        controller: _phoneController,
                        readOnly: true,
                        keyboardType: TextInputType.phone,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return LocalData.pleaseenteryourphonenumber.getString(context);
                          }
                          return null;
                        },
                        decoration:  InputDecoration(
                          border: OutlineInputBorder(),
                          prefixIcon: Icon(Icons.phone),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(
                              color: Colors.orange,
                            ),
                          ),
                          hintText: "+91 91xxx xxxxx",
                          labelStyle: TextStyle(color: Colors.black87),
                          labelText:LocalData.phone.getString(context),
                        ),
                      ),
                      SizedBox(
                        height: height * 0.018,
                      ),
                      _buildAddressFormFields(LocalData.email.getString(context), const Icon(Icons.mail),
                          _emailController, TextInputType.emailAddress),
                      SizedBox(
                        height: height * 0.018,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          InkWell(
                              onTap: () {
                                _getImage();
                              },
                              child: Text(
                                "Profile Image",
                                style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: height * 0.020),
                              )),
                        ],
                      ),
                      Container(
                        alignment: Alignment.center,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _profilePic != null
                                ? ClipOval(
                              child: Image.file(
                                _profilePic!,
                                height: height * 00.12,
                                // Set your preferred height
                                width: height *
                                    00.12, // Set your preferred height
                              ),
                            )
                                : Container(),
                            SizedBox(
                              height: height * 0.0,
                            ),
                            MaterialButton(
                                onPressed: () {
                                  _getImage();
                                },
                                child: Container(
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(35),
                                      border: Border.all(
                                          width: 1, color: Colors.black)),
                                  child:  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 5.0, vertical: 2.0),
                                    child: Text(
                                      LocalData.capture.getString(context),
                                      style: TextStyle(),
                                    ),
                                  ),
                                )),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Step(
              title: Row(
                children: [
                  Icon(
                    Icons.business_center_sharp,
                    color: Colors.blue.shade800,
                    size: height * 0.038,
                  ),
                  Text(
                    LocalData.busniessDetails.getString(context),
                    style: TextStyle(fontSize: height * 0.021),
                  ),
                ],
              ),
              content: Container(
                alignment: Alignment.bottomLeft,
                child: Padding(
                  padding: const EdgeInsets.all(7.0),
                  child: Column(
                    children: [
                      _buildAddressFormFields(
                          LocalData.busniessname.getString(context),
                          const Icon(Icons.business_sharp),
                          _bussinessNameController,
                          TextInputType.name),
                      SizedBox(
                        height: height * 0.020,
                      ),
                      DropdownButtonFormField<String>(
                        value: selectedVendorType,
                        onChanged: (String? newValue) {
                          setState(() {
                            selectedVendorType = newValue!;
                            selectedCategory = newValue;
                          });
                        },
                        items: const [
                          DropdownMenuItem(
                            value: 'none',
                            child: Text(
                              'None',
                              style: TextStyle(color: Colors.grey),
                            ),
                          ),
                          DropdownMenuItem(
                            value: 'Cab',
                            child: Text('Cab'),
                          ),
                          DropdownMenuItem(
                            value: 'Towing',
                            child: Text('Towing'),
                          ),
                          DropdownMenuItem(
                            value: 'Repairing',
                            child: Text('Repairing'),
                          ),
                          DropdownMenuItem(
                            value: 'Puncture',
                            child: Text('Puncture'),
                          ),
                          DropdownMenuItem(
                            value: 'Drivers',
                            child: Text('Drivers'),
                          ),
                          DropdownMenuItem(
                            value: 'Fuel',
                            child: Text('Fuel'),
                          ),
                          DropdownMenuItem(
                            value: 'Restaurants',
                            child: Text('Restaurants'),
                          ),
                          DropdownMenuItem(
                            value: 'Emergency',
                            child: Text('Emergency'),
                          ),
                        ],
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Category',
                        ),
                      ),
                      SizedBox(
                        height: height * 0.018,
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Step(
              title: Row(
                children: [
                  Icon(
                    Icons.business,
                    color: Colors.blue.shade800,
                    size: height * 0.038,
                  ),
                  Text(
                    LocalData.BusinessAddress.getString(context),
                    style: TextStyle(fontSize: height * 0.021),
                  ),
                ],
              ),
              content: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    _buildAddressFormFields(
                        LocalData.busniessDetails.getString(context),
                        const Icon(
                          Icons.streetview_outlined,
                        ),
                        _currentAddressStreetController,
                        TextInputType.name),
                    SizedBox(
                      height: height * 0.016,
                    ),
                    _buildAddressFormFields(
                        LocalData.busniessDetails.getString(context),
                        const Icon(
                          Icons.location_on,
                        ),
                        _currentAddressLandmarkController,
                        TextInputType.name),
                    SizedBox(
                      height: height * 0.016,
                    ),
                    AutoCompleteTextField<String>(
                      key: keybusiness,
                      controller: _currentAddressCityController,
                      clearOnSubmit: false,
                      suggestions: Constants().suggestions,
                      decoration:  InputDecoration(
                        labelText:  LocalData.city.getString(context),
                        prefixIcon: Icon(Icons.location_city_outlined),
                        border: OutlineInputBorder(),
                      ),
                      itemBuilder: (context, suggestion) =>
                          ListTile(
                            title: Text(suggestion),
                          ),
                      itemSorter: (a, b) => a.compareTo(b),
                      itemFilter: (suggestion, input) =>
                          suggestion.toLowerCase().startsWith(
                              input.toLowerCase()),
                      itemSubmitted: (item) {
                        setState(() {
                          controller.text = item;
                        });
                      },
                    ),

                    SizedBox(
                      height: height * 0.016,
                    ),
                    _buildAddressFormFields(
                        LocalData.pincode.getString(context),
                        const Icon(
                          Icons.pin,
                        ),
                        _currentAddresspincodeController,
                        TextInputType.number),
                  ],
                ),
              ),
            ),
            Step(
              title: Row(
                children: [
                  Icon(
                    Icons.insert_drive_file_rounded,
                    color: Colors.blue.shade800,
                    size: height * 0.038,
                  ),
                  Text(
                    LocalData.license.getString(context),
                    style: TextStyle(fontSize: height * 0.021),
                  ),
                ],
              ),
              content: Container(
                  child:
                  Column(
                    children: [
                      MaterialButton(
                        onPressed: () {
                          _showImageSourceDialog(
                              'Driving Licence'
                          );
                        },
                        color: Colors.blue,
                        child: Text(selectedVendorType == "Cab"
                            ?
                        'Select Driving Licence Image'
                            : 'Select business Licence Image',
                          style: const TextStyle(color: Colors.white),
                        ),
                      ),
                      const SizedBox(height: 16.0),
                      selectedLicenseImage != null &&
                          selectedLicenseImage.isNotEmpty
                          ? Container(
                        height: 150.0,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        child: Image.file(
                          File(selectedLicenseImage),
                          fit: BoxFit.cover,
                          width: double.infinity,
                          errorBuilder: (BuildContext context, Object error, StackTrace? stackTrace) {
                            // Error handling
                            print('Error loading image: $error');
                            return const Center(
                              child: Text(' '),
                            );
                          },
                        ),
                      )
                          : const SizedBox.shrink(),
                    ],
                  )

              ),
            ),
            Step(
                title: Row(
                  children: [
                    Icon(
                      Icons.document_scanner,
                      color: Colors.blue.shade800,
                      size: height * 0.038,
                    ),
                    Text(
                      LocalData.document.getString(context),
                      style: TextStyle(fontSize: height * 0.021),
                    ),
                  ],
                ),
                content: Container(
                  child: Column(
                      children: [
                      const SizedBox(height: 36.0),
                  MaterialButton(
                    onPressed: () {
                      _showImageSourceDialog('ID Proof');
                    },
                    color: Colors.blue,
                    child:  Text(
                      LocalData.UploadAdharCard.getString(context),
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(height: 32.0),
                  selectedIdProofImage.isNotEmpty
                      ? Container(
                    height: 150.0,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Image.file(
                      File(selectedIdProofImage),
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorBuilder: (BuildContext context, Object error,
                          StackTrace? stackTrace) {
                        print('Error loading image: $error');
                        return const Center(
                          child: Text(' '),
                        );
                      },
                    ),

                )
                    : const SizedBox.shrink(),
          ],
        ),
      ),
    )

    ],
    )
    ,
    )
    ,
    );
  }

  void _registerVendor() async {
    String? emptyField = _getEmptyField();
    if (emptyField != null) {
      Get.snackbar('Error', 'Please enter $emptyField');
    } else {
      try {
        List<int> profilePicBytes = await _profilePic!.readAsBytes();
        String profilePicBase64 = base64Encode(profilePicBytes);

        dio.FormData formData = dio.FormData.fromMap({
          "fullname": _nameController.text + " " + _surnameController.text,
          "profileImgUrl": await dio.MultipartFile.fromBytes(
            profilePicBytes,
            filename: 'profile_image.jpg',
          ),
          "phone": _phoneController.text,
          "email": _emailController.text,
          "password": widget.password,
          "businessName": "${_bussinessNameController.text} ",
          "city": "${_currentAddressCityController.text} ",
          "vendor_cat": selectedVendorType,
          "vendor_gender": selectedGender.toString(),
          "currentAddress": "${_currentAddressCityController.text
              .toUpperCase()} "
              "${_currentAddressStreetController.text} "
              "${_currentAddressLandmarkController.text} "
              "${_currentAddresspincodeController.text}",
          "licenseImage": await dio.MultipartFile.fromFile(
            selectedLicenseImage,
            filename: 'license_image.jpg',
          ),
          "documentImage": await dio.MultipartFile.fromFile(
            selectedIdProofImage,
            filename: 'document_image.jpg',
          ),
        });

        print(formData.toString());

        await ApiService().postData(formData);

        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('Registration Successful'),
              content: const Text('Thank you for registering as a vendor!'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Get.snackbar("Congrats! Your account has been created",
                        "Please login to continue",
                        snackPosition: SnackPosition.TOP);
                    Get.to(const LoginPage());
                  },
                  child: const Text('Go to login page'),
                ),
              ],
            );
          },
        );
      } catch (error) {
        print('Error during registration: $error');
        Get.snackbar('Error', 'Failed to register. Please try again.');
      }
    }
  }

  Future<void> _getImage() async {
    final picker = ImagePicker();

    // Capture a new photo using the device's camera
    final pickedFile = await picker.pickImage(
      source: ImageSource.camera,
    );

    if (pickedFile == null) {
      return;
    }

    setState(() {
      _profilePic = File(pickedFile.path);
    });
  }

  bool _validateCurrentStep() {
    switch (_index) {
      case 0:
        if (_nameController.text.isEmpty) {
          _showValidationErrorAlert('Please enter your name');
          return false;
        } else if (selectedGender == 'none') {
          _showValidationErrorAlert('Please select a gender');
          return false;
        } else if (_surnameController.text.isEmpty) {
          _showValidationErrorAlert('Please enter your surname');
          return false;
        } else if (_phoneController.text.isEmpty) {
          _showValidationErrorAlert('Please enter your phone number');
          return false;
        }

        else if (_emailController.text.isEmpty) {
          _showValidationErrorAlert('Please enter your email');
          return false;
        }


        if (_profilePic == null) {
          _showValidationErrorAlert('Please Verify your Face');
          return false;
        }
        break;

      case 1:
        if (selectedVendorType == 'none') {
          _showValidationErrorAlert('Please select a vendor type');
          return false;
        }


        else if (_bussinessNameController.text.isEmpty) {
          _showValidationErrorAlert('Please enter your Business name');
          return false;
        }
        break;
      case 2:
        if (_currentAddressCityController.text.isEmpty) {
          _showValidationErrorAlert('Please enter your business address city');
          return false;
        } else if (_currentAddressStreetController.text.isEmpty) {
          _showValidationErrorAlert(
              'Please enter your business address street');
          return false;
        } else if (_currentAddressLandmarkController.text.isEmpty) {
          _showValidationErrorAlert(
              'Please enter your business address landmark');
          return false;
        } else if (_currentAddresspincodeController.text.isEmpty) {
          _showValidationErrorAlert(
              'Please enter your business address pincode');
          return false;
        }
        break;

    }
    return true;
  }

  bool _validateAllSteps() {
    if (_nameController.text.isEmpty ||
        _surnameController.text.isEmpty ||
        _phoneController.text.isEmpty) {
      _showValidationErrorAlert('Please fill in all fields in Step 1');
      return false;
    }

    if (selectedVendorType == 'none' ||
        selectedGender == 'none' ||
        _emailController.text.isEmpty) {
      _showValidationErrorAlert('Please fill in all fields in Step 2');
      return false;
    }

    if (_currentAddressCityController.text.isEmpty ||
        _currentAddressStreetController.text.isEmpty ||
        _currentAddressLandmarkController.text.isEmpty ||
        _currentAddresspincodeController.text.isEmpty) {
      _showValidationErrorAlert('Please fill in all fields in Step 3');
      return false;
    }


    if (selectedLicenseImage == null || selectedLicenseImage.isEmpty) {
      _showValidationErrorAlert('Please select a driving license and upload an image');
      return false;
    }

    if (selectedIdProofImage == null || selectedIdProofImage.isEmpty) {
      _showValidationErrorAlert('Please select an ID proof and upload an image');
      return false;
    }

    return true;
  }

  Future<void> _showImageSourceDialog(String imageType) async {
    String? selectedImage;
    if (imageType == 'Driving Licence') {
      selectedImage = selectedLicenseImage;
    } else if (imageType == 'ID Proof') {
      selectedImage = selectedIdProofImage;
    }

    if (selectedImage == null || selectedImage.isEmpty) {
      return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return CupertinoAlertDialog(
            title: Text('Select Image Source for $imageType'),
            content: Column(
              children: <Widget>[
                CupertinoDialogAction(
                  onPressed: () {
                    Navigator.of(context).pop();
                    openCamera(imageType);
                  },
                  child: const Text(
                    'Open Camera',
                    style: TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(height: 8.0),
                CupertinoDialogAction(
                  onPressed: () {
                    Navigator.of(context).pop();
                    openGallery(imageType);
                  },
                  child: const Text(
                    'Open Gallery',
                    style: TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      );
    } else {
      return showDialog<void>(
        context: context,
        builder: (BuildContext context) {
          return CupertinoAlertDialog(
            title: Text('Change Image for $imageType'),
            content: Column(
              children: <Widget>[
                CupertinoDialogAction(
                  onPressed: () {
                    Navigator.of(context).pop();
                    openCamera(imageType);
                  },
                  child: const Text(
                    'Open Camera',
                    style: TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(height: 8.0),
                CupertinoDialogAction(
                  onPressed: () {
                    Navigator.of(context).pop();
                    openGallery(imageType);
                  },
                  child: const Text(
                    'Open Gallery',
                    style: TextStyle(
                      color: Colors.blue,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),


              ],
            ),
          );
        },
      );
    }
  }

  Future<void> openCamera(String imageType) async {
    final image = await ImagePicker().pickImage(source: ImageSource.camera);
    if (image != null) {
      setState(() {
        if (imageType == 'Driving Licence') {
          selectedLicenseImage = image.path;
        } else if (imageType == 'ID Proof') {
          selectedIdProofImage = image.path;
        }
      });
    }
  }

  Future<void> openGallery(String imageType) async {
    final image = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        if (imageType == 'Driving Licence') {
          selectedLicenseImage = image.path;
        } else if (imageType == 'ID Proof') {
          selectedIdProofImage = image.path;
        }
      });
    }
  }

  void _showValidationErrorAlert(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Validation Error'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Close the dialog
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  String? _getEmptyField() {
    if (_nameController.text.isEmpty) {
      return 'Name';
    } else if (_phoneController.text.isEmpty) {
      return 'Phone';
    } else if (_emailController.text.isEmpty) {
      return 'Email';
    } else if (_currentAddressCityController.text.isEmpty) {
      return 'Current Address City';
    } else if (_currentAddressStreetController.text.isEmpty) {
      return 'Current Address Street';
    } else if (_currentAddressLandmarkController.text.isEmpty) {
      return 'Current Address Landmark';
    } else if (_currentAddresspincodeController.text.isEmpty) {
      return 'Current Address Pincode';
    }


    else if (selectedVendorType == 'none') {
      return 'Vendor Type';
    } else if (selectedGender == 'none') {
      return 'Gender';
    } else {
      return null;
    }
  }

  void _setLocale(String? value) {
    if(value == null ) return;

    if(value ==  "eng"){
      _FlutterLocalization.translate("eng");
    }  else if(value ==  "hi"){
      _FlutterLocalization.translate("hi");
    } else if(value ==  "mr"){
      _FlutterLocalization.translate("mr");
    }
    else {
      return;
    }

    setState(() {
      _currentLocale = value;
    });

  }

}
