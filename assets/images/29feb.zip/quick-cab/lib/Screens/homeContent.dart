import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_carousel_widget/flutter_carousel_widget.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:flutter_slider_drawer/flutter_slider_drawer.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:http/http.dart' as http;
import 'package:untitled/Screens/Tabs/trialtab/RefreshTab.dart';
import '../Constants/contants.dart';
import '../Constants/shared_service.dart';
import '../Controllers/CabLeadController.dart';
import '../Controllers/home_page_controller.dart';
import '../Localization/locals.dart';
import '../generated/assets.dart';
import '../models/advertsize_model.dart';
import '../models/leadss.dart';
import '../services/ApiServices.dart';
import 'DrawerScreens/edit_profile.dart';
import 'DrawerScreens/help_support_screen.dart';
import 'DrawerScreens/leads_history_tab.dart';
import 'DrawerScreens/manage_my_post.dart';
import 'DrawerScreens/post_a_lead.dart';

class HomeContaant extends StatefulWidget {
  const HomeContaant({super.key});

  @override
  State<HomeContaant> createState() => _HomeContaantState();
}

late Future<LeadsResponse> _leadsResponseFuture;
late ScrollController _scrollController;

List<String> apiImages = [];

List<String> tabIcons = [
  Assets.imagesCabImage,
  Assets.imagesDriverImage,
  Assets.imagesTowingRb,
  Assets.imagesPunctureRb,
  Assets.imagesCarRepairingRb,
  Assets.imagesFuelsRb,
  Assets.imagesResturantImage,
  Assets.imagesHospitalsRb,
];

List<String> title = [
  "Cab",
  "Drivers",
  "Puncture",
  "Repairing",
  "Towing",
  "Fuel",
  "Restaurant",
  "Emergeny",
];

class _HomeContaantState extends State<HomeContaant> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late final LeadsController _leadsController;
  final String apiUrl = 'http://10.0.2.2:3000/posts/active';
  late ScrollController _scrollController;
  late List<Lead> _leads;
  bool _isLoading = false;
  int _currentPage = 1;
  DateTime? selectedFromDate;
  DateTime? selectedToDate;
  TimeOfDay? selectedFromTime;
  TimeOfDay? selectedToTime;
  String? selectedLocationFilter;
  String? toLocationFilter;
  String? fromLocationFilter;
  List<String> locationFromValues = [];
  List<String> locationtoValues = [];
  bool isVisible = false;

  Constants constant = Constants();
  late FlutterLocalization _FlutterLocalization;

  late String _currentLocale;

  @override
  void initState() {
    super.initState();
    _FlutterLocalization = FlutterLocalization.instance;
    _currentLocale = _FlutterLocalization.currentLocale!.languageCode;
    print(_currentLocale);
    _leadsController = Get.put(LeadsController(tabname: "Cab"));
    _leadsController.fetchLeadsDatahomePagenew();
    ApiService().getUserDataFromToken();
    _fetchAdvertizeImages();
    _fetchDistinctLocations();
    _fetchDistinctLocationsto();
    _leads = [];
    _scrollController = ScrollController()..addListener(_scrollListener);
    _fetchLeads();
  }

  void _setLocale(String? value) {
    if (value == null) return;

    if (value == "eng") {
      _FlutterLocalization.translate("eng");
    } else if (value == "hi") {
      _FlutterLocalization.translate("hi");
    } else if (value == "mr") {
      _FlutterLocalization.translate("mr");
    } else {
      return;
    }

    setState(() {
      _currentLocale = value;
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollListener() {
    if (_scrollController.position.pixels ==
        _scrollController.position.maxScrollExtent) {
      _fetchLeads();
    }
  }

  Future<void> _fetchLeads() async {
    if (_isLoading) return;

    setState(() {
      _isLoading = true;
    });

    final response = await http.get(Uri.parse('$apiUrl?page=$_currentPage'));

    if (response.statusCode == 200) {
      final jsonData = json.decode(response.body);
      final leadsResponse = LeadsResponse.fromJson(jsonData);

      setState(() {
        _leads.addAll(leadsResponse.leads);
        _currentPage++;
        _isLoading = false;
      });
    } else {
      throw Exception('Failed to load leads');
    }
  }

  Future<void> _refreshLeads() async {
    _currentPage = 1;
    _leads.clear();
    await _fetchLeads();
  }

  String capitalize(String input) {
    if (input.isEmpty) {
      return input;
    }
    return input[0].toUpperCase() + input.substring(1);
  }

  @override
  Widget build(BuildContext context) {
    final HomeController controller = Get.put(HomeController());
    RxMap userData = controller.userData;
    var Profile_complete_percentage = 0.0;
    if (userData['fullname'] != null) {
      Profile_complete_percentage += 0.11;
    }
    if (userData['email'] != null) {
      Profile_complete_percentage += 0.11;
    }
    if (userData['phone'] != null) {
      Profile_complete_percentage += 0.11;
    }
    if (userData['vendor_gender'] != null) {
      Profile_complete_percentage += 0.12;
    }
    if (userData['documentImgUrl'] != null) {
      Profile_complete_percentage += 0.11;
    }
    if (userData['currentAddress'] != null) {
      Profile_complete_percentage += 0.11;
    }
    if (userData['permenantAddress'] != null) {
      Profile_complete_percentage += 0.11;
    }
    if (userData['vendor_cat'] != null) {
      Profile_complete_percentage += 0.11;
    }
    if (userData['licenseImgUrl'] != null) {
      Profile_complete_percentage += 0.11;
    }

    var vendorType = "${userData['vendor_cat']}";
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    print("${userData['status']} this is status of user  ");
    return Padding(
      padding: const EdgeInsets.only(top: 10.0),
      child: SliderDrawer(
        key: _scaffoldKey,
        appBar: SliderAppBar(
          appBarColor: Colors.white,
          title: Row(
            children: [
              Padding(
                padding: EdgeInsets.only(left: width * 0.08),
                child: Image.asset(
                  Assets.imagesQuickcabFinalHome,
                  height: height * 0.3,
                ),
              ),
            ],
          ),
        ),
        slider: Column(
          children: [
            Container(
              height: height * 0.3,
              width: width * 1.0,
              color: Colors.amberAccent,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: height * 0.028),
                  ClipOval(
                    child: Image.network(
                      'http://10.0.2.2:3000/${userData['profileImgUrl']}',
                      fit: BoxFit.fitWidth,
                      height: height * 0.15,
                      width: height * 0.15,
                      loadingBuilder: (BuildContext context, Widget child,
                          ImageChunkEvent? loadingProgress) {
                        if (loadingProgress == null) {
                          return child;
                        } else {
                          return Center(
                            child: CircularProgressIndicator(
                              value: loadingProgress.expectedTotalBytes != null
                                  ? loadingProgress.cumulativeBytesLoaded /
                                      (loadingProgress.expectedTotalBytes ?? 1)
                                  : null,
                            ),
                          );
                        }
                      },
                    ),
                  ),
                  SizedBox(height: height * 0.008),
                  Text(
                    "${userData['fullname']}",
                    style: TextStyle(
                        fontWeight: FontWeight.w600, fontSize: height * 0.025),
                  ),
                  SizedBox(height: height * 0.018),
                  Row(
                    children: [
                      SizedBox(
                        width: width * 0.050,
                      ),
                      Center(
                        child: LinearPercentIndicator(
                          width: MediaQuery.of(context).size.width * 0.57,
                          animation: true,
                          lineHeight: 18.0,
                          animationDuration: 2500,
                          percent: Profile_complete_percentage,
                          center: Text(
                            "${(Profile_complete_percentage * 100).toStringAsFixed(0)} %",
                            style: const TextStyle(color: Colors.black),
                          ),
                          linearStrokeCap: LinearStrokeCap.roundAll,
                          progressColor: Colors.green,
                          backgroundColor: Colors.white,
                        ),
                      ),
                      SizedBox(
                        height: height * 0.012,
                      )
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 5.50,
            ),
            const Divider(),
            ListTile(
                leading: const Icon(
                  Icons.person_3,
                  color: Colors.orange,
                  size: 29,
                ),
                title: Text(LocalData.MyProfile.getString(context),
                    style: TextStyle(fontSize: 19)),
                onTap: () {
                  Get.to(EditProfile(userId: userData['userId']));
                }),
            Visibility(
              visible: vendorType != "Cab" ? false : true,
              child: ListTile(
                onTap: () {
                  Get.to(ManageMyPost(
                    id: userData['userId'].toString(),
                    Vendor_cat: userData['vendor_cat'].toString(),
                  ));
                },
                leading: const Icon(
                  Icons.settings,
                  color: Colors.orange,
                  size: 29,
                ),
                title: Text(LocalData.ManagemyLeads.getString(context),
                    style: TextStyle(fontSize: 19)),
              ),
            ),
            ListTile(
              onTap: () {
                Get.to(const HistoryTab());
              },
              leading: const Icon(
                Icons.history,
                color: Colors.orange,
                size: 29,
              ),
              title: Text(LocalData.history.getString(context),
                  style: TextStyle(fontSize: 19)),
            ),
            Visibility(
              visible: vendorType != "Cab" ? false : true,
              child: ListTile(
                leading: const Icon(
                  Icons.upload_file,
                  color: Colors.orange,
                  size: 29,
                ),
                title: Text(LocalData.postLead.getString(context),
                    style: TextStyle(fontSize: 19)),
                onTap: () {
                  Get.to(const PostLead());
                },
              ),
            ),
            ListTile(
                trailing: DropdownButton(
                  onChanged: (value) {
                    print("hello");
                    print(value);
                    _setLocale(value);
                  },
                  items: const [
                    DropdownMenuItem(
                      value: "hi",
                      child: Text("हिन्दी"),
                    ),
                    DropdownMenuItem(
                      value: "eng",
                      child: Text("Eng"),
                    ),
                    DropdownMenuItem(
                      value: "mr",
                      child: Text("मराठी"),
                    ),
                    DropdownMenuItem(
                      value: "kan",
                      child: Text("ಕನ್ನಡ"),
                    ),
                  ],
                ),
                leading: const Icon(
                  Icons.language,
                  color: Colors.orange,
                  size: 29,
                ),
                title: Text(LocalData.Language.getString(context),
                    style: TextStyle(fontSize: 19)),
                onTap: () {}),
            ListTile(
              onTap: () {
                Get.to(HelpAndSupportPage());
              },
              leading: const Icon(
                Icons.help,
                color: Colors.orange,
                size: 29,
              ),
              title: Text(LocalData.helpAndSupport.getString(context),
                  style: TextStyle(fontSize: 19)),
            ),
            ListTile(
                leading: const Icon(
                  Icons.login_outlined,
                  color: Colors.orange,
                  size: 29,
                ),
                title: Text(LocalData.logout.getString(context),
                    style: TextStyle(fontSize: 19)),
                onTap: () {
                  SharedService().logout();
                }),
          ],
        ),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 4,
              ),
              FlutterCarousel(
                  items: apiImages.map((imageUrl) {
                    return Builder(
                      builder: (BuildContext context) {
                        return Container(
                          width: MediaQuery.of(context).size.width,
                          margin: const EdgeInsets.symmetric(horizontal: 5.0),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(19.0),
                            child: Image.network(
                              imageUrl != null
                                  ? 'http://10.0.2.2:3000/$imageUrl'
                                  : '',
                              fit: BoxFit.fill,
                              loadingBuilder: (BuildContext context,
                                  Widget child,
                                  ImageChunkEvent? loadingProgress) {
                                if (loadingProgress == null) {
                                  return child;
                                } else {
                                  return Center(
                                    child: CircularProgressIndicator(
                                      value:
                                          loadingProgress.expectedTotalBytes !=
                                                  null
                                              ? loadingProgress
                                                      .cumulativeBytesLoaded /
                                                  (loadingProgress
                                                          .expectedTotalBytes ??
                                                      1)
                                              : null,
                                    ),
                                  );
                                }
                              },
                            ),
                          ),
                        );
                      },
                    );
                  }).toList(),
                  options: CarouselOptions(
                    height: height * 0.24,
                    aspectRatio: 16 / 9,
                    viewportFraction: 1.0,
                    initialPage: 4,
                    enableInfiniteScroll: true,
                    reverse: false,
                    autoPlay: true,
                    autoPlayInterval: const Duration(seconds: 3),
                    autoPlayAnimationDuration:
                        const Duration(milliseconds: 500),
                    autoPlayCurve: Curves.elasticInOut,
                    enlargeCenterPage: false,
                    controller: CarouselController(),
                    pageSnapping: true,
                    scrollDirection: Axis.horizontal,
                    pauseAutoPlayOnTouch: true,
                    pauseAutoPlayOnManualNavigate: true,
                    pauseAutoPlayInFiniteScroll: false,
                    enlargeStrategy: CenterPageEnlargeStrategy.scale,
                    disableCenter: false,
                    showIndicator: true,
                    slideIndicator: const CircularSlideIndicator(),
                  )),
              SizedBox(
                height: height * 0.12,
                child: Padding(
                  padding: const EdgeInsets.only(top: 12.0),
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: tabIcons.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(
                        onTap: () {
                          controller.navigateToTab(index);
                          print("printing a Index  ${index} ");
                        },
                        child: Padding(
                          padding: EdgeInsets.only(left: width * 0.04, top: 7),
                          child: Column(
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(55),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.orange.withOpacity(0.0),
                                        spreadRadius: 0,
                                        blurRadius: 0,
                                        offset: const Offset(0, 0),
                                      ),
                                      BoxShadow(
                                        color: Colors.grey.withOpacity(0.5),
                                        spreadRadius: 1,
                                        blurRadius: 3,
                                        offset: const Offset(2, 0),
                                      ),
                                    ],
                                    color: index == 0
                                        ? Colors.amber
                                        : Colors.white),
                                child: Center(
                                  child: Image.asset(
                                    tabIcons[index],
                                    width: height * 0.06,
                                    height: height * 0.06,
                                  ),
                                ),
                              ),
                              SizedBox(
                                height: height * 0.003,
                              ),
                              Text(
                                index == 0
                                    ? LocalData.Cab.getString(context)
                                    : index == 1
                                        ? LocalData.Driver.getString(context)
                                        : index == 2
                                            ? LocalData.Towing.getString(
                                                context)
                                            : index == 3
                                                ? LocalData.Puncture.getString(
                                                    context)
                                                : index == 4
                                                    ? LocalData.Repairing
                                                        .getString(context)
                                                    : index == 5
                                                        ? LocalData.Fuel
                                                            .getString(context)
                                                        : index == 6
                                                            ? LocalData
                                                                    .Restaurant
                                                                .getString(
                                                                    context)
                                                            : index == 7
                                                                ? LocalData
                                                                        .Emergeny
                                                                    .getString(
                                                                        context)
                                                                : title[index],
                                style: TextStyle(
                                  fontSize: height * 0.018,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
              const Divider(),
              SizedBox(
                  height: height * 1.4, child: LeadpageScrollIndicatorPage()),
            ],
          ),
        ),
      ),
    );
  }

  void _fetchDistinctLocations() async {
    try {
      List<String> distinctLocations =
          await ApiService().fetchDistinctLocationFrom();
      setState(() {
        locationFromValues = distinctLocations;
      });
    } catch (error) {
      print('Error fetching distinct locations: $error');
      // Handle the error as needed
    }
  }

  void _fetchDistinctLocationsto() async {
    try {
      List<String> distinctLocationsto =
          await ApiService().fetchDistinctLocationto();
      setState(() {
        locationtoValues = distinctLocationsto;
      });
    } catch (error) {
      print('Error fetching distinct locations: $error');
    }
  }

  Future<void> _fetchAdvertizeImages() async {
    try {
      List<AdvertizeModel> advertizeModels =
          await ApiService().fetchAdvertizeModels();
      setState(() {
        apiImages = advertizeModels.map((model) => model.image).toList();
      });
    } catch (error) {
      print('Error fetching advertize images: $error');
    }
  }
}
