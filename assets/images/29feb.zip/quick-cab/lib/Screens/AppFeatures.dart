import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:onboarding/onboarding.dart';
import 'package:untitled/Localization/locals.dart';
import 'package:untitled/Screens/login_page.dart';
import 'package:untitled/generated/assets.dart';

class Features extends StatefulWidget {
  const Features({super.key});

  @override
  State<Features> createState() => _FeaturesState();
}

class _FeaturesState extends State<Features> {
  late Material materialButton;
  late int index;
  late FlutterLocalization _FlutterLocalization;

  late String _currentLocale;

  @override
  void initState() {
    super.initState();

    _FlutterLocalization = FlutterLocalization.instance;
    _currentLocale = _FlutterLocalization.currentLocale!.languageCode;
    materialButton = _skipButton();
    index = 0;
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;



    final List<PageModel> onboardingPagesList = [
      PageModel(
        widget: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              Padding(
                padding:  const EdgeInsets.only( left: 8.0,right: 18),
                child: Text(
                  LocalData.featuresTag.getString(context),
                  textAlign: TextAlign.start,
                  style: TextStyle(fontSize: height * 0.035,
                      fontWeight: FontWeight.w500
                  ),
                ),
              ),
              SizedBox(
                height:  height * 0.005,
              ),
              Text(
                LocalData.firstfeaturesContent.getString(context),
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: height * 0.018),
              ),
              SizedBox(
                height:  height * 0.084,
              ),
               Text(
                 LocalData.FeaturesList.getString(context),style: TextStyle(
                fontSize: height*0.021
              ), ),
              SizedBox(
                height:  height * 0.064,
              ),
               Text(
                 LocalData.FeaturesDescription.getString(context)
                 ,
              textAlign: TextAlign.start,
              style: TextStyle(
                fontSize: height *0.017,
              ),),
            ],
          ),
        ),
      ),

    ];


    void _setLocale(String? value) {
      if (value == null) return;

      if (value == "eng") {
        _FlutterLocalization.translate("eng");
      } else if (value == "hi") {
        _FlutterLocalization.translate("hi");
      }
      else if (value == "mr") {
        _FlutterLocalization.translate("mr");
      }  else if (value == "kan") {
        _FlutterLocalization.translate("kan");
      }
      else {
        return;
      }

      setState(() {
        _currentLocale = value;
      });
    }

    return Scaffold(
      appBar: AppBar(actions: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            DropdownButton(
              onChanged: (value) {
                print(value);
                _setLocale(value);
              },
              items: const [
                DropdownMenuItem(
                  value: "hi",
                  child: Text("HI"),
                ),
                DropdownMenuItem(
                  value: "eng",
                  child: Text("Eng"),
                ),
                DropdownMenuItem(
                  value: "mr",
                  child: Text("Mr"),
                ),
                DropdownMenuItem(
                  value: "kan",
                  child: Text("Kan"),
                ),
              ],
            ),

            Text(LocalData.Language.getString(context),style: const TextStyle()),
            const SizedBox(width: 15,)

          ],
        )
      ]),
      body: Onboarding(
        pages: onboardingPagesList,
        onPageChange: (int pageIndex) {
          index = pageIndex;
        },
        startPageIndex: 0,
        footerBuilder: (context, dragDistance, pagesLength, setIndex) {
          return DecoratedBox(
            decoration: BoxDecoration(
              color: background,
              border: Border.all(
                width: 0.0,
                color: Colors.red,
              ),
            ),
            child: ColoredBox(
              color: background,
              child: Padding(
                padding: const EdgeInsets.all(45.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomIndicator(
                      netDragPercent: dragDistance,
                      pagesLength: pagesLength,
                      indicator: Indicator(
                        indicatorDesign: IndicatorDesign.line(
                          lineDesign: LineDesign(
                            lineType: DesignType.line_uniform,
                          ),
                        ),
                      ),
                    ),
                    index == pagesLength - 1
                        ? _signupButton
                        : _skipButton(setIndex: setIndex)
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Material _skipButton({void Function(int)? setIndex}) {
    return Material(
      borderRadius: defaultSkipButtonBorderRadius,
      color: defaultSkipButtonColor,
      child: InkWell(
        borderRadius: defaultSkipButtonBorderRadius,
        onTap: () {
          if (setIndex != null) {
            index = 2;
            setIndex(2);
          }
        },
        child: const Padding(
          padding: defaultSkipButtonPadding,
          child: Text(
            "Skip",
            style: defaultSkipButtonTextStyle,
          ),
        ),
      ),
    );
  }

  Material get _signupButton {
    return Material(
      borderRadius: defaultProceedButtonBorderRadius,
      color: defaultProceedButtonColor,
      child: InkWell(
        borderRadius: defaultProceedButtonBorderRadius,
        onTap: () {
          Get.to(const LoginPage());
        },
        child: const Padding(
          padding: defaultProceedButtonPadding,
          child: Text(
            'Sign up',
            style: defaultProceedButtonTextStyle,
          ),
        ),
      ),
    );
  }
}
