import 'package:flutter/material.dart';

import '../generated/assets.dart';


class ForgetPassword extends StatefulWidget {
  const ForgetPassword({super.key});

  @override
  State<ForgetPassword> createState() => _ForgetPasswordState();
}

class _ForgetPasswordState extends State<ForgetPassword> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _otpController = TextEditingController();
  bool _isPasswordVisible = false;

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;

    return Scaffold(
      body: Container(
        color: Colors.orange,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          mainAxisSize: MainAxisSize.max,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Column(
              children: [
                SizedBox(height: height * 0.1),
                Container(
                  height: height * 0.125,
                  width: height * 0.135,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(26),
                  ),
                  child: Image.asset(Assets.imagesAppiconfinal, fit: BoxFit.cover,),
                ),
                SizedBox(
                  height: height * 0.005,
                ),
              ],
            ),
            const SizedBox(
              height: 55,
            ),
            Expanded(
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(45)),
                ),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formKey,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: height * 0.02,
                        ),
                        const Padding(
                          padding: EdgeInsets.only(left: 28),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Reset Password",
                                style: TextStyle(
                                    fontWeight: FontWeight.w800, fontSize: 25),
                              ),
                              Text(
                                "Enter the OTP received on your phone to reset your password.",
                                style: TextStyle(
                                    fontWeight: FontWeight.w500,
                                    fontSize: 15,
                                    color: Colors.blue),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: height * 0.062,
                        ),
                        Center(
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width * 0.8,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                const SizedBox(
                                  height: 20,
                                ),
                                TextFormField(
                                  controller: _otpController,
                                  decoration: const InputDecoration(
                                    labelText: 'OTP',
                                    border: OutlineInputBorder(),
                                    prefixIcon: Icon(Icons.sms),
                                  ),
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Please enter the OTP';
                                    } else if (!RegExp(r'^[0-9]+$')
                                        .hasMatch(value)) {
                                      return 'Please enter a valid OTP';
                                    }
                                    return null;
                                  },
                                ),
                              SizedBox(
                                height: height *0.11,
                              ),
                                MaterialButton(
                                  child: Container(
                                    height: height * 0.059,
                                    decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(22),
                                        gradient: const LinearGradient(
                                            colors: [Colors.orange, Colors.orange, Colors.orange, Colors.deepOrange])),
                                    child: Center(
                                      child: Text(
                                        'Reset Password',
                                        style: const TextStyle(
                                            fontSize: 24,
                                            color: Colors.white,
                                            fontWeight: FontWeight.w700),
                                      ),
                                    ),
                                  ),
                                  onPressed: () async {
                                    // Call the function to handle reset password logic
                                    _resetPassword();
                                  },
                                ),
                                SizedBox(
                                  height: height * 0.06,
                                ),
                                // Other Widgets (e.g., Log in button)
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Function to handle the reset password logic
  void _resetPassword() {
    if (_formKey.currentState!.validate()) {
      // Perform reset password operation
      // Here you can make an API call to your backend server to reset the password using the OTP entered by the user.
      // Display appropriate feedback to the user based on the API response.
    }
  }
}