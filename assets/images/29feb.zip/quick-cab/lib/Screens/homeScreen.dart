import 'package:flutter/material.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:get/get.dart';
import 'package:untitled/Screens/DrawerScreens/leads_history_tab.dart';
import 'package:untitled/Screens/DrawerScreens/manage_my_post.dart';
import '../Constants/contants.dart';
import '../Controllers/CabLeadController.dart';
import '../Controllers/home_page_controller.dart';
import '../Localization/locals.dart';
import '../services/ApiServices.dart';
import 'DrawerScreens/post_a_lead.dart';
import 'DrawerScreens/edit_profile.dart';
import 'homeContent.dart';
import 'no_internet_page.dart';

class HomePage extends StatefulWidget {
  HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  late final LeadsController _leadsController;
  late final HomeController _homeController;


  late FlutterLocalization _FlutterLocalization ;
   late String _currentLocale;

  int _selectedIndex = 0;

  @override
  void initState() {
    super.initState();
    _FlutterLocalization = FlutterLocalization.instance;
    _currentLocale  =  _FlutterLocalization.currentLocale!.languageCode;
    print(_currentLocale);

    _leadsController = Get.put(LeadsController(tabname: "Cab"));
    ApiService().getUserDataFromToken();

    _homeController = Get.put(HomeController());
    checkInternetAndFetchDetails();
  }



  @override
  Widget build(BuildContext context) {


    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: _buildBody(),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
        items: [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.home,
              size: height * 0.030,
            ),
            label:  LocalData.Home.getString(context),
            activeIcon: Icon(
              Icons.home,
              color: Colors.orange,
              size: height * 0.0447,
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.history,
              size: height * 0.030,
            ),
            label:  LocalData.history.getString(context),
            activeIcon: Icon(
              Icons.history,
              color: Colors.orange,
              size: height * 0.0447,
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.add_circle,
              size: height * 0.030,
            ),
            label: LocalData.postLead.getString(context),
            activeIcon: Icon(
              Icons.add_circle,
              color: Colors.orange,
              size: height * 0.0447,
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.post_add,
              size: height * 0.030,
            ),
            label:  LocalData.myLeads.getString(context),
            activeIcon: Icon(
              Icons.post_add,
              color: Colors.orange,
              size: height * 0.0447,
            ),
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.person,
              size: height * 0.030,
            ),
            label: LocalData.MyProfile.getString(context),
            activeIcon: Icon(
              Icons.person,
              color: Colors.orange,
              size: height * 0.0447,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    RxMap userData = _homeController.userData;

    switch (_selectedIndex) {
      case 0:
        return HomeContaant();
      case 1:
        return HistoryTab();
      case 2:
        return PostLead();
      case 3:
        return ManageMyPost(
            id: userData['userId'].toString(),
            Vendor_cat: userData['vendor_cat'].toString());
      case 4:
        return EditProfile(userId: userData['userId']);
      default:
        return Container();
    }
  }


  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  Future<void> checkInternetAndFetchDetails() async {
    bool isConnected = await Constants().checkInternetConnection();

    if (!isConnected) {
      Get.off(() => NoInternetPage());
    }
  }
}
