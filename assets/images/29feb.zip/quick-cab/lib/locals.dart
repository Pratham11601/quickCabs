// mixin LocalData {
//   static const String MyProfile = 'MyProfile';
//   static const String editProfile = 'editProfile';
//   static const String ManagemyLeads = 'ManagemyLeads';
//   static const String leadsHistory = 'leadsHistory';
//   static const String postNewLead   = 'postNewLead';
//   static const String helpAndSupport   = 'helpAndSupport';
//   static const String history   = 'history';
//   static const String postLead = 'Postlead';
//   static const String myLeads = 'myLeads';
//   static const String name = 'name';
//   static const String phone = 'Phone';
//   static const String email = 'Email';
//   static const String gender = 'gender';
//   static const String budniessAddress   = 'budniessAddress';
//   static const String savedetails   = 'savedetails';
//   static const String logout = 'logout';
//   static const String helpandsupport = 'helpandsupport';
//   static const String sendMessage   = 'Sendmessage';
//   static const String howcanweAssit   = 'howcanweAssityou';
//   static const String typeQuery   = 'typeQuery';
//   static const String active   = 'active';
//   static const String completed   = 'completed';
//   static const String Login   = 'Login';
//   static const String PersonDetails   = 'PersonDetails';
//   static const String firstname   = 'firstname';
//   static const String surname   = 'surname';
//   static const String male   = 'Male';
//   static const String female   = 'female';
//   static const String profileImage   = 'profileImage';
//   static const String capture   = 'capture';
//   static const String contine   = 'continue';
//   static const String cancle   = 'cancle';
//   static const String busniessname   = 'busniessname';
//   static const String category   = 'category';
//   static const String license   = 'license';
//   static const String document   = 'document';
//   static const String featureFirst   = 'featureFirst';
//
//
//
//
//
//   static Map<String, dynamic> HI = {
//     MyProfile: 'मेरी प्रोफ़ाइल',
//     editProfile: 'प्रोफ़ाइल संपादित करें',
//     ManagemyLeads: 'मेरे लीड्स प्रबंधित करें',
//     leadsHistory: 'लीड्स इतिहास',
//     postNewLead: 'नया लीड पोस्ट करें',
//     helpAndSupport: 'सहायता और समर्थन',
//     history: 'इतिहास',
//     postLead: 'लीड पोस्ट करें',
//     myLeads: 'मेरे लीड्स',
//     name: 'नाम',
//     phone: 'फ़ोन',
//     email: 'ईमेल',
//     gender: 'लिंग',
//     budniessAddress: 'व्यवसाय पता',
//     savedetails: 'विवरण सहेजें',
//     logout: 'लॉग आउट',
//     helpandsupport: 'सहायता और समर्थन',
//     sendMessage: 'संदेश भेजें',
//     howcanweAssit: 'हम आपकी कैसे मदद कर सकते हैं',
//     typeQuery: 'प्रश्न टाइप करें',
//     active: 'सक्रिय',
//     completed: 'पूरा हो गया',
//     Login: 'लॉग इन करें',
//     PersonDetails: 'व्यक्ति विवरण',
//     firstname: 'पहला नाम',
//     surname: 'उपनाम',
//     male: 'पुरुष',
//     female: 'महिला',
//     profileImage: 'प्रोफ़ाइल छवि',
//     capture: 'कैप्चर करें',
//     contine: 'जारी रखें',
//     cancle: 'रद्द करें',
//     busniessname: 'व्यापार का नाम',
//     category: 'श्रेणी',
//     license: 'लाइसेंस',
//     document: 'दस्तावेज़'
//   };
//
//   static Map<String, dynamic> MR = {
//     MyProfile: 'माझं प्रोफाइल',
//     editProfile: 'प्रोफाइल संपादित करा',
//     ManagemyLeads: 'माझे लीड्स व्यवस्थापित करा',
//     leadsHistory: 'लीड्स इतिहास',
//     postNewLead: 'नवीन लीड पोस्ट करा',
//     helpAndSupport: 'सहाय्य आणि समर्थन',
//     history: 'इतिहास',
//     postLead: 'लीड पोस्ट करा',
//     myLeads: 'माझे लीड्स',
//     name: 'नाव',
//     phone: 'फोन',
//     email: 'ईमेल',
//     gender: 'लिंग',
//     budniessAddress: 'व्यवसाय पत्ता',
//     savedetails: 'तपशील साठवा',
//     logout: 'लॉगआउट',
//     helpandsupport: 'सहाय्य आणि समर्थन',
//     sendMessage: 'संदेश पाठवा',
//     howcanweAssit: 'आम्ही आपली कसे मदत करू शकतो',
//     typeQuery: 'प्रश्न टाइप करा',
//     active: 'सक्रिय',
//     completed: 'पूर्ण',
//     Login: 'लॉगिन करा',
//     PersonDetails: 'व्यक्तीचे तपशील',
//     firstname: 'पहिले नाव',
//     surname: 'आडनाव',
//     male: 'पुरुष',
//     female: 'स्त्री',
//     profileImage: 'प्रोफाइल चित्र',
//     capture: 'कॅप्चर करा',
//     contine: 'सुरू ठेवा',
//     cancle: 'रद्द करा',
//     busniessname: 'व्यवसाय नाव',
//     category: 'वर्ग',
//     license: 'परवाना',
//     document: 'दस्तऐवज'
//   };
//
//
// }
