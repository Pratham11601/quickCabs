import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

Widget buildEditableTextField({
  required IconData icon,
  required String title,
  required TextEditingController controller,
  bool enabled = true,
  VoidCallback? onTap,
}) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 8.0),
    child: ListTile(
      leading: Icon(
        icon,
        size: 38,
      ),
      title: Text(
        title,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w700,
        ),
      ),
      subtitle: TextField(
        controller: controller,
        enabled: enabled,
        onTap: onTap,
        decoration: InputDecoration(
          border: InputBorder.none,
        ),
      ),
    ),
  );
}