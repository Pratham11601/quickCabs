import 'package:autocomplete_textfield/autocomplete_textfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:untitled/Screens/Tabs/CabLeadsList.dart';
import 'package:untitled/models/leadss.dart';
import 'package:untitled/services/ApiServices.dart';
import '../Constants/contants.dart';
import '../Screens/DrawerScreens/manage_my_post.dart';
import '../Screens/Tabs/Cabstab.dart';
import '../Screens/homeScreen.dart';
import '../models/leads_listing.dart';

class EditPostDialog extends StatefulWidget {
  final Lead post;


  EditPostDialog({required this.post});

  @override
  _EditPostDialogState createState() => _EditPostDialogState();
}

class _EditPostDialogState extends State<EditPostDialog> {
  late TextEditingController vendorCatController;
  late TextEditingController LeadId;
  late TextEditingController dateController;
  late TextEditingController timeController;
  late TextEditingController locationFromController;
  late TextEditingController toLocationController;
  late TextEditingController cabNumberController;
  late TextEditingController vendorCatIdController;
  late bool isActive;

  Map<String, dynamic> getCurrentState() {
    return {
      'dateController': dateController.text,
      'timeController': timeController.text,
      'locationFromController': locationFromController.text,
      'toLocationController': toLocationController.text,
      'isActive': isActive,
    };
  }


  GlobalKey<AutoCompleteTextFieldState<String>> keyto = GlobalKey();
  GlobalKey<AutoCompleteTextFieldState<String>> keyfrom = GlobalKey();


  DateTime selectedDate = DateTime.now();
  TimeOfDay selectedTime = TimeOfDay.now();

  @override
  void initState() {
    super.initState();
    vendorCatController = TextEditingController(text: widget.post.vendorCat ?? "");
    LeadId = TextEditingController(text: widget.post.id.toString() ?? '0');
    dateController = TextEditingController(text: widget.post.date ?? "");
    timeController = TextEditingController(text: widget.post.time ?? "");
    locationFromController = TextEditingController(text: widget.post.locationFrom ?? "");
    toLocationController = TextEditingController(text: widget.post.toLocation ?? "");
    isActive = widget.post.isActive ?? false;
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );

    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
        dateController.text = DateFormat('dd-MM-yyyy').format(selectedDate);
      });
    }
  }

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );

    if (picked != null && picked != selectedTime) {
      setState(() {
        selectedTime = picked;
        timeController.text = selectedTime.format(context);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(

      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: dateController,
              onTap: () {
                _selectDate(context);
              },
              readOnly: true,
              decoration: const InputDecoration(labelText: 'Date'),
            ),

            TextField(
              controller: timeController,
              onTap: () {
                _selectTime(context);
              },
              readOnly: true,
              decoration: const InputDecoration(labelText: 'Time'),
            ),
            SizedBox(
              height: 15,
            ),
            AutoCompleteTextField<String>(
              key: keyto,
              controller: locationFromController,
              clearOnSubmit: false,
              suggestions: Constants().suggestions,
              decoration: InputDecoration(
                labelText: 'From',
                border: OutlineInputBorder(),
              ),
              itemBuilder: (context, suggestion) => ListTile(
                title: Text(suggestion),
              ),
              itemSorter: (a, b) => a.compareTo(b),
              itemFilter: (suggestion, input) =>
                  suggestion.toLowerCase().startsWith(input.toLowerCase()),
              itemSubmitted: (item) {
                setState(() {
                  locationFromController.text = item;
                });
              },
            ),
            SizedBox(
              height: 15,
            ),
            AutoCompleteTextField<String>(

              key: keyfrom,
              controller: toLocationController,
              clearOnSubmit: false,
              suggestions: Constants().suggestions,
              decoration: InputDecoration(
                labelText: 'to location',
                border: OutlineInputBorder(),
              ),
              itemBuilder: (context, suggestion) => ListTile(
                title: Text(suggestion),
              ),
              itemSorter: (a, b) => a.compareTo(b),
              itemFilter: (suggestion, input) =>
                  suggestion.toLowerCase().startsWith(input.toLowerCase()),
              itemSubmitted: (item) {
                setState(() {
                  toLocationController.text = item;
                });
              },
            ),
            SwitchListTile(
              activeColor: Colors.orange,
              title: const Text('Active '),
              value: isActive,
              onChanged: (value) {
                print("Switch toggled: $value");
                setState(() {
                  isActive = value;
                });
              },
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () async {
            print("Hello");

            String formattedDate =
                DateFormat('dd/MM/yyyy').format(selectedDate);
            String formattedTime = selectedTime.format(context);

            await ApiService().updateMyLead(
              id: LeadId.text,
              vendorCat: vendorCatController.text,
              date: formattedDate,
              time: formattedTime,
              locationFrom: locationFromController.text,
              toLocation: toLocationController.text,
              isActive: isActive,
            );

            showToast(
              "Lead Edited Successfully! check Once",
              context: context,
              animation: StyledToastAnimation.scale,
              reverseAnimation: StyledToastAnimation.size,
              position: StyledToastPosition.top,
              animDuration: Duration(seconds: 1),
              duration: Duration(seconds: 3),
              curve: Curves.elasticOut,
              reverseCurve: Curves.linear,
            );


            setState(() {
              Navigator.pop(context);
            });

            Get.to(CabsTab());
          },

          child: const Text('Save'),
        ),

      ],
    );
  }
}
