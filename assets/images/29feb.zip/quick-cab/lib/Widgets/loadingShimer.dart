import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:untitled/generated/assets.dart';

Widget LoadingWidget ( double height, double width) => Lottie.asset(Assets.animationsLoadingShimmer);