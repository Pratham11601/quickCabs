
class Routes{
  static const String HOME_PAGE = '/home';
  static const String LOGIN_PAGE = '/login';
  static const String REGISTRATION_PAGE = '/registration_screen';
  static const String OTP_VERIFICATION = '/otp_verification_screen';
  static const String CAB_PAGE = '/cab_screen';
  static const String CAR_REPAIRING_PAGE = '/car_repairing_screen';
  static const String DRIVER_PAGE = '/driver_screen';
  static const String FUEL_PAGE = '/fuel_screen';
  static const String HOSPITAlS_PAGE = '/hospitals_screen';
  static const String HOTELS_PAGE = '/hotels_screen';
  static const String PUNCTURE_PAGE = '/puncture_screen';
  static const String RESTURANTS_PAGE = '/restorants_screen';
  static const String TOWING_PAGE = '/towing_screen';
}