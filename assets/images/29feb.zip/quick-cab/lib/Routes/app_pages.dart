import 'package:get/get.dart';
import 'package:untitled/Routes/routes.dart';
import '../Screens/login_page.dart';
import '../Screens/registeration_page.dart';


class AppPages {

  static final routes = [
    GetPage(name: Routes.REGISTRATION_PAGE, page: () => const RegistrationsPage()),
    GetPage(name: Routes.LOGIN_PAGE, page: () => const LoginPage()),
  ];
}
