import 'package:api_cache_manager/api_cache_manager.dart';
import 'package:api_cache_manager/utils/cache_manager.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled/Screens/login_page.dart';

class SharedService {
  static const String KEY_NAME = 'login_key';

  static Future<bool> isLoggedIn() async {
    var isCacheKeyExist = await APICacheManager().isAPICacheKeyExist(KEY_NAME);

    print('Is Logged In: $isCacheKeyExist');
    return isCacheKeyExist;
  }

  Future<void> logout() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    print(prefs);

    prefs.clear();

    if (prefs == null) {
      print(prefs);
    }

    Get.to(LoginPage());
  }




}
