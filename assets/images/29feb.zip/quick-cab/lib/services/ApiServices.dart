import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart' as dioPackage;
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:flutter_styled_toast/flutter_styled_toast.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:untitled/Screens/Tabs/Cabstab.dart';
import 'package:untitled/Screens/homeScreen.dart';
import '../Controllers/home_page_controller.dart';
import '../models/advertsize_model.dart';
import '../models/leadss.dart';

class ApiService {
  var client = http.Client();
  var APIUrl = "http://10.0.2.2:3000";
  final dioPackage.Dio dioInstance = dioPackage.Dio();


  Future<LeadsResponse> fetchActiveLeads(int pageSize) async {
    int currentPage = 1;

    try {
      final response = await dioInstance.get(
        '$APIUrl/posts/active',
        queryParameters: {
          'page': currentPage,
          'pageSize': pageSize,
        },
      );

      if (response.statusCode == 200) {
        currentPage++;
        return LeadsResponse.fromJson(response.data);
      } else {
        throw Exception('Failed to fetch active leads');
      }
    } catch (error) {
      print('Error fetching active leads: $error');
      throw Exception('Something went wrong');
    }
  }

  Future<List<AdvertizeModel>> fetchAdvertizeModels() async {
    try {
      final apiUrl = '$APIUrl/advertise';
      final response = await client.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        final List<dynamic> responseData = json.decode(response.body);
        List<AdvertizeModel> advertizeModels = responseData
            .map((json) => AdvertizeModel.fromJson(json))
            .toList();

        return advertizeModels;
      } else {
        throw Exception('Failed to load advertize models: ${response.statusCode}');
      }
    } catch (error) {
      print('Error fetching advertize models: $error');
      throw Exception('Error fetching advertize models: $error');
    }
  }

  Future<String?> fetchUserProfileImageUrl(int UserId) async {
    try {
      final apiUrl = '$APIUrl/vendorDetails/get/$UserId';
      final response = await client.post(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        final Map<String, dynamic> imageData = json.decode(response.body);

        print(imageData);

        return imageData['profileImgUrl']?.toString();
      } else {
        throw Exception('Failed to load image URL: ${response.statusCode}');
      }
    } catch (error) {
      print('Error fetching image URL: $error');
      throw Exception('Error fetching image URL: $error');
    }
  }

  Future<String> fetchVendorDetailsByIdforeditProfile(int vendorId) async {
    try {
      final apiUrl = '$APIUrl/vendorDetails/get/$vendorId';
      final response = await client.post(Uri.parse(apiUrl));

      print(response.statusCode);

      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = json.decode(response.body);
        final Map<String, dynamic> vendorDetails = responseData['vendor'];
        var name = vendorDetails['fullname'].toString();
        print("response.body $response.body");
        return name;
      } else {
        throw Exception('Failed to load vendor details: ${response.statusCode}');
      }
    } catch (error) {
      print('Error fetching vendor details: $error');
      throw Exception('Error fetching vendor details: $error');
    }
  }

  Future<void> postData(dioPackage.FormData formData) async {
    final String apiUrl = '$APIUrl/vendorDetails';

    try {
      print('POST Request Payload: $formData');

      final response = await dioInstance.post(
        apiUrl,
        data: formData,
      );

      print('Response Status Code: ${response.statusCode}');

      if (response.statusCode == 201) {
        print('Data posted successfully');

        Get.snackbar(
          "Please Login to get Start",
          "Enter your Credentials",
        );
      } else {
        print('Failed to post data: ${response.statusCode}');
        // Handle failure as needed
        // You might want to inspect the response body for more information
        print('Response Body: ${response.data}');
      }
    } catch (error) {
      print('Error posting data: $error');
      // Handle error as needed
    }
  }

  Future<void> help_support_send(String queryMessage, int vendor_id, String vendor_name, String vendor_category, String vendor_contact) async {final String apiUrl = 'http://10.0.2.2:3000/help_support';

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'query_message': queryMessage,
        'vendor_category': vendor_category?? " ",
        'vendor_id': vendor_id?? " ",
        'vendor_name': vendor_name?? " ",
        'vendor_contact': vendor_contact?? " ",
      }),
    );

    if (response.statusCode == 201) {
      debugPrint('Data saved successfully');

      Get.snackbar("Thank you for submitting your query! We will contact you soon." ,"",snackPosition: SnackPosition.BOTTOM  );
    } else {
      debugPrint('Failed to save data. Status code: ${response.statusCode}');
    }
  }

  Future<bool> loginUser(String phone, String password) async {
    try {
      final response = await client.post(
        Uri.parse('$APIUrl/vendorDetails/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "phone": phone,
          "password": password,
        }),
      );
      print("API Hitted");
      print(response.statusCode);
      if (response.statusCode == 200) {
        Map<String, dynamic> userData = json.decode(response.body);
        await saveUserDataInSharedPreferences(userData);

        Get.to(HomePage());
        return true;
      } else {
        Get.snackbar(
            'Login Failed', 'Please Check your Password and Phone number',
            backgroundColor: Colors.red,
            snackPosition: SnackPosition.BOTTOM,
            colorText: Colors.white);

        print('Failed to login: ${response.statusCode}');
        return false;
      }
    } catch (error) {
      print('Error during login: $error');
      return false;
    }
  }

  Future<void> updateLeadStatus(int leadId, bool isActive) async {
    final String apiUrl = '$APIUrl/posts/$leadId';

    try {
      final http.Response response = await http.patch(
        Uri.parse(apiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'is_active': isActive}),
      );

      if (response.statusCode == 200) {
        print('Lead status updated successfully for leadId: $leadId');
      } else {
        throw Exception('Failed to update lead status: ${response.statusCode}');
      }
    } catch (error) {
      print('Error updating lead status: $error');
      throw Exception('Error updating lead status: $error');
    }
  }

  Future<void> refreshUserToken() async {
    try {
      Map<String, dynamic> userData = await getUserDataFromToken();
      String refreshToken = userData['refreshToken'];

      final response = await client.post(
        Uri.parse('$APIUrl/vendorDetails/refresh-token'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "refreshToken": refreshToken,
        }),
      );

      if (response.statusCode == 200) {
        Map<String, dynamic> refreshedData = json.decode(response.body);
        await saveUserDataInSharedPreferences(refreshedData);
      } else {
        throw Exception('Failed to refresh token: ${response.statusCode}');
      }
    } catch (error) {
      print('Error refreshing user token: $error');
      throw Exception('Error refreshing user token: $error');
    }
  }

  Future<Map<String, dynamic>> updateMyLead({required String id, required String vendorCat, required String date, required String time, required String locationFrom, required String toLocation, required bool isActive,}) async {
    final String apiUrl = '${APIUrl}/posts/$id';

    try {
      final Map<String, dynamic> updatedPostData = {
        'vendor_cat': vendorCat,
        'date': date,
        'time': time,
        'location_from': locationFrom,
        'to_location': toLocation,
        'is_active': isActive,
      };

      final http.Response response = await http.patch(
        Uri.parse('$apiUrl'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: json.encode(updatedPostData),
      );

      print(response.statusCode);

      final Map<String, dynamic> responseData = json.decode(response.body);

      if (response.statusCode == 200) {
        print("done");
        print('Updated Post Data: $updatedPostData');

        return {
          'success': true,
          'message': 'Lead updated successfully',
          'post': responseData,
        };
      } else if (response.statusCode == 404) {
        return {
          'success': false,
          'message': 'Post not found',
        };
      } else {
        return {
          'success': false,
          'message': 'Unexpected result during post update',
        };
      }
    } catch (error) {
      return {
        'success': false,
        'message': 'Failed to update post',
        'error': error.toString(),
      };
    }
  }

  Future<Map<String, dynamic>> fetchVendorDetailsById(int vendorId) async {
    final apiUrl = '$APIUrl/vendorDetails/get/$vendorId';

    try {
      final response = await client.post
        (Uri.parse(apiUrl));

      print(response.statusCode);

      if (response.statusCode == 200) {
        final Map<String, dynamic> vendorDetails = json.decode(response.body);

        print("response.body $response.body");

        return vendorDetails;
      } else {
        throw Exception(
            'Failed to load vendor details: ${response.statusCode}');
      }
    } catch (error) {
      print('Error fetching vendor details: $error');
      throw Exception('Error fetching vendor details: $error');
    }
  }

  Future<List<String>> fetchLocations() async {
    try {
      final response = await client.get(
        Uri.parse('$APIUrl/posts/from'),
      );

      if (response.statusCode == 200) {
        List<String> locations = (json.decode(response.body) as List)
            .map((location) => location.toString())
            .toList();
        return locations;
      } else {
        throw Exception('Failed to load location options');
      }
    } catch (error) {
      print('Error fetching location options: $error');
      throw Exception('Error fetching location options: $error');
    }
  }

  Future<Map<String, dynamic>> checkPhoneNumberExistence(String phone, BuildContext context) async {
    try {
      final response = await client.post(
        Uri.parse('$APIUrl/vendorDetails/check'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          "phone": phone,
        }),
      );

      if (response.statusCode == 200) {
        showToast(
          "OTP Sending,Please Verify to Proceed",
          context: context,
          animation: StyledToastAnimation.scale,
          reverseAnimation: StyledToastAnimation.size,
          position: StyledToastPosition.bottom,
          animDuration: Duration(seconds: 1),
          duration: Duration(seconds: 3),
          curve: Curves.elasticOut,
          reverseCurve: Curves.linear,
        );

        return {
          'exists': false,
          'message': 'Phone number available for registration.',
        };
      } else if (response.statusCode == 409) {
        showToast(
          'This number is Register Please try with another',
          context: context,
          position: StyledToastPosition.bottom,
          animDuration: Duration(seconds: 1),
          duration: Duration(seconds: 3),
          curve: Curves.elasticOut,
          reverseCurve: Curves.linear,
        );

        return {
          'exists': true,
          'message': 'Phone number already in use.',
        };
      } else {
        showToast(
          'Network Error Please Try Later',
          context: context,
          animation: StyledToastAnimation.scale,
          reverseAnimation: StyledToastAnimation.size,
          position: StyledToastPosition.bottom,
          animDuration: Duration(seconds: 1),
          duration: Duration(seconds: 3),
          curve: Curves.elasticOut,
          reverseCurve: Curves.linear,
        );
        throw Exception('Failed to check phone number: ${response.statusCode}');
      }
    } catch (error) {
      print('Error checking phone number existence: $error');
      throw Exception('Error checking phone number existence: $error');
    }
  }

  Future<Map<String, dynamic>> getUserDataById(int userId) async {
    try {
      final response = await client.post(
        Uri.parse('$APIUrl/vendorDetails/get/$userId'),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> userData = json.decode(response.body);
        return userData;
      } else {
        throw Exception('Failed to load user data');
      }
    } catch (error) {
      print('Error getting user data: $error');
      throw Exception('Error getting user data: $error');
    }
  }

  Future<void> saveUserDataInSharedPreferences(Map<String, dynamic> userData) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    prefs.setInt('userId', userData['userId']);
    prefs.setString('token', userData['token']);

    print('userId, ${userData['userId']}');
    print('userId, ${userData['token']}');
    print('other Data, ${userData['message']}');
  }

  Future<void> saveUserDataInSharedPreferencess(Map<String, dynamic> userData) async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('fullname', userData['fullname']);
      await prefs.setString('email', userData['email']);
      await prefs.setString('phone', userData['phone']);
      await prefs.setString('permanentAddress', userData['permanentAddress']);
      await prefs.setString('currentAddress', userData['currentAddress']);

      print('User data saved to SharedPreferences');
    } catch (error) {
      print('Error saving user data to SharedPreferences: $error');
      throw Exception('Error saving user data to SharedPreferences: $error');
    }
  }

  Future<void> updateUserData(String email, String currentAddress) async {
    try {
      Map<String, dynamic> userData = await getUserDataFromToken();
      int userId = userData['userId'];

      print(userData['userId']);
      final response = await client.patch(
        Uri.parse('$APIUrl/vendorDetails/$userId'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "email": email,
          "currentAddress": currentAddress,
        }),
      );

      if (response.statusCode == 200) {
        userData = await getUserDataById(userId);
      } else {
        print('Failed to update  ${response.statusCode}');
        throw Exception('Failed to update  ${response.statusCode}');
      }
    } catch (error) {
      print('Error updating user data: $error');
      throw Exception('Error updating user data: $error');
    }
  }

  Future<void> postLead(Map<String, dynamic> formData, String tabname, double heightOficon) async {
    try {
      final response = await http.post(
        Uri.parse('$APIUrl/posts/'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode(formData),
      );

      if (response.statusCode == 201) {
        print('Lead posted successfully');
        print(formData);
        Get.snackbar(
          "Posting Your Lead",
          " Please Check ",
          duration: Duration(seconds: 2),
          snackPosition: SnackPosition.BOTTOM,
          icon: Icon(
            Icons.upload_rounded,
            size: heightOficon,
            color: Colors.orangeAccent,
          ),
        );

        Timer(Duration(seconds: 1), () {
          Get.to(CabsTab());
        });
      } else {
        print('Failed to post lead: ${response.statusCode}');
        throw Exception('Failed to post lead: ${response.statusCode}');
      }
    } catch (error) {
      print('Error posting lead: $error');
      throw Exception('Error posting lead: $error');
    }
  }

  Future<String> fetchLeadsData() async {
    var response = await client.get(Uri.parse('$APIUrl/posts/'));

    if (response.statusCode == 200) {
      return response.body;
    } else {
      throw Exception('Failed to load leads data');
    }
  }

  Future<String> fetchLeadsDataActive() async {
    var response = await client.get(Uri.parse('$APIUrl/posts/active'
        ''));

    if (response.statusCode == 200) {
      return response.body;

    } else {
      throw Exception('Failed to load leads data');
    }
  }

  Future<String> fetchLeadsDataActivenext() async {
    var response = await client.get(Uri.parse('$APIUrl/posts/nextfive'));








    if (response.statusCode == 200) {
      return response.body;

    } else {
      throw Exception('Failed to load leads data');
    }
  }

  Future<List<String>> fetchDistinctLocationFrom() async {
    try {
      final response = await client.get(
        Uri.parse('$APIUrl/posts/from'),
      );

      if (response.statusCode == 200) {
        print('Response body: ${response.body}');

        // Parse the response JSON
        final Map<String, dynamic> responseData = json.decode(response.body);

        // Extract the list from the 'locationFromValues' key
        List<String> distinctLocations =
            (responseData['locationFromValues'] as List)
                .map((location) => location.toString())
                .toList();

        return distinctLocations;
      } else {
        throw Exception('Failed to load distinct locationFrom values');
      }
    } catch (error) {
      print('Error fetching distinct locationFrom values: $error');
      throw Exception('Error fetching distinct locationFrom values: $error');
    }
  }

  Future<List<String>> fetchDistinctLocationto() async {
    try {
      final response = await client.get(
        Uri.parse('$APIUrl/posts/to'),
      );

      if (response.statusCode == 200) {
        print('Response body: ${response.body}');

        final Map<String, dynamic> responseData = json.decode(response.body);

        // Extract the list from the 'locationFromValues' key
        List<String> distinctLocations =
            (responseData['locationtoValues'] as List)
                .map((location) => location.toString())
                .toList();

        return distinctLocations;
      } else {
        throw Exception('Failed to load distinct locationtoValues values');
      }
    } catch (error) {
      print('Error fetching distinct locationtoValues values: $error');
      throw Exception(
          'Error fetching distinct locationtoValues values: $error');
    }
  }

  Future<String> fetchVendorsData() async {
    var response = await client.get(Uri.parse('$APIUrl/vendorDetails/'));

    if (response.statusCode == 200) {
      return response.body;
    } else {
      throw Exception('Failed to load leads data');
    }
  }

  Future<Map<String, dynamic>> getUserDataFromToken() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? token = prefs.getString('token');

    if (token != null) {
      try {
        List<String> tokenParts = token.split('.');

        String decodedPayload = utf8.decode(base64Url.decode(
            tokenParts[1].padRight((tokenParts[1].length + 3) ~/ 4 * 4, '=')));

        final Map<String, dynamic> decodedPayloadMap = json.decode(decodedPayload);

        Get.find<HomeController>().updateUserData(decodedPayloadMap);

        return decodedPayloadMap;
      } catch (e) {
        if (e is FormatException) {
          print('Format error: $e');
        } else {
          print('Other decoding error: $e');
        }
        throw Exception('Error decoding token: $e');
      }
    } else {
      throw Exception('Token not found');
    }
  }


  void dispose() {
    client.close();
    dioInstance.close();

  }
}
