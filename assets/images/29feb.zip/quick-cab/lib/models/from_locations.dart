
import 'dart:convert';

FromLocations fromLocationsFromJson(String str) => FromLocations.fromJson(json.decode(str));

String fromLocationsToJson(FromLocations data) => json.encode(data.toJson());

class FromLocations {
    FromLocations({
        required this.locationFromValues,
        required this.message,
    });

    List<String> locationFromValues;
    String message;

    factory FromLocations.fromJson(Map<String, dynamic> json) => FromLocations(
        locationFromValues: List<String>.from(json["locationFromValues"].map((x) => x)),
        message: json["message"],
    );

    Map<String, dynamic> toJson() => {
        "locationFromValues": List<String>.from(locationFromValues.map((x) => x)),
        "message": message,
    };
}
