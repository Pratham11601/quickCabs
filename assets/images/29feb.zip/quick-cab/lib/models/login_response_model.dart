class LoginResponseModel {
  late final String message;
  late final Data data;

  LoginResponseModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    data = Data.fromJson(json["data"]);
  }
}

class Data {
  late final String fullname;
  late final String phone;
  late final String email;
  late final int id;

  Data({
    required this.fullname,
    required this.phone,
    required this.email,
    required this.id,
  });

  Data.fromJson(Map<String, dynamic> json) {
    phone = json['phone'];
    fullname = json['fullname'];
    email = json['email'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() {
    final _data = <String, dynamic>{};

    _data['fullname'] = fullname;
    _data['id'] = id;
    _data['phone'] = phone;
    _data['email'] = email;

    return _data;
  }
}
