
import 'dart:convert';

ToLocation fromLocationsFromJson(String str) => ToLocation.fromJson(json.decode(str));

String fromLocationsToJson(ToLocation data) => json.encode(data.toJson());

class ToLocation {
  ToLocation({
    required this.locationtoValues,
    required this.message,
  });

  List<String> locationtoValues;
  String message;

  factory ToLocation.fromJson(Map<String, dynamic> json) => ToLocation(
    locationtoValues: List<String>.from(json["locationFromValues"].map((x) => x)),
    message: json["message"],
  );

  Map<String, dynamic> toJson() => {
    "locationFromValues": List<String>.from(locationtoValues.map((x) => x)),
    "message": message,
  };
}
