import 'dart:convert';

LeadsListing leadsListingFromJson(String str) =>
    LeadsListing.fromJson(json.decode(str));

String leadsListingToJson(LeadsListing data) => json.encode(data.toJson());

class LeadsListing {
  LeadsListing({
    required this.result,
    required this.message,
  });

  List<Result> result;
  String message;

  factory LeadsListing.fromJson(Map<dynamic, dynamic> json) => LeadsListing(
        result:
            List<Result>.from(json["result"].map((x) => Result.fromJson(x))),
        message: json["message"],
      );

  Map<dynamic, dynamic> toJson() => {
        "result": List<dynamic>.from(result.map((x) => x.toJson())),
        "message": message,
      };
}

class Result {
  Result({

    required this.date,
    this.vendorCat,
    required this.createdAt,
    this.is_active,
    this.toLocation,
    this.vendorCatId,
    this.locationFrom,
    required this.vendorId,
    this.vendorName,
    this.vendor_contact,
    required this.id,
    required this.time,
    required this.updatedAt,
  });

  String? date;
  DateTime createdAt;
  bool? is_active;
  String? toLocation;
  int? vendorCatId;
  String? vendorCat;
  String? vendor_contact;
  String? locationFrom;
  int vendorId;
  String? vendorName;
  int id;
  String? time;
  DateTime updatedAt;

  factory Result.fromJson(Map<dynamic, dynamic> json) => Result(
        date: json["date"] ?? " ",
        createdAt: DateTime.parse(json["createdAt"] ?? " "),
        is_active: json["is_active"] ?? false,
        toLocation: json["to_location"] ?? " ",
        locationFrom: json["location_from"] ?? " ",
    vendor_contact: json["vendor_contact"] ?? " ",
    vendorId: json["vendor_id"] is int ? json["vendor_id"] : int.tryParse(json["vendor_id"].toString()) ?? 0,

    vendorCat: json["vendor_cat"] ?? " ",
        vendorName: json["vendor_name"] ?? " ",
        id: json["id"] ?? 7,
        time: json["time"] ?? " ",
        updatedAt: DateTime.parse(json["updatedAt"] ?? " "),
      );

  Map<dynamic, dynamic> toJson() => {
        "date": date,
        "createdAt": createdAt.toIso8601String(),
        "is_active": is_active,
        "to_location": toLocation,
        "vendor_cat_id": vendorCatId,
        "location_from": locationFrom,
        "vendor_contact": vendor_contact,

        "vendor_contact": vendor_contact,
        "vendor_id": vendorId,
        "vendor_name": vendorName,
        "id": id,
        "time": time,
        "updatedAt": updatedAt.toIso8601String(),
      };
}
