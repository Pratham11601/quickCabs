import 'dart:convert';

VendorsDeatils vendorsDeatilsFromJson(String str) =>
    VendorsDeatils.fromJson(json.decode(str));

String vendorsDeatilsToJson(VendorsDeatils data) => json.encode(data.toJson());

class VendorsDeatils {
  VendorsDeatils({
    required this.message,
    required this.vendors,
    required this.status,
  });

  String message;
  List<Vendor> vendors;
  bool status;

  factory VendorsDeatils.fromJson(Map<dynamic, dynamic> json) => VendorsDeatils(
        message: json["message"],
        vendors:
            List<Vendor>.from(json["vendors"].map((x) => Vendor.fromJson(x))),
        status: json["status"],
      );

  Map<dynamic, dynamic> toJson() => {
        "message": message,
        "vendors": List<dynamic>.from(vendors.map((x) => x.toJson())),
        "status": status,
      };
}

class Vendor {
  Vendor({
    required this.status,
    this.city,
    this.businessName,
    required this.createdAt,
    required this.phone,
    required this.id,
    required this.updatedAt,
    this.fullname,
    this.email,
    this.profileImgUrl,
    this.vendorGender,
    this.documentImgUrl,
    this.currentAddress,
    this.carnumber,
    this.subcriptionPlan,
    this.vendorCat,
    this.permenantAddress,
    this.licenseImgUrl,
  });

  DateTime createdAt;
  String phone;
  String? city;
  String? businessName;
  int id;
  DateTime updatedAt;
  String? fullname;
  String? email;
  String? profileImgUrl;
  String? vendorGender;
  String? documentImgUrl;
  String? currentAddress;
  String? carnumber;
  String? subcriptionPlan;
  String? vendorCat;
  String? permenantAddress;
  String? licenseImgUrl;
  int status;

  factory Vendor.fromJson(Map<dynamic, dynamic> json) => Vendor(
        status: json["status"] ?? 5,
        createdAt: DateTime.parse(json["createdAt"]),
        phone: json["phone"] ?? 0,
        id: json["id"] ?? 0,
        updatedAt: DateTime.parse(json["updatedAt"]),
        fullname: json["fullname"] ?? "",
        email: json["email"] ?? "",
        profileImgUrl: json["profileImgUrl"] ?? "",
        businessName: json['businessName'],
        city: json['city'],
        vendorGender: json["vendor_gender"] ?? "",
        documentImgUrl: json["documentImgUrl"] ?? "",
        currentAddress: json["currentAddress"] ?? "",
        carnumber: json["carnumber"] ?? "",
        subcriptionPlan: json["subcriptionPlan"] ?? "",
        vendorCat: json["vendor_cat"] ?? "",
        permenantAddress: json["permenantAddress"] ?? "",
        licenseImgUrl: json["licenseImgUrl"] ?? "",
      );

  Map<dynamic, dynamic> toJson() => {
        "createdAt": createdAt.toIso8601String(),
        "status": status,
        "phone": phone,
        "id": id,
        "updatedAt": updatedAt.toIso8601String(),
        "fullname": fullname,
        "email": email,
        "profileImgUrl": profileImgUrl,
        "vendor_gender": vendorGender,
        "documentImgUrl": documentImgUrl,
        "currentAddress": currentAddress,
        "carnumber": carnumber,
        "subcriptionPlan": subcriptionPlan,
        "vendor_cat": vendorCat,
        "permenantAddress": permenantAddress,
        "licenseImgUrl": licenseImgUrl,
      };
}
