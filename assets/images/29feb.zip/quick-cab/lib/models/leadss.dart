import 'dart:convert';

List<LeadsResponse> leadsResponseFromJson(String str) => List<LeadsResponse>.from(json.decode(str).map((x) => LeadsResponse.fromJson(x)));

String leadsResponseToJson(List<LeadsResponse> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class LeadsResponse {
    LeadsResponse({
        required this.totalItems,
        required this.totalPages,
        required this.currentPage,
        required this.leads,
        required this.message,
    });

    int totalItems;
    int totalPages;
    int currentPage;
    List<Lead> leads;
    String message;



    void addLeads(List<Lead> newLeads) {
        leads.addAll(newLeads);
    }


    factory LeadsResponse.fromJson(Map<dynamic, dynamic> json) => LeadsResponse(
        totalItems: json["totalItems"],
        totalPages: json["totalPages"],
        currentPage: json["currentPage"],
        leads: List<Lead>.from(json["leads"].map((x) => Lead.fromJson(x))),
        message: json["message"],
    );

    Map<dynamic, dynamic> toJson() => {
        "totalItems": totalItems,
        "totalPages": totalPages,
        "currentPage": currentPage,
        "leads": List<dynamic>.from(leads.map((x) => x.toJson())),
        "message": message,
    };
}

class Lead {
    Lead({
        required this.id,
        required this.date,
        required this.vendorId,
        required this.vendorName,
        required this.locationFrom,
        required this.toLocation,
        required this.time,
        required this.isActive,
        required this.vendorContact,
        required this.vendorCat,
        required this.createdAt,
        required this.updatedAt,
    });

    int id;
    String date;
    int vendorId;
    String vendorName;
    String locationFrom;
    String toLocation;
    String time;
    bool isActive;
    String vendorContact;
    String vendorCat;
    DateTime createdAt;
    DateTime updatedAt;

    factory Lead.fromJson(Map<dynamic, dynamic> json) => Lead(
        id: json["id"],
        date: json["date"],
        vendorId: json["vendor_id"],
        vendorName: json["vendor_name"],
        locationFrom: json["location_from"],
        toLocation: json["to_location"],
        time: json["time"],
        isActive: json["is_active"],
        vendorContact: json["vendor_contact"],
        vendorCat: json["vendor_cat"],
        createdAt: DateTime.parse(json["createdAt"]),
        updatedAt: DateTime.parse(json["updatedAt"]),
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "date": date,
        "vendor_id": vendorId,
        "vendor_name": vendorName,
        "location_from": locationFrom,
        "to_location": toLocation,
        "time": time,
        "is_active": isActive,
        "vendor_contact": vendorContact,
        "vendor_cat": vendorCat,
        "createdAt": createdAt.toIso8601String(),
        "updatedAt": updatedAt.toIso8601String(),
    };

}
