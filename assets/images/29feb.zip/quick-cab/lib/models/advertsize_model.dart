
import 'dart:convert';

AdvertizeModel advertizeModelFromJson(String str) => AdvertizeModel.fromJson(json.decode(str));

String advertizeModelToJson(AdvertizeModel data) => json.encode(data.toJson());

class AdvertizeModel {
    AdvertizeModel({
        required this.image,
    });

    String image;


    factory AdvertizeModel.fromJson(Map<dynamic, dynamic> json) => AdvertizeModel(
        image: json["image"]?? " " ,

    );

    Map<dynamic, dynamic> toJson() => {
        "image": image,

    };
}
